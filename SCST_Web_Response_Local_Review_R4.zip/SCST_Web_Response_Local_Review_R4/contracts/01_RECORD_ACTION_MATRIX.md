# R4 — Ma trận record, hành động và external review

**Ngày:** 31-10-2026. **Phạm vi:** phản hồi W-04, W-05 và yêu cầu ma trận thống nhất tại mục 4 của LOCAL_REVIEW_REPORT.md. **Trạng thái:** REVIEW_RESPONSE / PROPOSED_FOR_RECONCILIATION. Chưa là schema/API/backend đã triển khai, chưa cấp quyền sử dụng phương án thực và chưa thay Final Baseline. Đây là supplement phản hồi review, không phải baseline phiên bản mới. ZIP v0.3 được giữ nguyên. Kết quả replay Windows chỉ được local báo cáo; folder log/receipt được liên kết trong báo cáo chưa được đính kèm để đối chứng trực tiếp ở vòng web này.

## 1. Kết luận cần chốt ở mức thiết kế

Local nhận định đúng: v0.3 mới quy định những record cần có, chưa nối chúng thành một contract có hành động, điều kiện, giao dịch và lỗi rõ ràng. Có thể cụ thể hóa phần này ngay bằng phân tích kỹ thuật, không cần yêu cầu owner chọn serializer, transaction hoặc cấu trúc repo.

Ba quyết định kỹ thuật đề nghị:

1. **Trạng thái được suy từ content, receipts và events; không tin một cờ VERIFIED/APPROVED do client gửi.** Content bất biến và projection trạng thái là hai lớp khác nhau.
2. **Điều kiện chặn gắn với hành động và phạm vi đã khai.** Hồ sơ review hiện trường còn thiếu không tự khóa xem/chỉnh/so sánh/xuất sơ bộ nếu đầu vào và các điều kiện core cho những hành động ấy đã đủ. Ngược lại, thiếu dữ liệu giới hạn/profile bắt buộc của core không được chuyển nhãn thành “để chuyên môn xem sau” nhằm cho solver hoặc selection vượt qua.
3. **Không yêu cầu mọi hồ sơ có một cổng thu hồi trực tuyến.** Review policy phải xác định phương thức kiểm tình trạng hiện hành phù hợp với loại hồ sơ và quy trình thật. Khi chưa có phương thức được chấp nhận thì đánh dấu UNKNOWN cho hành động phụ thuộc; không suy NOT_REVOKED, không khóa toàn bộ công cụ và cũng không giả một quy trình xác minh không tồn tại.

## 2. Nguyên tắc chung cho mọi command

### 2.1 Danh tính và quyền

`principal` là danh tính backend lấy từ phiên hoặc kênh dịch vụ đã xác thực, không lấy từ body request. Quyền là capability cho hành động cụ thể, có target/scope và policy version. Một operator có thể được giao nhiều capability nếu quy trình đơn vị cho phép; tool không mặc nhiên gán thẩm quyền chuyên môn chỉ vì đó là người duy nhất dùng app.

Nhóm capability cần biểu diễn: đọc; nhập/sửa draft; xác nhận dữ liệu; chạy/cancel solver; sửa plan; chọn sơ bộ; đăng ký hồ sơ review; đối chiếu hồ sơ; ghi sự kiện thay thế/thu hồi; backup/restore. Reviewer bên ngoài không cần account giả; họ là chủ thể được nêu trong bằng chứng ngoài app. Agent chỉ có các capability draft/read/run được bật rõ qua CVF và backend; không có confirm, selection hoặc chấp thuận review.

Quy tắc phân quyền và người đầu mối được đơn vị xác nhận ở bước thiết lập theo căn cứ có thật; app lưu chúng như trust configuration có version/audit. Không tự tạo người ký hoặc yêu cầu một chuỗi xác minh vô hạn cho mọi người xác minh. Quyền quản trị app không tự cấp thẩm quyền kỹ thuật review profile. Cách phân công thực là đầu vào của owner/đơn vị; cách backend kiểm capability là trách nhiệm thiết kế/triển khai.

### 2.2 Phần chung của một command

| Thành phần | Ý nghĩa cần chốt |
|---|---|
| Command identity | `commandId`/idempotency key và action name |
| Target | Ref/hash bất biến, hoặc ID cùng expected revision của projection cần đổi |
| Actor | Server-derived principal và authentication event; agent có thêm CVF decision binding khi capability được bật |
| Preconditions | Scope, quyền, expected revision, dependency/source/policy còn áp dụng |
| Requested effect | Nội dung sửa hoặc ref đề nghị dùng; client không gửi kết luận quyền authoritative |
| Receipt | Command result, created refs, actor/event/time/policy, expected/actual revision và lỗi có cấu trúc |

Idempotency chỉ trả lại kết quả cũ khi cùng principal, action, key, target và payload hash. Cùng key nhưng payload khác phải xung đột. Việc trả lại kết quả lịch sử vẫn cần quyền đọc hiện hành và không được làm sống lại eligibility hiện tại của một plan/review đã hết hiệu lực. Các lệnh có tác dụng lên quyền sử dụng hiện tại phải kiểm current policy/applicability ở thời điểm thực hiện hành động mới.

### 2.3 Không tạo vòng hash

Confirmed content không trỏ ngược receipt xác nhận chính nó. ConfirmationReceipt pin targetRef, draftRef và field claims; lifecycle/index liên kết receipt với trạng thái hiển thị. Plan giữ provenance cần thiết tới run ID; run/validation/selection trỏ đúng content mà không làm chu trình hash. Thay nội dung hoặc ý nghĩa đơn vị tạo schema/version/hash mới; không sửa receipt cũ để gắn sang hash mới.

## 3. Ma trận record → lifecycle → command → actor → điều kiện → evidence → transaction → lỗi

Các tên record/action dưới đây là tên đề nghị để local map sang schema/API. Không tuyên bố chúng đã tồn tại. State là projection suy ra, trừ khi có trường nội dung được version riêng có ý nghĩa nghiệp vụ.

| Record | Lifecycle / action | Principal | Preconditions | Evidence bắt buộc | Ranh giới giao dịch | Lỗi / khôi phục |
|---|---|---|---|---|---|---|
| SourceArtifact | INGESTED / register source | Ingest service dưới command của operator | File hoàn chỉnh, loại/kích thước cho phép, bytes/hash được server tính, test namespace được giữ | Blob thật, import event, nguồn nhận và thời điểm; chưa đồng nghĩa chứng từ thật | Publish blob hoàn chỉnh trước; sau đó DB commit source record + event + command result | File chưa đầy đủ không đăng ký; file có mà DB chưa commit là orphan có thể dọn; không có confirmed target trỏ blob thiếu |
| ManualEntryEvent | RECORDED / record manual input | Operator có quyền nhập | Có field/question, raw input, unit/context; actor thật | Event nhập tay; không giả document hash | DB commit event + command result | Input thiếu vẫn thành draft, không thành confirmed content |
| IntakeDraft | DRAFT / NEEDS_REVIEW / append revision | Operator; agent chỉ khi có capability được bật | Đúng expected draft revision; source refs resolve; chưa cần mọi giá trị đầy đủ | Raw fields, candidate, conflicts, source spans; correction reason | DB commit revision mới + change event + CAS draft head | STALE_REVISION không ghi đè; client reload/so diff. Không chuyển conflict thành 0 |
| EntityContent + ConfirmationReceipt | DATA_CONFIRMED / confirm draft | Data confirmer có quyền | Source registry/graph hợp lệ, không synthetic/test; critical field coverage đủ; exact normalization; target và draft còn đúng revision | Target content, draft, FieldClaims, source refs, actor event, coverage/normalization policy | Một DB transaction ghi content, receipt, links/lifecycle và command result; blob dependencies đã durable | Thiếu nguồn/field/actor hoặc stale thì không có DATA_CONFIRMED orphan; draft còn để sửa; retry idempotent |
| SupportProfileContent | DATA_CONFIRMED → APPLICABLE_FOR_SCOPE / activate profile use | System đánh giá; technical conclusion từ nguồn có thẩm quyền | Content đã xác nhận; scope/type/dimensions và review evidence đúng đối tượng; conditions đủ | Profile source, statement/verification tương ứng, scope và validity policy | Activation/evaluation receipt pin profile/review/policy; không sửa content/rating cũ | Profile không đủ review thì giữ pending/inapplicable; không dùng field-review plan thay cho profile rating |
| GeneratorDefinition / ArrangementTemplate | REGISTERED_FOR_BUILD → SUPPORTED_FOR_INPUT / register and assess generation capability | Build/config registrar có quyền; system đánh giá input support | Definition có version, implementation/build tương ứng; input/profile/geometry phù hợp với phạm vi đã kiểm; không eval script từ hồ sơ | Definition/build/config refs, supported input contract, profile refs và coverage của phép dựng | DB commit registration/config version và capability assessment; run pin đúng version, không sửa ngầm template | Thiếu generator cho input thì không dispatch auto-generation; vẫn cho luồng nhập/kiểm thủ công khi model và quyền đủ; không suy capability từ profile hợp lệ |
| LoadingCaseContent | SNAPSHOT_CREATED → PREFLIGHT_READY / create or revise case | Operator/case service | Refs/hash đúng, scope/input đủ theo preflight; initial state và allowance được xác nhận | Pinned vessel/hold/manifest/profile/rules, input confirmations, preflight outcome | DB commit case version + index/head CAS + result; ready là evaluation, không cờ client | Dependency đổi/hết hiệu lực khiến readiness cần đánh giá lại; lịch sử giữ nguyên |
| OptimizationRun | QUEUED/RUNNING → completed/timeout/error/cancel / dispatch run | Operator hoặc agent có run capability; solver worker | Case snapshot pin; current action allowed; preflight của model đủ; đúng generator/template implementation hỗ trợ input | Run config, seed/build, case/template/profile refs và capability assessment, actor/CVF binding nếu áp dụng | DB commit run request trước dispatch; worker writes append results; state transitions CAS/idempotent | Thiếu khả năng sinh trả lỗi riêng; worker crash/cancel tạo trạng thái đúng; run cũ hoàn tất muộn không đổi case head/selection |
| PlanContent | PROPOSED / create candidate or manual revision | Solver service; operator; agent chỉ bounded draft revision khi được bật | Unit IDs thuộc case; đúng parent/case cho sửa tay; immutable input refs | Generation provenance hoặc edit event, parent ref, positions và partition | DB commit content mới + lineage; chưa có valid/selected claim | Geometry lỗi vẫn lưu chẩn đoán nếu policy cho; không kế thừa run proof hoặc validation cũ |
| ValidationReceipt | CHECKED / validate exact plan | Validator service qua command được phép | Plan/case/dependencies/policy được pin; coverage được tính server-side | Từng rule và outcome/reason/evidence, validator build, observed totals | DB commit receipt bất biến và assessment projection | Missing rule/unknown/fail ở điều kiện của action chặn action; không đổi receipt lịch sử khi rule đổi |
| PreliminarySelectionEvent | PRELIMINARY_SELECTED / select plan | Plan selector là người có quyền | Core conditions và required fulfillment đạt; validation đúng current plan/snapshot; expected selection revision khớp | Plan/validation/case refs, actor event, selection policy; nêu rõ review ngoài phạm vi còn thiếu | DB transaction ghi event + CAS selected-plan projection + result | STALE/CORE_NOT_SATISFIED/VALIDATION_STALE không chọn; không dùng field receipt để override hard fail |
| ExternalReviewStatement + Registration | RECORDED_PENDING_CHECK / register external document | Review recorder đã auth | Có attachment và stated subject; có thể chưa đủ binding/authority | Original blob, extracted assertion có source span, người review được nêu, operator auth của việc ghi nhận | DB commit statement/registration + source links + result sau blob publication | Thiếu binding vẫn lưu pending; không tạo reviewer login hoặc approval giả |
| ExternalReviewVerification | PARTIAL / POLICY_REQUIREMENTS_SATISFIED / verify evidence | Review verifier được giao | Đúng statement/subject, policy cho loại review; các check phải có nguồn và kết quả riêng | Identity/authority check, exact-subject binding, conditions/coverage, validity/current-status method và time | DB commit verification receipt; người đối chiếu không sửa original statement | UNKNOWN/PARTIAL cho phần chưa kiểm; lỗi chỉ chặn hành động cần phần đó; không tự đánh dấu whole document invalid vì không có API online |
| PlanUseAssessment | CURRENTLY_REVIEWED_FOR_DECLARED_SCOPE hoặc PENDING/INAPPLICABLE / assess declared use | System evaluation; human decision ở đúng vai trò | Core hard conditions, selection và review coverage/conditions hiện hành đủ cho scope; data/profile review riêng vẫn hợp lệ | Plan/case/validation, applicable external evidence, policy/version/time và phạm vi đánh giá | Evaluation receipt pin inputs; không tạo nhãn an toàn chung hoặc điều khiển thi công | Missing applicable evidence ⇒ pending cho declared field-use; vẫn giữ các chức năng không phụ thuộc đủ điều kiện |
| Supersession/WithdrawalEvent | SUPERSEDED/WITHDRAWN/REPORTED_CHANGE_PENDING / record change | Recorder/verifier có capability đúng loại | Có nguồn/scope của thay đổi; phân biệt thông báo chưa đối chiếu với xác nhận đủ | Source/event, subject ref, effective date và recording date, actor và verification nếu có | Append event + invalidate affected projections; không xóa lịch sử | Late information không viết lại lịch sử; đánh dấu tác động/current eligibility, yêu cầu assessment mới |
| BackupManifest / RestoreAssessment | CREATED/VERIFIED hoặc RESTORE_PENDING / backup, restore | Operator được quyền; maintenance service | Snapshot DB nhất quán, blobs được pin; restore vào vùng tạm và kiểm hashes/refs/schema | DB snapshot, blob manifest, versions/check results; không lưu sessions/keys như nghiệp vụ | Backup có trạng thái incomplete tới lúc đủ artifacts; restore được kiểm trước atomic switch của bộ dữ liệu theo implementation | Missing blob/integrity failure ⇒ không chuyển sang operational store; sau restore current validity/auth được đánh giá lại |

Ma trận không cho phép AI vượt capability bởi nó tự khai role human hoặc có CVF ALLOW. Policy và actor được backend quyết định. Việc hỗ trợ agent command được bật sau đúng gate CVF, không tự có trong core.

## 4. Điều kiện chặn theo hành động: tránh công cụ luôn “chờ duyệt”

| Trạng thái thiếu | Vẫn được làm | Chưa được làm |
|---|---|---|
| Nguồn/giá trị chưa xác nhận | Lưu draft, đối chiếu nguồn, sửa/xem candidate, xuất danh sách thiếu; test trong namespace synthetic riêng | Tạo case operational-ready hoặc dùng giá trị đó như giới hạn đã xác nhận |
| Profile bắt buộc cho cấu hình chưa đủ dữ liệu/review | Tra cứu, nhập profile draft, xem yêu cầu, làm phần test kỹ thuật độc lập | Tạo/chọn phương án thật sử dụng cấu hình thiếu profile đó |
| Core hard checks không đạt | Lưu chẩn đoán, sửa, so sánh lỗi, xuất draft có trạng thái rõ | Preliminary selection đáp ứng mục tiêu chuyến, hoặc field-use claim |
| Core đã đủ, review riêng cho hiện trường chưa đủ | Tạo candidate, sửa/kiểm lại, so sánh, chọn **sơ bộ** nếu policy core cho phép, xuất báo cáo lập kế hoạch có coverage rõ | Gắn nhãn đã review đủ cho phạm vi hiện trường còn thiếu |
| Hồ sơ review được nhận nhưng binding/current-status check chưa đủ | Lưu, đọc, đối chiếu, yêu cầu làm rõ; các thao tác planning không phụ thuộc hồ sơ đó tiếp tục | Dùng hồ sơ đó như review áp dụng cho plan hiện tại |
| Review cũ hết hiệu lực hoặc bị thay thế | Đọc lịch sử, xem lý do, dựng lại assessment hoặc phương án mới | Tái dùng kết luận cũ cho action hiện tại mà không kiểm lại |

Không được sửa severity hoặc đưa một core-hard constraint sang nhóm review bên ngoài chỉ để mở nút. Action policy phải được version, có lý do, và được kiểm bằng test coverage. Nếu một giới hạn nằm trong cả planning và field-use, nó phải được thỏa cho cả hai hành động tương ứng.

Trong UI, nên diễn đạt trực tiếp “Thiếu xác nhận khối lượng bó X”, “Chưa có profile cho quan hệ A đặt lên B”, hoặc “Đã chọn sơ bộ; chưa có hồ sơ review cho điều kiện máy trên hàng”. Không dồn tất cả thành một trạng thái APPROVED/NOT_APPROVED khiến người dùng không biết còn làm được gì.

## 5. External review không giả định có hệ thống thu hồi trực tuyến

### Ví dụ trạng thái synthetic để đối chiếu workflow

Các ví dụ này có `testOnly=true`, chỉ minh họa policy đề nghị; không phải fixture schema-valid, kết quả đã chạy hoặc dữ liệu tàu thật. Không ví dụ nào cấp `operationalEligible=true`.

| Ví dụ | Điều kiện giả lập | Hành vi đề nghị |
|---|---|---|
| SYN-WF-A | Core input/profile/validation đủ; review riêng cho field use đang chờ | Cho planning, so sánh, chọn sơ bộ và export có trạng thái rõ theo policy; chưa có claim review đủ cho field use |
| SYN-WF-B | Thiếu profile bắt buộc cho quan hệ chồng, dù có file đính kèm chung | Giữ draft/chẩn đoán; không tạo/chọn phương án thật dùng quan hệ đó |
| SYN-WF-C | Không có online registry; policy đã chấp nhận cách đối chiếu thủ công; evidence/time/scope của cách đó đầy đủ | Đánh giá theo policy và ghi đúng phương thức; không tạo kết quả truy vấn online giả hoặc notRevoked tuyệt đối |
| SYN-WF-D | Chỉ có tên reviewer trong payload; thiếu source/binding hoặc không có phương thức kiểm được chấp nhận | Lưu pending, cho thao tác bổ sung/đối chiếu; không coi tên tự khai là review áp dụng |

### 5.1 ReviewPolicy phải định nghĩa phương thức, không chỉ đòi một boolean

Với mỗi loại hồ sơ, policy cần:

- Phạm vi đối tượng: profile, phương án, phương tiện/chuyến hoặc điều kiện riêng.
- Cách xác định người có thẩm quyền và nguồn chứng minh việc được giao trách nhiệm.
- Cách bind hồ sơ với nội dung được review: plan hash trong export, bản xác nhận bổ sung hoặc cơ chế version/bản tài liệu tương đương được quy trình chấp nhận.
- Loại hiệu lực: đến ngày; chỉ cho chuyến/điều kiện; đến khi có thay đổi được liệt kê; hoặc cần xác nhận lại tại action. Không tự chọn “vĩnh viễn” khi chứng từ không có expiry.
- Phương thức kiểm tình trạng hiện hành được chấp nhận, lần kiểm, người kiểm, nguồn và trigger kiểm lại.
- Yêu cầu độ mới theo loại action; các điều kiện làm receipt cũ không còn đủ.
- Quy tắc khi thiếu hoặc có thông tin bất lợi: pending/blocked cho phần nào, nội dung nào vẫn được xem/lập kế hoạch.

Policy không phải do agent tự ban hành. Web/local có thể chuẩn bị cấu trúc và default “chưa có policy được chấp nhận”; người chịu trách nhiệm quy trình xác nhận các phương thức dùng được trên thực tế.

### 5.2 Những phương thức có thể được quy trình chấp nhận

| Phương thức | Evidence cần ghi | Kết luận được phép |
|---|---|---|
| Registry do đơn vị/issuer vận hành | Subject ID, nguồn, kết quả, thời gian tra cứu, scope và identity nếu cần | Đã kiểm trạng thái theo registry tại thời điểm đó, không bảo đảm vĩnh viễn |
| Xác nhận trực tiếp từ issuer/reviewer | Nội dung phản hồi/cách xác minh, người liên hệ, subject/version/hash, thời gian và điều kiện | Có xác nhận hiện hành theo nguồn cụ thể, phạm vi cụ thể |
| Quy trình kiểm thủ công được đơn vị chấp nhận | Checklist có policy version; bản hồ sơ hiện hành, identity/authority/binding, thông báo thay thế đã biết, người kiểm/time; các trigger review lại | Đã đối chiếu theo phương thức đó; không tự nói đã truy cập cơ sở thu hồi không tồn tại |
| Không có nguồn hoặc phương thức được chấp nhận | Thiếu gì và ai có thể cung cấp | UNKNOWN/PENDING cho action cần review; không suy ra “không bị thu hồi” |

Đây là các lựa chọn thiết kế cần quy trình xác nhận, không phải lời khẳng định mọi phương thức đủ về mặt pháp lý. Không mặc định rằng không có API online thì mọi hồ sơ đều vô dụng. Cũng không mặc định một checklist do operator tự tích là đủ thẩm quyền.

Nên dùng kết quả `CURRENT_STATUS_CHECK_SATISFIES_POLICY` với method/evidence/time/scope thay vì một boolean `notRevoked` tạo cảm giác biết tuyệt đối. Sự vắng mặt của thông báo trong cơ sở dữ liệu app chỉ chứng minh app chưa ghi nhận, không chứng minh ngoài thực tế không có thay đổi.

### 5.3 Bộ hồ sơ gửi review dễ thực hiện

Tool có thể xuất một review package gồm plan/case/version, hash/QR hoặc mã nhận diện, manifest và bố trí cần xem, coverage và danh sách điều kiện chưa đánh giá. Reviewer xem/ghi nhận đúng đối tượng theo quy trình. Operator nhập lại hồ sơ đã review và verifier kiểm binding. Không cần buộc reviewer tạo account cloud hoặc sử dụng hệ thống ký số do tool tự phát minh.

Nếu người review chỉ ký một bản vẽ không thể liên hệ chắc chắn với plan, cần bổ sung binding theo quy trình; không dùng thao tác chọn plan ở dropdown để tạo liên hệ thay họ. Nhận hồ sơ và kết luận hồ sơ đủ điều kiện áp dụng là hai hành động riêng.

## 6. Source registry và field coverage đủ cụ thể để triển khai

### 6.1 Registry không chỉ là một nhãn nguồn

Source record cần identity, immutable hash/bytes hoặc manual event, loại nguồn, namespace test/real do server giữ, quá trình nhận, lineage (như OCR/transform), và các sự kiện thay thế/phát hiện vấn đề. Label DOCUMENT không chứng minh thật; registry chỉ đảm bảo consistency với nguồn đã đăng ký và quy trình xác nhận.

Content-addressing không thay quyền hoặc sự thật. Cùng bytes có thể được tái dùng nhưng phải giữ các context/claims khác nhau khi nguồn áp dụng khác nhau; không tự thừa kế xác nhận của chuyến trước chỉ vì cùng file hash.

### 6.2 CriticalFieldPolicy

Mỗi entity type/schema version có policy liệt kê JSON Pointer hoặc quy tắc tạo tập pointer bắt buộc. Các nhóm tối thiểu:

- Phương tiện: identity, cargo limit, nguồn/hiệu lực áp dụng.
- Hầm: geometry/frame, số đo/phương pháp, exclusions và margins có căn cứ.
- Manifest: unit ID, cargo semantics/packaging, dimensions, mass và linkage đến dòng/đơn vị nguồn.
- Profile: cấu hình, phạm vi, limits, basis tải, hướng/compatibility và nguồn chuyên môn.
- Case: initial state, existing load, voyage allowance, dunnage reserve, dates/scope và refs tới các entity.

Không yêu cầu mọi trường mô tả UI đều có xác nhận thủ công. Các tổng/giá trị derived có claim pin input set và formula version. Một pointer tồn tại nhưng normalized value/hash không khớp vẫn là coverage failure. Một field claim trỏ snapshot khác hoặc source span ngoài file cũng bị từ chối.

### 6.3 Correction không phải đổi đơn vị

Phân biệt extract candidate, exact conversion, derived aggregate và human correction. Khi operator sửa giá trị đã đọc sai, ghi giá trị cũ/mới, người/thời điểm, nguồn hoặc quan sát bổ sung và lý do. Không viết correction vào metadata như UNIT_CONVERSION_EXACT để che một thay đổi có ý nghĩa nghiệp vụ.

Không dùng version/hash giả để điền đủ ví dụ. Các record demo cần testOnly và không được chứa một fake signature hoặc xác nhận chuyên môn được diễn đạt như thật.

## 7. Khối lượng và đo lường

Đọc cùng `contracts/03_MASS_MEASUREMENT.md` trong supplement. Ma trận này giữ các bất biến chung: raw value/unit/locale không bị mất; chuẩn hóa exact; giá trị so hạn mức khác giá trị làm tròn hiển thị; critical field claims bao phủ mass/dimensions/margins; policy và nguồn của margin được pin; thay đơn vị tạo schema/field/hash mới và lineage, không chuyển receipt cũ sang nội dung mới.

Integer grams là lựa chọn biểu diễn cần reconcile với mẫu dữ liệu và miền wire/DB. Nó không tự xác định độ chính xác cân, uncertainty của nguồn hoặc margin hình học. Không tạo ±1 g/±1 mm từ việc phần mềm lưu số nguyên. Các ca CT-13…15 bên dưới chỉ là acceptance đề nghị phối hợp với tài liệu mass/measurement, chưa chạy.

## 8. Persistence, concurrency và recovery

### 8.1 File store không được giả là nằm trong transaction SQLite

Tài liệu SQLite mô tả atomic commit cho các thay đổi trong transaction database. SCST dùng file store bên ngoài nên phải thiết kế riêng điểm nối DB/blob; không thể chỉ ghi “một transaction” rồi suy file và DB cùng commit. Nguồn: SQLite Atomic Commit, https://www.sqlite.org/atomiccommit.html (đối chiếu 31-10-2026).

Đề nghị bounded protocol:

1. Nhận bytes vào staging ngoài vùng confirmed; kiểm size/hash và hoàn thành file.
2. Publish blob bất biến vào store dưới digest theo thủ tục durability được local kiểm trên OS/filesystem mục tiêu.
3. DB transaction kiểm idempotency/expected revision/current preconditions, ghi source/content/receipt/link/event/result cùng nhau.
4. Sau commit mới trả thành công và cập nhật UI. Không có verified row trỏ một blob chưa hoàn thành.
5. Crash trước DB commit có thể để orphan blob; dọn theo quy trình không đụng file đã được bất kỳ snapshot/backup tham chiếu. Crash sau commit không được thiếu dependency đã hứa durable; nếu phát hiện mất/corrupt file thì đánh dấu integrity failure và chặn action phụ thuộc.

Không cam kết nguyên tử giữa filesystem và DB trong mọi lỗi nguồn điện nếu chưa kiểm cơ chế và môi trường. Nếu local chọn lưu small artifacts trong DB hoặc giao thức khác, cần chứng minh cùng invariant; không bắt buộc cụ thể tên hàm flush/rename trong baseline review.

### 8.2 Optimistic concurrency và lỗi

SQLite cho phép nhiều read transaction nhưng chỉ một write transaction đồng thời; write có thể trả SQLITE_BUSY. Nguồn: https://www.sqlite.org/lang_transaction.html. Điều này không thay optimistic concurrency của nghiệp vụ: hai UI request từ cùng người vẫn có thể dựa trên revision cũ.

Các lỗi cần tách: AUTH_DENIED, SCOPE_DENIED, STALE_REVISION, IDEMPOTENCY_CONFLICT, SOURCE_UNRESOLVED, SOURCE_TEST_ONLY, FIELD_COVERAGE_INCOMPLETE, NORMALIZATION_AMBIGUOUS, NUMERIC_RANGE_EXCEEDED, CORE_NOT_SATISFIED, REVIEW_PENDING, REVIEW_INAPPLICABLE, INTEGRITY_FAILURE, STORAGE_BUSY và STORAGE_FAILURE. Tên cuối do local chốt, nhưng phân biệt ý nghĩa không được mất.

Retry bounded cho lỗi tài nguyên được phép; stale/khác payload không retry tự động như cùng command. Khi kết quả commit không rõ vì mất kết nối, client tra commandId trước khi gửi một command mới. Không báo “thành công” trước khi receipt/result durable; cũng không tạo duplicate snapshot/event chỉ vì người dùng bấm lại.

### 8.3 Backup/restore

SQLite có cơ chế tạo snapshot DB qua Online Backup API; tài liệu mô tả phạm vi snapshot database. Nguồn: https://www.sqlite.org/backup.html. Backup của SCST cần thêm danh sách blobs mà snapshot DB tham chiếu và bảo đảm chúng không bị garbage collection trong lúc copy. Snapshot DB một mình chưa là backup hoàn chỉnh của hồ sơ nguồn.

Restore vào vị trí tạm, kiểm schema/integrity/refs/blobs trước khi dùng; giữ bản đang chạy tới khi việc chuyển bộ dữ liệu được hoàn thành theo giao thức đã kiểm. Không restore session/key/credential vào hiệu lực hiện hành. Lịch sử review được phục hồi đúng bytes, nhưng current validity/withdrawal và authorization phải được đánh giá lại cho hành động mới.

## 9. Acceptance delta có ý nghĩa

Các ca dưới đây là yêu cầu tương lai, không phải tests đã chạy. Không chạy lại 86 reference tests chỉ để tăng số lượng bằng chứng khi code/input không đổi.

| ID | Ca cần kiểm | Expected |
|---|---|---|
| CT-01 | Có cùng command key và payload; response lần đầu bị mất | Một effect duy nhất; retry lấy cùng receipt; không duplicate event |
| CT-02 | Cùng key khác payload/target | IDEMPOTENCY_CONFLICT, không ghi effect thứ hai |
| CT-03 | Hai confirmation/selection requests cùng expected revision | Chỉ một head update thắng; request còn lại stale, không overwrite |
| CT-04 | Blob hoàn thành nhưng crash trước DB commit | Không có confirmed orphan row; blob orphan có thể phát hiện/dọn an toàn |
| CT-05 | DB transaction bị lỗi sau khi chuẩn bị receipt | Không có snapshot confirmed thiếu receipt/links; command không báo success |
| CT-06 | Restore thiếu một blob hoặc blob khác hash | Không chuyển store thành vận hành; chỉ rõ dependency lỗi |
| CT-07 | Core đủ, field review pending | Được planning/so sánh/xuất sơ bộ theo policy; chưa được field-use claim |
| CT-08 | Core profile/rating bắt buộc thiếu, nhưng có attachment generic | Không được dùng attachment thay missing profile; core action chặn |
| CT-09 | Hồ sơ không có online revocation registry nhưng có phương thức thủ công được policy chấp nhận | Đánh giá theo đúng method/evidence/time; không đòi endpoint giả hoặc ghi notRevoked tuyệt đối |
| CT-10 | Không có bất kỳ phương thức/source được policy chấp nhận cho current-status check | Review pending cho action phụ thuộc; các tác vụ độc lập vẫn hoạt động |
| CT-11 | Cùng file hash được tái dùng cho chuyến khác | Không tự kế thừa confirmation/review scope của chuyến cũ |
| CT-12 | Field pointer/normalized value đổi sau confirmation | Hash/binding không khớp; receipt cũ không xác nhận giá trị mới |
| CT-13 | Mass đúng hạn mức và vượt 1 g trong contract grams | Exact comparison; không dùng rounded kg/t UI |
| CT-14 | Mass hoặc tổng vượt numeric wire range | Reject trước serialize/commit; không đổi sang float hoặc im lặng mất integer precision |
| CT-15 | Nguồn chỉ công bố cm hoặc uncertainty chưa biết | Lưu đúng phương pháp/resolution/UNKNOWN; không tạo ±1 mm hoặc margin giả |
| CT-16 | Run cũ kết thúc sau case/selection đã đổi | Lưu đúng lịch sử, không làm mới selection hoặc current candidate tự động |
| CT-17 | Profile áp dụng và model kiểm được, nhưng không có generator hỗ trợ input | Không dispatch auto-generation hoặc báo vô nghiệm; luồng nhập bố trí/kiểm thủ công tiếp tục nếu quyền và điều kiện đủ |

Các ca CT cần mapping với ADM/ER/LAT có sẵn để tránh duplication. Một test integration có thể cung cấp bằng chứng cho nhiều requirement nếu expected/phạm vi được nêu rõ.

## 10. Điều có thể chốt bằng kỹ thuật và điều còn cần người có thông tin

**Có thể đưa vào contract đề nghị ngay:** chiều refs chống hash cycle; server-derived actor; idempotency và concurrency; field coverage/resolver; phân biệt state/action; DB/blob invariant; yêu cầu restore; không dùng binary float/rounded display để quyết định mass; giữ lineage của correction/migration.

**Cần đối chiếu quy trình/dữ liệu trước freeze:** loại review và người có thẩm quyền; cách xác minh hồ sơ/thay thế/thu hồi thực có thể thực hiện; action nào cần mỗi loại evidence; manifest precision/handling units; phương pháp đo hầm/hàng và policy uncertainty/margin; các profile/rating kỹ thuật thật.

Những đầu vào còn thiếu chỉ chặn quyết định hoặc chức năng phụ thuộc. Không cần owner thiết kế DB transaction, chọn serializer hoặc viết oracle. Đây là công việc đội phát triển đề xuất, local kiểm khả năng hiện thực và reviewer kiểm phần thuộc thẩm quyền.

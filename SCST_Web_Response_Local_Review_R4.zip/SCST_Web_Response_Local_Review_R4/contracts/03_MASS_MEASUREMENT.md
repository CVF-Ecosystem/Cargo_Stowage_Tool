# Khối lượng, độ phân giải và chất lượng số đo

**Trạng thái:** PROPOSED_FOR_RECONCILIATION. Phản hồi W-05 và đề nghị precision của local; chưa thay schema v0.2, chưa migration hoặc triển khai backend.

## 1. Phần có thể quyết định bằng kỹ thuật

Đề nghị core vận hành dùng **integer grams** cho khối lượng và **integer millimetres** cho geometry đã chuẩn hóa, với cùng giới hạn số của canonical contract. Đây là lựa chọn biểu diễn, không phải tuyên bố cân chính xác tới gram hoặc hầm đã đo chính xác tới millimetre.

VIM của JCGM phân biệt resolution của thiết bị và measurement uncertainty (JCGM 200:2012, mục 4.14 và 2.26). Hai khái niệm đó không đồng nhất với độ phân giải dữ liệu phần mềm. Nguồn: https://www.bipm.org/documents/20126/2071204/JCGM_200_2012.pdf .

Local chịu trách nhiệm đối chiếu mẫu manifest, miền giá trị, parser/DB/wire/solver và migration. Owner không cần chọn serializer hoặc kiểu số; owner cung cấp dữ liệu gốc và cách khai báo số liệu đang dùng.

## 2. Hợp đồng grams đề nghị

1. Giữ `rawText`, `sourceUnit`, locale/phân cách đã được nhận diện, source ref/span và basis nguồn. Thiếu khác với số 0; chuỗi mơ hồ ở trạng thái cần xác nhận.
2. Parse decimal exact ở backend. Đổi tấn × 1,000,000; kg × 1,000; g × 1. Không dùng binary float để nhận/so sánh giới hạn.
3. Canonical mass là số nguyên, mọi mass của unit/hiện hữu/kê/allowance/support và tổng cùng đơn vị. Không giữ một số field kg còn một số field g trong cùng phép kiểm.
4. Miền khối lượng không âm; cargo unit phải dương. Mỗi field và phép cộng/nhân trung gian có bound. Dù backend dùng integer lớn, wire/canonical theo v0.2 giới hạn JS-safe cần kiểm trước serialize: trị tuyệt đối không quá 9,007,199,254,740,991.
5. Lưu các đại lượng có đơn vị dưới tên có nghĩa rõ, ví dụ `massG`, không đổi ngầm ý nghĩa `massKg`. Những đại lượng không phải khối lượng như GT không bị nhân 1,000.
6. Giá trị dưới gram không biểu diễn chính xác, overflow hoặc nguồn chưa rõ phải giữ draft và trả reason code. Không truncate hoặc làm tròn xuống để lọt hạn mức. Nếu thực tế cần dưới gram, đó là thay precision contract có chủ đích.
7. UI hiển thị kg/tấn theo precision phù hợp nguồn, có nhãn đơn vị. Giá trị hiển thị làm tròn không trở thành giá trị tính toán hoặc dữ liệu import vòng sau.
8. Đổi kg→g tạo schema version, field name, ref/hash và receipt mới. Migration bảo tồn raw source/lineage; không gắn receipt cũ vào hash mới. Nguồn v0.2 nguyên kg chuyển exact bằng ×1,000 sau kiểm overflow.

### Ví dụ synthetic về conversion

Các con số dưới đây chỉ để kiểm dữ liệu, không phải manifest hoặc định mức của phương tiện thật:

| Nguồn đã xác định cách đọc | Canonical dự kiến | Hành vi |
|---|---|---|
| 2,0005 t; dấu phẩy thập phân đã xác nhận | 2,000,500 g | Exact conversion |
| 2000.5 kg; dấu chấm thập phân đã xác nhận | 2,000,500 g | Cùng kết quả |
| 1,234 kg; chưa rõ locale | Chưa tạo canonical mass | Giữ draft, hỏi cách đọc |
| 0.0004 kg | 0.4 g, không là integer | Giữ draft theo precision đề nghị |
| Một line 3 bó, tổng 6,000 kg, chưa có mass từng bó | Chưa sinh mass của 3 unit | Không tự gán 2,000 kg/bó |

Ngưỡng thử vượt nhỏ nhất chuyển thành **1 g** khi mass contract đổi. Kiểm đúng biên không bị nới bằng epsilon; tolerance hiển thị không được tham gia quyết định.

### Geometry chuẩn hóa theo millimetres

Quy tắc exact conversion cũng áp dụng cho các kích thước và tọa độ đầu vào thuộc miền integer mm: m × 1,000; cm × 10; mm × 1 sau khi giải quyết raw unit/locale. Giá trị sub-mm không biểu diễn exact trong contract này phải giữ draft hoặc đi qua quyết định precision/model có chủ đích; không âm thầm làm tròn cargo nhỏ hơn hoặc hầm lớn hơn. Cargo dimensions phải dương; tọa độ có thể có dấu theo frame được pin. Phải kiểm miền của từng field, offsets, tổng và đại lượng trung gian trước serialize/commit.

Không suy mọi kết quả geometry đều là integer mm. Diện tích/thể tích có đơn vị khác; khoảng cách, góc hoặc phép dựng một primitive có thể tạo số không nguyên. Local phải chốt numeric policy của các primitive được chọn và cách xử lý biên có căn cứ; không lấy epsilon hiển thị làm quyền vượt hard constraint. Rounding/bounding bảo thủ có chủ đích cần source/model policy và kiểm hướng của bound. Renderer hỗ trợ một hình hoặc góc không tự mở hỗ trợ geometry ở solver/validator.

## 3. Metadata số đo cần có, nhưng không bắt người dùng bịa

| Nhóm | Nội dung đề nghị | Khi nguồn không có |
|---|---|---|
| Nguồn và phương pháp | Source artifact/event, người xác nhận, ngày đo/nguồn, MEASURED/DRAWING/DECLARED/ESTIMATED_CONFIRMED phù hợp | Giữ chưa rõ, không tự đổi estimate thành measured |
| Giá trị gốc | Raw value, unit, vị trí nguồn, cách chuẩn hóa | Draft nếu không resolve hoặc mâu thuẫn |
| Độ phân giải được nguồn khai | Bước hiển thị/cách ghi của cân hoặc tài liệu, nếu có | `NOT_STATED`; không điền bằng 1 g/1 mm chỉ vì phần mềm lưu như vậy |
| Thông tin uncertainty/bound | Loại thông tin, giá trị, đơn vị, coverage factor/probability nếu được nguồn công bố | `NOT_STATED`; không mặc định 0 |
| Giá trị dùng lập phương án | Nominal hay outer bound/allowance đã được xác nhận; policy và căn cứ chọn | Không tự tạo bound từ độ phân giải |
| Margin | Mục đích, đối tượng/mặt áp dụng, giá trị và nguồn/decision ref | Không đo từ ảnh hoặc gán một phần trăm chung |

Không dùng một trường `accuracy=...` chung cho mọi loại thông tin. Standard uncertainty, expanded uncertainty, giới hạn nhà sản xuất và một bound bảo thủ do người có trách nhiệm chấp nhận có ý nghĩa khác nhau. Không tự biến một sigma/uncertainty thành một giới hạn tuyệt đối bảo đảm vật lý.

UI nên hỏi theo nguồn: “Số đo lấy từ đâu?”, “Đây là kích thước ngoài của bó hay kích thước danh nghĩa?”, “Số này đã trừ khoảng hở/bao gồm kê chưa?”. Các metadata sâu được importer hoặc người có chuyên môn bổ sung khi nguồn có; không yêu cầu operator tính uncertainty nếu họ không có dữ liệu.

## 4. Dùng bound/margin sao cho không tính hai lần

Khi đã có bound phù hợp được xác nhận, một mô hình bảo thủ có thể dùng envelope hàng phía lớn hơn và vùng hầm phía nhỏ hơn. Đây là cách thiết kế cần profile/measurement policy chấp nhận, không phải công thức tự gán khi thiếu nguồn.

Tách sổ theo dõi:

- **Measurement/source allowance:** phần phản ánh chất lượng số đo hoặc bound được nguồn/decision cung cấp.
- **Operational clearance:** khoảng hở thao tác/điều kiện đã được xác nhận.
- **Geometry approximation:** phần không gian bị bỏ do dùng inner BOX hoặc envelope bảo thủ.
- **Numerical policy:** cách implementation xử lý tính toán/tiếp xúc; không dùng để cho phép vượt hard limit.

Mỗi phần chỉ được áp một lần, pin trong snapshot. Ví dụ một BOX đã là vùng hữu dụng sau clearance không được nhập lại như kích thước thô rồi trừ cùng clearance lần nữa.

Với kích thước có thể đã gồm phần kê, cần ghi `dimensionBasis`: envelope của đơn vị cùng đóng gói/đế gắn với nó, hay kích thước chồng có cả phần kê rời của plan. Chuẩn hóa rõ các thành phần, offsets, anchor/contact plane và profile liên quan trước khi tính placement. Nếu đã tính một phần kê thì không tính lần hai; đồng thời không tự bỏ chiều cao kê trong profile rồi làm sai cao độ tiếp xúc. Chưa tách được basis thì giữ conflict và yêu cầu nguồn làm rõ.

Không tự cộng một uncertainty vào mass thực khai hoặc tự giảm cargo allowance; basis lập phương án và phương pháp bảo thủ phải được người có trách nhiệm chấp nhận. Source quality không được sửa bằng một epsilon kỹ thuật.

## 5. Hành vi khi số đo chưa đủ tin cậy

- Cho lưu nguồn/draft, xem, so sánh và xuất hồ sơ chẩn đoán với nhãn đúng.
- Có thể phân tích trên giả định trong môi trường/test namespace riêng nếu tác vụ được phép; không gọi đó là confirmed operational record.
- Khi điều kiện measurement/model cần cho candidate hoặc selection chưa đủ, chặn đúng bước đó và nêu trường cần bổ sung.
- Thiếu thông tin field-review của một plan không tự làm mất quyền xem/chỉnh dựa trên các input/profile đã đủ điều kiện; xem ma trận action tại contracts/01.

## 6. Delta nghiệm thu cần local xác nhận

Tối thiểu kiểm: conversion exact của mass và geometry; locale ambiguity; sub-gram/sub-mm; negative/zero đúng nghĩa field; overflow field/tổng/trung gian; tổng từ unit; 1 g vượt; UI rounding round-trip; kg→g lineage/hash/receipt; bound không có nguồn; NOT_STATED khác 0; margin được áp đúng một lần; dimension basis có kê không làm đổi sai anchor/contact plane. Đây là ca cần triển khai sau contract reconciliation, chưa có test backend mới trong R4.

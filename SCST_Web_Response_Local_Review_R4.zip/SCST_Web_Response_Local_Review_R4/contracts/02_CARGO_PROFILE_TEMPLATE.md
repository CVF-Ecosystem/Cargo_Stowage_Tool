# Hàng hóa, profile kê/chồng và template sinh phương án

**Trạng thái:** `REVIEW_RESPONSE` / `PROPOSED_FOR_RECONCILIATION`.  
**Đối chiếu:** LOCAL_REVIEW_REPORT.md mục 2.2, 4, W-01/W-02/W-03; v0.3 MASTER mục 3–4 và docs/02; schema manifest/support_profile v0.2 đã pin.  
**Giới hạn:** đây là đề nghị contract để local đối chiếu, chưa phải schema mới, code sinh phương án hoặc profile kỹ thuật đã được duyệt. Không đổi các tệp v0.2/v0.3 đã phát hành.

## 1. Quyết định có thể đề nghị ngay

1. Giữ **dòng chứng từ**, **đơn vị được đặt** và **nhóm lựa chọn/hiển thị** là ba khái niệm riêng.
2. Mỗi đơn vị mà solver đặt có ID ổn định và được đối soát tới nguồn; không tách một bó hoặc tạo mass từng unit bằng phép chia tổng tùy ý.
3. Profile quy định **cấu hình nào có thể được dùng/kiểm và trong điều kiện nào**. Template/generator quy định **cách tạo candidate theo cấu hình đó**. Hai trách nhiệm phải tách.
4. Một candidate phải được validator kiểm độc lập với generator; lời khẳng định của generator rằng nó đã theo profile không thay validation.
5. Giữ `unsupported` tại intake/preflight. Chưa thêm bucket thứ tư vào phân hoạch PlanContent.
6. BOX/AABB được đánh giá bằng tính bảo thủ và khả năng phục vụ case, không chọn hay loại chỉ vì góc chụp ảnh.

Các tên field/record dưới đây là tên đề nghị phục vụ reconcile. Local phải đồng bộ chúng với wire format, persistence và lifecycle được chốt sau review; không import thẳng các ví dụ này vào schema v0.2.

## 2. Dòng nguồn không tự là một đơn vị vật lý

### 2.1 SourceLine — giữ đúng điều nguồn đã khai

| Nhóm thông tin | Nội dung tối thiểu | Điều không được tự suy |
|---|---|---|
| Nhận diện | source artifact ref/hash, sheet/page/span, sourceLineId, mô tả nguyên văn | Dòng cùng mô tả không tự là cùng lô hoặc cùng kiện |
| Số lượng | raw quantity, đơn vị đếm của nguồn, count đã chuẩn hóa nếu xác định được | “10” không tự có nghĩa 10 bó; có thể là chiếc, kiện, lô hoặc đơn vị khác |
| Mass | raw total/unit mass, đơn vị, basis và độ phân giải nguồn đã biết | Tổng line không tự chứng minh mass từng unit hoặc mass bằng nhau |
| Geometry | kích thước được khai theo line hay theo từng unit, hình thức đóng gói, nguồn đo/spec | Kích thước một thanh/ống không tự là kích thước bao của cả bó |
| Mapping | trạng thái mapping, IDs đã tạo, phần còn thiếu/xung đột/ngoài phạm vi | Số unit đã tạo phải đối soát với đúng đơn vị đếm, không với một con số bất kỳ |

Nếu nguồn ghi “2 bó, tổng 3,25 t” thì có thể xác nhận thông tin **của dòng** khi nguồn đủ. Nó chưa đủ để tạo hai CargoUnit mỗi bó 1,625 t. Dữ liệu vẫn hữu ích ở intake và đối soát, nhưng bước cần mass từng đơn vị phải chờ nguồn hoặc quy tắc được chấp thuận phù hợp.

### 2.2 HandlingUnit — đơn vị nguyên vẹn solver được đặt

| Trường/quan hệ đề nghị | Nghĩa cần chốt |
|---|---|
| `unitId` | ID của đơn vị được đặt, duy nhất trong manifest snapshot; ID do hệ thống cấp vẫn phải map đúng đơn vị nguồn |
| `sourceLineRef`, `sourceUnitIdentifier` | Nguồn gốc của unit và mã kiện nguồn nếu có; không bắt nguồn phải có mã giả để hợp schema |
| `cargoForm` | Hình thức hàng phục vụ phân loại, ví dụ nhóm thanh dài hoặc ống tròn; danh mục vận hành chỉ mở theo pilot đã xác nhận |
| `handlingUnitKind` | Một bó, một ống/chiếc, hoặc đơn vị nguyên vẹn khác được nguồn/quy trình xác định |
| `packagingSpecificationRef` | Khi cách bó/đóng kiện ảnh hưởng envelope hoặc profile; không suy sức bền dây bó từ tên BUNDLE |
| `geometrySpecificationRef` | Loại envelope/primitive, kích thước bao theo đơn vị, frame/yaw và nguồn; mức xấp xỉ được khai rõ |
| `massG` hoặc field mass đã được chốt | Giá trị cùng basis/nguồn/confirmation; tên grams phụ thuộc quyết định precision chung, không đổi ngầm `massKg` |
| `supportProfileRefs` | Các profile có thể xét; applicability vẫn do backend/validator đánh giá trong case |
| `displayTags`, `selectionGroupRefs` | Nhóm hiển thị và nhóm lựa chọn tách nghĩa; tag không tự tạo ràng buộc |

Một bó có thể chứa nhiều thanh/ống, nhưng các thành phần đó không được đồng thời tính như các đơn vị solver riêng nếu chúng chưa được tách theo quy trình thật. Số chiếc trong bó có thể là metadata truy vết; nó không được làm tổng mass hoặc số lượng placement bị tính hai lần.

Mass của unit cần làm rõ thành phần đã bao gồm theo nguồn: vật liệu đóng bó/đế gắn với kiện nếu có, và phần kê/chèn được tính riêng theo budget của case. Package không tự chuyển mọi phần này thành một basis pháp lý mới. Mục tiêu contract là không bỏ sót hoặc tính lại cùng khoản tải.

### 2.3 Khi nào được mở rộng một dòng thành nhiều units?

Cho phép mở rộng có kiểm soát khi nguồn xác nhận rõ:

- Đơn vị đếm và số lượng là gì.
- Mỗi unit dùng giá trị kích thước/mass nào; nếu cùng giá trị, nguồn thực sự xác nhận áp dụng cho từng unit.
- Có cách định danh/mapping từng unit trong quá trình xếp và đối soát.
- Tổng được kiểm lại và sai khác với tổng nguồn được xử lý theo policy có nguồn, không sửa mass để ép tổng khớp.

Không dùng từ “đồng nhất” để tự suy các bó nặng bằng nhau. Các bước nhập lặp có thể giúp người dùng nhanh hơn nhưng không tạo ra chứng cứ mới. Trường hợp chỉ biết total và muốn sử dụng cận mass hoặc một aggregate đặc biệt cần contract chuyên biệt; chưa tự bật trong MVP.

### 2.4 Ví dụ hoàn toàn synthetic để diễn giải semantics

Ví dụ dưới đây **không phải payload hợp schema v0.2**, không có dữ liệu thật hoặc giá trị kê/chồng. Toàn ví dụ có `testOnly=true`.

| Nội dung | Giá trị giả lập |
|---|---|
| SourceLine `SYN-L1` | 2 bó; total = 3.250.000 g |
| Unit `SYN-U1` | Một bó, mass riêng được ví dụ khai = 1.500.000 g |
| Unit `SYN-U2` | Một bó, mass riêng được ví dụ khai = 1.750.000 g |
| Geometry/profile | Chưa có trong ví dụ |
| Đối soát mass line | Đúng: tổng hai unit = total |
| Quyền sinh/chọn phương án | Chưa đủ: còn thiếu geometry/profile và mọi điều kiện dữ liệu vận hành |

Nếu xóa hai mass riêng khỏi ví dụ và chỉ giữ total, hệ thống không được tự tái tạo chúng. Đối soát tổng thành công cũng không chứng minh các giá trị đã đúng thực tế hoặc đủ để sinh phương án.

## 3. Group semantics phải được tách theo mục đích

### 3.1 Phân loại đề nghị

| Khái niệm | Ý nghĩa | Không kéo theo |
|---|---|---|
| Nhóm hiển thị/lô nguồn | Tìm kiếm, lọc, màu, thống kê | Không bắt đi đủ hoặc nằm cạnh nhau |
| Nhóm `ALL_OR_NONE` | Chọn toàn bộ các unit của nhóm hoặc không chọn unit nào | Không tự buộc cùng lớp, cùng vùng hay kề nhau |
| Ràng buộc không gian | Ví dụ cùng vùng/cùng lớp/giới hạn khoảng cách nếu nghiệp vụ thật cần | Phải có predicate/đơn vị/oracle riêng; chưa có thì không hứa tính năng |
| Arrangement instance | Một bố trí candidate có cấu trúc, giữ placement và IDs con | Không tạo thêm mass ngoài các units hoặc biến nhóm thành một kiện mới |

Đề nghị để vòng đầu dễ kiểm: mỗi unit thuộc tối đa một selection group ALL_OR_NONE; các display tags có thể nhiều. Nếu nguồn/pilot yêu cầu nhóm lựa chọn chồng nhau, local nêu delta và semantics rõ trước khi mở hỗ trợ. Đây là giới hạn mô hình đề nghị, không phải nhận định schema v0.2 đã thực thi điều đó.

### 3.2 Tập required/optional/excluded

Trong một LoadingCase đã xác nhận, các unit thuộc một nhóm ALL_OR_NONE phải có cách phân loại nhất quán. Nếu người dùng phân loại một phần required, một phần optional/excluded, UI có thể đề xuất cách giải quyết nhưng backend phải từ chối snapshot còn xung đột; không tự thay đổi phạm vi mà không cho người dùng thấy.

- Nhóm required: toàn bộ thành viên phải được placed để đạt fulfillment.
- Nhóm optional: generator/solver có thể chọn cả nhóm hoặc không chọn; không lấy một phần để tăng objective.
- Nhóm excluded: phải là quyết định scope có chủ thể/nguồn phù hợp; không phải lối chuyển một nhóm required bị lỗi thành “không cần xét”.

Sau khi case đủ điều kiện, ba tập kết quả vẫn là placed/unplaced/excluded. `unsupported` là nguyên nhân cần xử lý ở intake/preflight; nó không tự tạo một tập kết quả mới hoặc có nghĩa “không đủ chỗ”.

## 4. Profile cho phép kiểm khác template có thể sinh

### 4.1 SupportQualification/Profile

Profile là **dữ liệu điều kiện và phạm vi chấp thuận**, không phải một thuật toán sinh bố trí. Mẫu nội dung cần có:

| Nhóm | Nội dung cần biểu diễn | Nguồn chịu trách nhiệm |
|---|---|---|
| Identity/version | Ref/hash, loại profile, phạm vi, trạng thái hiệu lực theo receipt | Registry/lifecycle; không tin một nhãn APPROVED tự khai |
| Applicability | Cargo form, handling-unit kind, cách đóng bó, dải geometry/mass có nguồn | Hồ sơ kỹ thuật/quy trình được review |
| Trên–dưới | Các cặp tương thích có chiều, hướng và loại nền/đỡ | Người có thẩm quyền xác định; không suy tính đối xứng |
| Support pattern | Kiểu kê/đỡ/chèn, vùng hoặc quy luật bố trí kiểm được, khe/nhô/multi-support được phép | Profile đã review, không lấy từ ảnh để điền số |
| Limits/basis | Tầng, chiều cao, tải phía trên/stack và cách tính theo nguồn, phần kê đã bao gồm hoặc đã dành | Nguồn rating/allowance phù hợp, có đơn vị và basis |
| Conditions | Điều kiện chống lăn, chèn, khoảng hở và kiểm tra bắt buộc | Chuyên môn; tách điều kiện machine-checkable và external review |
| Coverage/exclusions | Điều đã kiểm và chưa kiểm, loại load case/scenario được bao phủ | Không mặc định profile static cargo bao phủ tải máy/tải động |
| Review binding | Nguồn, danh tính/thẩm quyền, phạm vi, hiệu lực và điều kiện kiểm lại | Theo contract review bên ngoài/đúng role được chốt |

Nếu một điều kiện chỉ có thể được xác nhận tại hiện trường, profile phải mô tả điều kiện và loại bằng chứng cần có. Không dùng boolean placeholder để diễn đạt máy đã kiểm một điều nó không tính được.

### 4.2 ArrangementTemplate / GeneratorDefinition

Template/generator là **cách tạo các candidate trong phạm vi đã định nghĩa**. Nội dung tối thiểu để đánh giá khả năng sinh:

| Nhóm | Nội dung cần pin |
|---|---|
| Binding | Template version/hash, profile refs và loại geometry được hỗ trợ |
| Input contract | Unit pool/nhóm được nhận, attributes bắt buộc, scope required/optional và điều kiện từ chối |
| Construction rules | Quy tắc hàng/lớp/slots, frame, anchors, transforms/yaw và thứ tự dựng có định nghĩa |
| Parameter bounds | Những tham số generator được phép thay đổi và cận từ profile/geometry; không dùng cận mặc định thiếu nguồn |
| Unit expansion | Mapping từ một arrangement sang toàn bộ child unit IDs và placements; không bỏ child hoặc tính mass nhóm thêm lần nữa |
| Support derivation | Quy tắc tạo support relations dự kiến để validator kiểm độc lập |
| Build/runtime | Implementation/build ID, seed nếu có, time/candidate budget, cancellation và tie-break theo contract solver |
| Coverage | Tập cấu hình generator thật sự tìm; có hữu hạn/đầy đủ trong miền đã khai hay là heuristic; điều kiện báo chưa tìm thấy |
| Validation handoff | Candidate payload có thể được một checker độc lập đọc và kiểm lại |

Phép mở rộng một template instance thành placements phải xác định được từ đúng inputs, tham số và implementation version đã pin. Thuật toán tìm/chọn giữa các instance có thể là heuristic hoặc dùng seed; time limit có thể ảnh hưởng candidate cuối. Vì vậy tái lập phép dựng hình từ một instance khác với cam kết mọi lần solve theo thời gian thực trả cùng một nghiệm.

Template không nên chứa mã script/expression tùy ý để eval từ chứng từ hoặc profile. Thuật toán và kiểu tham số nằm trong implementation được quản lý version; hồ sơ kỹ thuật chỉ cấp dữ liệu/điều kiện được phép sử dụng.

Một profile có thể đủ để kiểm một bố trí do người dùng nhập nhưng chưa có generator thực hiện được. Khi đó phải báo **thiếu khả năng sinh tự động cho cấu hình ấy**, không nói profile vô hiệu hoặc hàng chắc chắn không xếp được.

### 4.3 ArrangementInstance / Candidate

Candidate được tạo cần pin case, generator/template/profile versions, input units và các placement con. Validator tính lại mass, partition, containment, collision, support và rule coverage; không chấp nhận tổng hoặc graph chỉ vì generator đã gửi.

Manual edit có thể làm candidate ra ngoài cấu trúc template gốc nhưng vẫn cần được đánh giá bằng rule/profile. Nếu engine chỉ kiểm được template đã khai, phải báo giới hạn ấy thay vì tự cho phép một bố trí tự do. Bản sửa tạo version/validation mới và không kế thừa proof tối ưu của run.

## 5. Các trục đủ điều kiện độc lập

Không dùng một boolean “supported” cho tất cả các bước.

| Trục/đánh giá | Câu hỏi | Có nghĩa gì nếu đạt? |
|---|---|---|
| Dữ liệu | Unit/case đã đủ nguồn, confirmation và values cần thiết chưa? | Đủ điều kiện dữ liệu theo policy; chưa chứng minh placement nào đúng |
| Applicability | Profile/rules có đúng loại unit, range, vùng, thời gian và scenario không? | Được xét trong phạm vi profile; chưa phải mọi cách xếp đều hợp |
| Model support | Validator có biểu diễn và kiểm được shape/support pattern/constraints này không? | Có thể nhận candidate để kiểm, không tự kết luận candidate hợp |
| Generation capability | Có generator/template implementation nhận bộ dữ liệu này không? | Có thể bắt đầu tìm trong miền được công bố, không bảo đảm sẽ tìm thấy |
| Candidate validity | Candidate cụ thể vượt các phép kiểm áp dụng chưa? | Kết quả theo đúng snapshot/mô hình/coverage; còn các điều kiện quyết định riêng |
| Fulfillment/value | Có đáp ứng required và mục tiêu nghiệp vụ của case không? | Có căn cứ xét lựa chọn/giá trị của phương án, không tự cấp field approval |

Hệ quả cần thể hiện rõ trong lỗi và UI:

- Đủ geometry nhưng thiếu profile: có thể lưu/xem/chẩn đoán, chưa đủ cho bước cần support đã kiểm.
- Đủ dữ liệu và profile, model kiểm được nhưng chưa có generator: có thể xét luồng nhập bố trí/kiểm thủ công được phép; không tuyên bố đã có auto-planning.
- Có generator nhưng hết thời gian: SEARCH_LIMIT/TIME_LIMIT, không phải proof vô nghiệm.
- Có bố trí tham chiếu được review nhưng model không biểu diễn được: MODEL_LIMIT, cần đánh giá model; không đổ cho solver.
- Reference chưa có nguồn/điều kiện đủ: DATA_OR_REVIEW_GAP; chưa dùng nó làm oracle physical feasibility.

Đây là semantics đề nghị. Tên enum lỗi chính xác cần được đồng bộ trong bảng lifecycle/API chung trước freeze.

## 6. BOX/AABB: chính xác về điều được chứng minh

### 6.1 Bảo thủ về containment

Gọi A là miền sử dụng thực đã được xác minh trong scope, H là miền mô hình, O là vùng chiếm chỗ của cargo. Hướng bảo thủ đề nghị là H nằm trong A sau khi xét các giới hạn có nguồn; O nằm trong H cùng clearance/exclusions thì mới có căn cứ chấp nhận phần containment của mô hình.

Hình hộp bao **bên ngoài** một hầm không vuông không tự là H hợp lệ. Kiểm tâm hoặc một số điểm tùy chọn không thay containment của toàn occupied volume. Cách kiểm vertices chỉ được dùng khi tính chất của lớp hình học làm nó đủ; không áp nó ngầm cho mọi vùng không lồi/có lỗ hoặc vật cản.

Mô hình phải có frame, biên theo cao độ cần xét, exclusions và quy tắc clearance dùng chung giữa solver, validator, viewer, export. Pairwise gap và margin với hầm cần được định nghĩa riêng để không cộng hai lần cùng khoản khoảng hở. Precision/phương pháp đo/margin có nguồn được xử lý theo contract đo lường riêng; không tăng hầm hoặc thu nhỏ cargo bằng epsilon để làm PASS.

### 6.2 Bảo thủ không có nghĩa đủ hữu ích

Một H rất nhỏ có thể tránh vượt biên nhưng không phục vụ pilot. Do đó đánh giá hai câu riêng:

1. Mô hình có loại bỏ kết quả vượt giới hạn hay không?
2. Mô hình có giữ đủ các cấu hình cần thiết của case đại diện để tool có giá trị không?

Với ống tròn, các AABB có thể giao nhau dù hai tiết diện tròn không giao nhau. Ví dụ toán học không đơn vị, không phải dữ liệu tàu: hai đường tròn bán kính 10, tâm (0,0) và (10,18) có bình phương khoảng cách tâm 424, lớn hơn 400 nên không giao nhau; hộp bao của chúng vẫn giao nhau trong hình chữ nhật từ (0,8) đến (10,10). Điều này chỉ chứng minh một khả năng false rejection của representation, không khẳng định một cách xếp ống thực là được phép.

Nếu pilot cần cấu hình đó, các lựa chọn cần so là: shape-aware primitive trong phạm vi đã chốt, hoặc arrangement/template có geometry và units con đầy đủ. Không giải bằng cách cho overlap bất kỳ; cũng không mặc định phải xây general mesh/physics engine.

## 7. Phần cần dữ liệu/owner, và phần đội kỹ thuật tự làm

### Cần owner/nguồn chuyên môn

- Chọn pilot new loading hay occupied/replan, và loại hàng bắt buộc.
- Cung cấp một manifest/bố trí nguồn đại diện để xác định ý nghĩa dòng và đơn vị.
- Xác nhận quan hệ xếp nhiều tầng/mixed vertical thực sự cần, ai có nguồn profile và các điều kiện thao tác/tải tạm liên quan.
- Xác nhận mục tiêu chuyến: hàng bắt buộc, phần được lựa chọn/loại và tiêu chí giá trị công việc.

### Đội kỹ thuật có thể đề nghị/đối chiếu ngay

- Tách record, group semantics, eligibility axes và error reasons.
- Lập mapping dữ liệu nguồn còn thiếu và prototype contract có nhãn synthetic rõ.
- Xác định dữ liệu cần cho profile checker và generator theo mẫu ở trên.
- Chuẩn bị phương pháp oracle, kiểm containment và benchmark theo tài liệu acceptance đi kèm.

Không yêu cầu owner quyết định serializer, kiểu generator, cấu trúc repo hoặc viết oracle. Không dùng thiếu một profile thật làm lý do trì hoãn mọi phân tích contract; nhưng profile chưa có vẫn chặn kết luận về những cấu hình phụ thuộc nó.

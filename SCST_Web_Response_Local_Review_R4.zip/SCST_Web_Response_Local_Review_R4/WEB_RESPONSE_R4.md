# Phản hồi R4 — xử lý báo cáo local trước Final Baseline

**Ngày:** 31-10-2026. **Đầu vào:** SCST-REVIEW-0.3 và LOCAL_REVIEW_REPORT ngày 31-10-2026.  
**Trạng thái:** REVIEW_RESPONSE / PROPOSED_FOR_RECONCILIATION. Các quyết định dưới đây là disposition và đề nghị của Web Agent; chưa thay quyết định owner, kết luận chuyên môn hoặc schema/backend đang chạy.

## 1. Kết luận

Tôi đồng ý với kết luận local: **chưa chốt Final Baseline**. Báo cáo đã phân biệt đúng giữa tài liệu/reference hiện có và phần mềm vận hành chưa được xây; đồng thời phát hiện một lệch nguồn CVF cần giải quyết trước khi nhận định về tích hợp.

Phần cần tiến thêm đã rõ hơn sau vòng này: chọn một case đầu vào đại diện, reconcile các contract có trạng thái/hành động cụ thể, xác định nguồn CVF được chọn và bằng chứng tương ứng. Các đề nghị kỹ thuật R4 đã được viết để local có thể chấp nhận, yêu cầu sửa hoặc bác bỏ từng điểm có lý do.

Giữ phạm vi Tool-first, một người dùng chính trên PC local, core chạy khi AI tắt; frontend và backend tách trách nhiệm trong cùng sản phẩm. CVF kiểm soát những Agent actions được bật, trong khi backend authorization và cargo validator giữ quyền quyết định của chúng. Không có căn cứ từ báo cáo này để chuyển thành hệ thống điều hành cảng hoặc buộc xây mô hình vật lý tổng quát.

## 2. Bằng chứng hiện có nói được đến đâu?

| Nguồn | Điều Web đã nhận/đối chiếu | Giới hạn |
|---|---|---|
| LOCAL_REVIEW_REPORT.md | Đọc báo cáo, xác định các kết luận, đề nghị và đường dẫn evidence | Chưa có thư mục raw log/receipt local được báo cáo liên kết |
| Kết quả Windows trong báo cáo | Local báo checksum v0.3 35/35, v0.2 65/65, 86 reference tests đạt và bốn probes `[true,true,true,false]` | `LOCAL_REPORTED`; Web chưa độc lập kiểm các log Windows của lần đó |
| Evidence web R3 đã đóng gói | Có trong v0.3 nguyên bản, đúng phạm vi reference/schema và kiểm bytes | Không đổi thành test backend/UI/CVF/hiện trường; R4 không chạy lại để cộng số |
| Ba ảnh | Quan sát hàng nhiều nhóm/nhiều cao độ và thiết bị ở ảnh 1 theo bản đã nhận | Không có kích thước, mass, support/rating hoặc chứng nhận an toàn; chưa xác nhận là ba case độc lập |
| CVF | Hai repo/SHA khác nhau được baseline và local report nêu | Web chưa đọc được source/license đúng revision; lỗi truy cập không chứng minh repo không tồn tại |
| Tài liệu chuyên ngành/đo lường | Có registry nguồn chính thức, edition, mức truy cập và giới hạn | Chưa xác định applicability, thông số hay profile của phương tiện thực |

Xem [evidence/EVIDENCE_AVAILABILITY.md](evidence/EVIDENCE_AVAILABILITY.md). Việc bổ sung log local giúp đối chứng nguồn chạy, không tự làm phát sinh bằng chứng nghiệm thu ứng dụng.

## 3. Các đề nghị kỹ thuật được cụ thể hóa

### 3.1 Dòng manifest, đơn vị xếp và nhóm

Giữ ba lớp: dòng nguồn khai gì; đơn vị nguyên vẹn mà solver được đặt là gì; nhóm phục vụ lựa chọn/hiển thị có ý nghĩa gì. Một dòng có số bó và tổng mass chưa đủ để sinh mass từng bó bằng phép chia. Chỉ mở rộng thành các unit cùng thuộc tính khi nguồn thực sự xác nhận các giá trị đó áp dụng cho từng unit.

`ALL_OR_NONE` nghĩa là chọn cả nhóm hoặc không chọn; nó không tự buộc các kiện nằm cạnh nhau. Ràng buộc cùng lớp/cùng vùng cần predicate riêng nếu pilot yêu cầu. R4 đề nghị selection groups không chồng nhau ở vòng đầu; đây là lựa chọn mô hình cần local đối chiếu, không phải mô tả schema lịch sử đã có.

`unsupported` tiếp tục là trạng thái cần xử lý ở intake/preflight. Không được làm mất dòng nguồn, tạo bucket plan thứ tư hoặc tự chuyển hàng required thành excluded để solver chạy được.

Chi tiết: [contracts/02_CARGO_PROFILE_TEMPLATE.md](contracts/02_CARGO_PROFILE_TEMPLATE.md), mục 2–3.

### 3.2 Profile kiểm cấu hình và template sinh cấu hình

Local chỉ đúng một thiếu sót đáng kể: **có profile để kiểm không chứng minh đã có cách tự động sinh phương án theo profile đó**.

R4 đề nghị tách:

- Profile: đối tượng/phạm vi áp dụng, cặp trên–dưới có chiều, kê/chèn/chống lăn, limits/basis, coverage và nguồn review.
- Template/generator: input nhận được, quy tắc dựng hàng/lớp/slots, tham số được thay, child unit IDs/placements, support derivation, build/config và miền tìm kiếm.
- Validator: kiểm lại candidate theo đúng input/model/profile; không tin tổng, graph hoặc nhãn hợp lệ do generator tự khai.

Không tự cấp rating trong mẫu profile. Các điều kiện chỉ kiểm được ở hiện trường được giữ đúng coverage và review requirement. Nếu một core-hard predicate bắt buộc chưa có nguồn hoặc chưa biểu diễn được, nó vẫn chặn hành động phụ thuộc.

Sáu trục cần tách là: dữ liệu, applicability, khả năng biểu diễn/kiểm, khả năng sinh, validity của candidate và fulfillment/giá trị nghiệp vụ. Điều này tránh một cờ “supported” che mất chỗ còn thiếu.

### 3.3 BOX/AABB được đánh giá bằng case

BOX có thể dùng khi là miền **nằm trong vùng hữu dụng được xác minh** ở toàn chiều cao/occupied volume liên quan. Hộp bao ngoài hầm hoặc phép kiểm tâm không đủ. Cùng geometry/frame/exclusions/clearance phải được dùng xuyên solver, validator, viewer và export.

Tính bảo thủ và tính hữu ích cần kiểm riêng. Với hàng tròn, bounding boxes có thể chồng nhau trong khi primitives không giao nhau; đây là khả năng false rejection của representation. Nếu cấu hình cần cho pilot bị mất, cần xem primitive/template phù hợp. Không nới overlap bằng epsilon để che giới hạn mô hình.

R4 đề nghị phân biệt bốn nguyên nhân: `DATA_OR_REVIEW_GAP`, `MODEL_LIMIT`, `SEARCH_LIMIT`, `CONSTRAINT_VIOLATION`. Khi reference đủ căn cứ nhưng model không diễn đạt được, tăng thời gian solver không xử lý được nguyên nhân. Khi reference diễn đạt và kiểm được nhưng solver chưa tìm thấy, đó mới là vấn đề khả năng sinh/tìm kiếm trong budget.

### 3.4 Ma trận trạng thái, quyền và giao dịch

Đã bổ sung ma trận 16 nhóm record theo cấu trúc local yêu cầu, gồm cả template/generator và binding tại lúc dispatch:

**Record → lifecycle → action → principal → preconditions → evidence → transaction → failure/recovery.**

Các invariant được đề nghị gồm: actor lấy từ backend; critical field coverage gắn đúng value/source/snapshot; content bất biến tách receipts và projection; refs không tạo vòng hash; idempotency và optimistic concurrency; run cũ không ghi đè selection mới; blob hoàn chỉnh trước DB commit; restore kiểm đủ dependency và đánh giá lại current authorization/review.

Đây là nghĩa vụ thiết kế và kiểm chứng, chưa là API hoặc migration đã hiện thực. Phần DB/blob dùng tài liệu chính thức SQLite làm căn cứ xác định ranh giới; giao thức cụ thể là đề nghị SCST và cần local kiểm trên filesystem/OS mục tiêu. Xem [contracts/01_RECORD_ACTION_MATRIX.md](contracts/01_RECORD_ACTION_MATRIX.md), mục 8 và các URL nguồn tại đó.

### 3.5 External review phải vận hành được

Giữ riêng người review chuyên môn bên ngoài, người ghi nhận hồ sơ trong app và người được giao đối chiếu. Một account operator không tự đại diện cho reviewer ký hồ sơ.

Đề nghị review policy xác định đúng phương thức có thể làm thật: registry nếu đơn vị có, xác nhận từ issuer/reviewer, hoặc đối chiếu thủ công được quy trình đơn vị chấp nhận. Mỗi cách cần nguồn, subject/version, phạm vi, thời điểm và trigger kiểm lại. Không mặc định cần một online revocation service; cũng không suy “không bị thu hồi” từ việc app chưa ghi nhận thông báo.

Đây là điều chỉnh về hành vi cần reconcile với v0.3: khi core input/profile/validation đã đủ, hồ sơ review riêng cho field use còn chờ vẫn cho phép lập, sửa, so sánh, chọn **sơ bộ** theo policy và xuất hồ sơ planning có coverage rõ. Điều còn thiếu chặn đúng claim/hành động phụ thuộc. Thiếu profile bắt buộc của core vẫn chặn sử dụng cấu hình đó; không chuyển hard constraint sang review ngoài để mở nút.

### 3.6 Grams giải quyết biểu diễn; nguồn số đo vẫn phải rõ

Tiếp tục đề nghị integer grams cho mass, với conversion decimal exact, locale rõ, kiểm miền số/tổng/trung gian và mọi mass/limit/reserve đồng nhất đơn vị. Việc chuyển `massKg` sang `massG` cần schema/hash/lineage/receipt mới; không đổi ý nghĩa field cũ hoặc giữ receipt cũ trên nội dung mới.

Phần bổ sung từ local được tiếp thu: độ phân giải số nguyên của phần mềm không nói được độ chính xác của cân hoặc số đo hầm. JCGM VIM phân biệt measurement uncertainty và resolution; xem mục 2.26/4.14 tại [nguồn BIPM](https://www.bipm.org/documents/20126/2071204/JCGM_200_2012.pdf).

R4 đề nghị giữ raw/source/method, resolution được nguồn khai, uncertainty/bound khi có, và margin theo mục đích/nguồn. Thiếu thông tin ghi `NOT_STATED`, không mặc định bằng 0 hoặc ±1 g/±1 mm. Tách measurement allowance, operational clearance và mất không gian do xấp xỉ để không tính hai lần. Chi tiết ở [contracts/03_MASS_MEASUREMENT.md](contracts/03_MASS_MEASUREMENT.md).

## 4. Nguồn CVF là một nhánh quyết định riêng

Baseline pin `Controlled-Vibe-Framework-CVF-Provenance` tại SHA `ebf31b9f5c42e4de58f40a434409c3441a5d8383`. Local báo checkout `Controlled-Vibe-Framework-CVF` tại SHA `15e39450853184eb65dbde73398c69c3171a6241`. Đây là hai nhận diện khác nhau; chưa có căn cứ coi chúng tương đương hoặc kết luận chắc chắn không tương thích.

Web đã thử các URL nguồn/commit/license; chưa truy cập được nội dung đúng revision. Vì vậy giữ `BLOCKED_BY_SOURCE` và `NOT_VERIFIED` cho API/export/guards/license của pin. License public do local báo chưa được gán sang Provenance.

Cách đóng: xác nhận nguồn thực sự muốn dùng; nhận source/revision/license có căn cứ qua quyền đọc hoặc gói được phép chia sẻ; nếu đổi nguồn thì ghi quyết định thay pin và kiểm tác động. Sau đó mới mapping API, guards và integration tests. Không sửa CVF core hoặc tự tạo API canonical để lấp khoảng trống.

CVF chưa đủ nguồn chặn phần Agent integration phụ thuộc nó. Review và thiết kế core AI-off vẫn tiếp tục. Nếu yêu cầu MVP bắt buộc có Agent ngay từ đầu, owner cần nhận diện phụ thuộc này trong phạm vi; R4 không tự loại CVF khỏi sản phẩm.

Chi tiết và nguồn license chính thức đã đọc: [research/01_CVF_SOURCE_LICENSE.md](research/01_CVF_SOURCE_LICENSE.md).

## 5. Điều kiện freeze khác điều kiện nghiệm thu sản phẩm

Không yêu cầu có ứng dụng nghiệm thu xong mới chốt yêu cầu để xây ứng dụng. Mục tiêu trước freeze là đủ căn cứ chọn phạm vi, mô hình và contract có thể kiểm.

| Trước khi chốt phần baseline liên quan | Phần được kiểm sau implementation |
|---|---|
| Pilot hầm trống hay occupied/replan, cargo/handling units và mục tiêu chuyến rõ | Backend thực thi đúng case/partition và không mất dữ liệu |
| Ít nhất một case đầu vào đại diện đủ để đánh giá mô hình | Các case nghiệm thu được chạy trên phần mềm thật |
| Model/profile/template diễn đạt được cấu hình cần; giá trị còn thiếu có nguồn cung và gate rõ | Generator tạo candidate; validator/oracle đối chiếu; fidelity nghiệp vụ đạt |
| Record/lifecycle/action policy và compatibility được reconcile | Auth, transaction, concurrency, stale/replay, recovery và migration chạy đúng |
| Quy trình nhận/đối chiếu review thực có thể làm | Evidence/binding/lifecycle và UX không đánh đồng review với confirmation dữ liệu |
| Nguồn CVF và phạm vi Agent được quyết định rõ cho phần phụ thuộc | G4b/guards/bridge được kiểm bằng runtime đúng bản |
| Protocol case/oracle/rubric và cách chốt ngưỡng rõ | Performance/UI/export đạt ngưỡng đã pin trên workload/máy thực |

Giữ tách Technical Proof, MVP nghiệp vụ và chấp thuận một phương án/chuyến. Hai case độc lập cùng case âm tính là đề nghị nghiệm thu MVP của dự án sau khi có ứng dụng; không được gọi là chuẩn ngành hoặc xem ba ảnh đã đáp ứng chúng.

## 6. Việc cần trả lại ở vòng local tiếp theo

1. Disposition các proposal R4 theo ID, với lý do và tác động tương thích; tập trung điểm chưa reconcile thay vì lặp lại kết luận đã thống nhất.
2. Ma trận record/action đã đối chiếu vào domain/wire/lifecycle/persistence dự kiến; không chỉ thay version string.
3. Đính kèm thư mục evidence local đã được báo cáo; giữ receipt gốc, command, input/dependency/output hashes và môi trường thực.
4. Nhận diện nguồn CVF đang chọn cùng source/license evidence; nếu thiếu thì giữ blocked, không suy API từ repo khác.
5. Lập hồ sơ một case đầu vào đại diện từ dữ liệu owner cung cấp, chỉ rõ chỗ chưa có nguồn/profile. Đội kỹ thuật tự chuẩn bị oracle và phép đánh giá model.
6. Trả bản đề nghị điều kiện nào đủ để freeze, điều kiện nào còn chờ và người/nguồn có thể đóng. Chưa dựng roadmap/treeview hoặc triển khai trong work order này.

Các câu hỏi nghiệp vụ được gộp tại [DECISIONS_AND_INPUTS.md](DECISIONS_AND_INPUTS.md); yêu cầu giao việc đầy đủ tại [NEXT_LOCAL_REVIEW.md](NEXT_LOCAL_REVIEW.md). Không yêu cầu owner chọn serializer, thuật toán hay viết bộ test kỹ thuật.

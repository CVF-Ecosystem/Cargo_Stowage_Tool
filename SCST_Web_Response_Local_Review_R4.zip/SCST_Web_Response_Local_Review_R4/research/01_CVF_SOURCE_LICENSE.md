# W-06 — nguồn CVF, revision và điều kiện dùng

Ngày kiểm: **31-10-2026 (Asia/Ho_Chi_Minh)**. Loại tài liệu: `REVIEW_RESPONSE`, bổ sung cho SCST-REVIEW-0.3; chưa phải baseline mới hoặc quyết định triển khai. Phạm vi: đối chiếu nguồn; không thay checkout, cài dependency hoặc chạy CVF.

## 1. Kết luận

**Giữ `BLOCKED_BY_SOURCE` cho nguồn Provenance mà baseline pin.** Chưa xác minh độc lập API, exports, guards, dependencies hoặc license tại revision đó. Không thay nguồn pin bằng public checkout khác chỉ vì tên gần giống. Việc thiếu source đúng bản chặn kết luận G4b/CVF integration; không chặn các phần review SCST độc lập hoặc việc thiết kế core AI-off.

Hai mốc hiện phải giữ riêng:

| Vai trò | Repo và commit | Mức bằng chứng |
|---|---|---|
| Mốc baseline muốn đối chiếu | `Blackbird081/Controlled-Vibe-Framework-CVF-Provenance` @ `ebf31b9f5c42e4de58f40a434409c3441a5d8383` | Có trong v0.2 docs/04 và docs/07; source chưa truy cập được ở vòng web |
| Checkout local báo cáo đang có | `Blackbird081/Controlled-Vibe-Framework-CVF` @ `15e39450853184eb65dbde73398c69c3171a6241` | Do LOCAL_REVIEW_REPORT mục 6.1 báo cáo; raw logs/receipt local chưa có trong tệp đính kèm của vòng này |

`git cat-file` không tìm thấy mốc Provenance trong public clone, theo local report, chỉ nói clone đó chưa có object. Nó không chứng minh commit không tồn tại trên nguồn khác. Repo khác, commit khác và license khác không được tự xem là tương đương.

## 2. Truy cập web đã thử và giới hạn quan sát

| URL | Kết quả công cụ web | Điều được phép kết luận |
|---|---|---|
| https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance | DisabledError | Không lấy được nội dung qua công cụ; không xác nhận 404, private hay repo không tồn tại |
| https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/tree/ebf31b9f5c42e4de58f40a434409c3441a5d8383 | DisabledError | Chưa thấy tree của revision pin |
| https://raw.githubusercontent.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/ebf31b9f5c42e4de58f40a434409c3441a5d8383/LICENSE | DisabledError | Chưa đọc được LICENSE đúng revision Provenance |
| https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF/blob/15e39450853184eb65dbde73398c69c3171a6241/LICENSE | DisabledError | Chưa đọc được LICENSE đúng public revision từ web |
| https://raw.githubusercontent.com/Blackbird081/Controlled-Vibe-Framework-CVF/15e39450853184eb65dbde73398c69c3171a6241/LICENSE | DisabledError | Như trên; không độc lập xác nhận nội dung mà local đã báo |
| https://api.github.com/repos/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/commits/ebf31b9f5c42e4de58f40a434409c3441a5d8383 | Not accessible via this tool | Chưa có commit object từ endpoint công khai |
| https://api.github.com/repos/Blackbird081/Controlled-Vibe-Framework-CVF/contents/LICENSE?ref=15e39450853184eb65dbde73398c69c3171a6241 | Not accessible via this tool | Chưa có license bytes/blob SHA |

Search nguồn GitHub cho thấy metadata repo public trong trang topic agent-governance (https://github.com/topics/agent-governance?l=typescript&o=asc&s=stars). Metadata đó không xác nhận commit pin, API hay LICENSE. Không dùng các kết quả có từ “Provenance” nhưng thuộc tác giả/dự án khác làm nguồn CVF.

Không có source bytes hoặc license-file SHA được web xác minh trong lượt này. Không tạo hash đại diện giả.

## 3. License: điều đã đọc trực tiếp và điều còn chưa biết

Local báo LICENSE public checkout là CC BY-NC-ND 4.0. Vòng web đọc được **legal code chính thức của Creative Commons**, nhưng chưa đọc được LICENSE repo tại revision được báo; do đó không gán license đó cho nguồn Provenance.

Nguồn gốc: https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode.en (Sections 1(h), 2(a), 3(a)); trang tóm tắt: https://creativecommons.org/licenses/by-nc-nd/4.0/.

Tóm tắt giới hạn: CC BY-NC-ND 4.0 gắn NonCommercial với mục đích lợi thế thương mại hoặc bồi hoàn tiền. Quyền cấp phép phân biệt sao chép/chia sẻ nguyên liệu được cấp phép với tạo/sao chép nhưng không chia sẻ bản phái sinh, trong phạm vi phi thương mại; việc chia sẻ có điều kiện ghi công. Do đó “dùng nội bộ”, “không bán” hoặc “không sửa core” chưa tự xác định quyền tích hợp. Phải đối chiếu đúng source, điều kiện cấp phép và cách dùng. Đây chưa phải kết luận SCST được phép hoặc bị cấm tích hợp.

Không yêu cầu đổi license hay suy đoán một adapter là/không là derivative. Cần kiểm cùng source revision và quyền của chủ sở hữu trước quyết định tích hợp/phân phối.

## 4. Đường xử lý hợp lệ, tối thiểu

1. Xác nhận **mốc Provenance có phải nguồn thực sự muốn dùng** hay chỉ là tham chiếu cần sửa. Đây là quyết định nguồn của dự án, không phải tự động đổi sang public repo.
2. Nếu tiếp tục dùng Provenance, cung cấp quyền đọc hợp lệ hoặc gói nguồn được phép chia sẻ từ đúng revision, kèm bằng chứng commit/tree và LICENSE/NOTICE tại revision ấy. Một ZIP đặt tên bằng SHA chưa tự chứng minh nó chứa đúng commit.
3. Nếu chọn public revision khác, ghi change proposal: lý do thay nguồn, actual SHA, provenance, license/permissions, khác biệt API/guards/runtime và tác động adapter. Chỉ sau khi quyết định nguồn được chấp nhận mới kiểm tương thích theo mốc mới.
4. Local có thể bổ sung bằng chứng đọc nguồn đang có: remote đã loại credential, HEAD, working-tree status, LICENSE/NOTICE tại SHA, file tree, package/lockfiles và API exports/mandatory guard registration liên quan. Đây là inventory, không phải integration test.
5. Sau khi nguồn/điều kiện dùng được giải quyết, xác minh thực read/deny/bounded action, timeout/malformed/ESCALATE/replay/false ALLOW và authority backend. Chưa chạy thì giữ NOT_RUN.

Trong thời gian chờ, giữ Agent mutation capability tắt. Không hiển thị “CVF integrated” hoặc dựng API canonical từ protocol SCST đề xuất. Không sửa CVF core để làm adapter test đi qua.

## 5. Điều kiện đóng W-06

W-06 đóng phần source/license khi có nguồn được lựa chọn rõ, đúng revision và bằng chứng license/permission tương ứng. G4b chỉ đóng sau kiểm runtime/guards thật; việc đọc được repo không tự đóng G4b. Phần review core/manual không cần bị treo vì nguồn CVF chưa giải quyết.

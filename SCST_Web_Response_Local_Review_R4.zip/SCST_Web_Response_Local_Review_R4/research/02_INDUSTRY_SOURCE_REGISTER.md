# Nguồn chuyên ngành và phạm vi sử dụng — W-08

Ngày kiểm: **31-10-2026**, múi giờ trình bày hồ sơ Asia/Ho_Chi_Minh. Đây là nghiên cứu phục vụ thiết kế; chưa xác định điều khoản vận hành áp dụng cho một phương tiện cụ thể. Không sao chép toàn văn các nguồn vào package.

## 1. Kết quả đối chiếu nguồn

| ID | Nguồn gốc và URL | Phiên bản/mức truy cập đã xác minh | Phát biểu được hỗ trợ và tác động |
|---|---|---|---|
| S01 | IMO CSS overview — https://www.imo.org/en/ourwork/safety/pages/css-code.aspx | Trang giới thiệu chính thức đọc được | Nguyên tắc planning/execution/supervision và người đủ năng lực. Là nền giải thích ranh giới tool; không là bảng tham số profile |
| S02 | IMO e-Publications — https://imo-epublications.org/content/books/9789280117301 | Metadata/abstract chính thức: 2021 edition, phát hành 03-2021; chưa đọc toàn bộ sách trả phí | Abstract ghi bao gồm sửa đổi đến 2020, trong đó MSC.1/Circ.1623 và CSM guidelines MSC.1/Circ.1353/Rev.2. Không gọi đây là xác minh toàn bộ cập nhật sau 2020 |
| S03 | NeRF maritime / CSS republication — https://puc.overheid.nl/nsi/doc/PUC_2092_14/ | Toàn trang đọc được, bảng lịch sử hiển thị version từ 27-05-2002 | Giữ như nguồn công bố lại có phiên bản, không dùng trạng thái trên trang để nói đây là hợp tuyển IMO mới nhất. Không bỏ bước pin đúng điều khoản/sửa đổi khi đăng ký rule |
| S04 | DNV Steel Load Planner — https://www.dnv.com/services/ship-classification-fleet-in-service/steel-load-planner/ | Trang sản phẩm trực tiếp đọc được; không có publication revision của model | DNV mô tả mô hình kết cấu theo tàu cho đánh giá tải cục bộ và giới hạn đối với hệ thống/quy trình khác. Chỉ dùng minh họa cách khai scope; không chuyển thời gian giải/rating/tính năng sang SCST |
| S05 | BIPM/JCGM VIM — https://www.bipm.org/documents/20126/2071204/JCGM_200_2012.pdf | JCGM 200:2012, bản thứ ba, version 2008 minor corrections; đọc mục 2.26 và 4.14 | Phân biệt measurement uncertainty và resolution. Thiết kế SCST cần tách metadata nguồn khỏi precision của integer g/mm |
| S06 | CSDL VBPL Bộ Tư pháp — https://vbpl.moj.gov.vn/TW/Pages/vbpq-toanvan.aspx?ItemID=174773 | Search chính nguồn trả nội dung/metadata; mở trực tiếp trả 502. Chưa đọc đầy đủ phụ lục kỹ thuật tại vòng này | TT 02/2025/TT-BGTVT ban hành QCVN 72:2025/BGTVT, hiệu lực được nguồn ghi 01-08-2025. Không suy thông số cargo/profile từ metadata |
| S07 | Cổng văn bản Chính phủ — https://vanban.chinhphu.vn/?classid=1&docid=220128&pageid=27160 | Trang metadata chính thức mở được; chưa đối chiếu toàn bộ phụ lục sửa đổi | TT 78/2026/TT-BXD ban hành 27-10-2026, hiệu lực 01-05-2027. Tại ngày review 31-10-2026, không được đánh dấu sửa đổi này đã có hiệu lực chỉ vì vừa ban hành |
| S08 | Creative Commons legal code — https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode.en | Legal code chính thức mở được | Dùng nghiên cứu điều kiện license theo research/01; không chứng minh LICENSE của repo CVF đang bị chặn truy cập |

Không tìm thấy source đúng revision CVF qua các đường truy cập đã thử; xem research/01. Không diễn giải lỗi truy cập thành việc repo/commit không tồn tại.

## 2. Những nguồn này chưa cung cấp điều gì cho SCST

- Chưa có hồ sơ tàu/sà lan thật, flag/loại phương tiện, vùng và thời gian chuyến để xác định applicability cụ thể.
- Chưa có approved cargo/structural limits, kê/chồng, chống lăn/chằng buộc hoặc allowance của case.
- Chưa có hợp tuyển đầy đủ các sửa đổi sau mốc của tài liệu đã đọc; không tuyên bố đã hoàn thành rà soát pháp lý mọi loại phương tiện.
- Một trang sản phẩm, một ảnh hoặc bố trí từng được dùng không là oracle độc lập chứng minh an toàn.

Không gán các quy định về phương tiện thủy nội địa cho tàu biển chỉ từ việc cả hai có hầm xếp hàng. Cũng không tự cho rằng một chuẩn quốc tế thay thế hồ sơ/ràng buộc áp dụng của từng phương tiện.

## 3. Applicability record đề nghị trước khi kích hoạt một rule

| Nhóm | Trường cần xác định |
|---|---|
| Nguồn | Publisher/issuer; document ID; edition/amendment; section; URL hoặc artifact hash; ngôn ngữ; ngày truy cập và mức nội dung đã đọc |
| Phạm vi | Loại/flag/class phương tiện, vùng hoạt động, cargo/handling scope và điều kiện áp dụng |
| Thời gian | Ngày ban hành khác ngày hiệu lực; effective interval, quy tắc chuyển tiếp nếu có; khoảng ngày case |
| Chuyển thành rule | Phát biểu được nguồn hỗ trợ; giá trị/điều kiện thực lấy từ đâu; validator/model có kiểm được không |
| Trách nhiệm | Người đủ thẩm quyền đối chiếu applicability, căn cứ quyết định và ngày review |
| Bằng chứng/test | Acceptance/negative cases, đơn vị/basis, dependency, giới hạn mô hình; trạng thái khi thiếu dữ liệu |

Giữ tham khảo ở trạng thái REFERENCE_ONLY cho tới khi applicability và conversion thành rule được review. Không tự kích hoạt theo chuỗi tiêu đề hoặc năm lớn nhất. Nếu quy định có hiệu lực tương lai, lưu version tương lai nhưng không áp nhầm cho case trước ngày hiệu lực; kiểm quy tắc chuyển tiếp khi có nguồn đầy đủ.

## 4. Điều kiện đóng W-08

Vòng này đã bổ sung registry nguồn, ngày/edition và giới hạn truy cập. Phần tài liệu gốc có thể nghiên cứu độc lập đã được thực hiện trong phạm vi ghi ở bảng. W-08 còn PARTIAL cho applicability của phương tiện/chuyến và các thông số kỹ thuật thật. Phần đó cần hồ sơ cùng người có trách nhiệm; không đóng bằng sự đồng ý của hai AI.

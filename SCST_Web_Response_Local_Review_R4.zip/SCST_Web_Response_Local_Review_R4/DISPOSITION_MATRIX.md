# Disposition R2 / D3 / W sau báo cáo local

**Trạng thái:** REVIEW_RESPONSE / PROPOSED_FOR_RECONCILIATION.  
**Căn cứ ID:** bảng 3.1, 3.2 và 7.2 trong [báo cáo local](inputs/LOCAL_REVIEW_REPORT.md); quyết định gốc ở `DECISION_LOG_R2_R3.md` trong ZIP v0.3 giữ nguyên.

“Đã trả proposal” nghĩa là đã có nội dung để đối chiếu. Nó không có nghĩa owner đã phê duyệt, schema/backend đã hiện thực, tests đã chạy hoặc vấn đề nghiệp vụ đã đóng.

## 1. R2

| ID | Disposition Web R4 | Điều đã bổ sung / nơi đọc | Điều kiện còn mở |
|---|---|---|---|
| R2-01 | GIỮ, chờ căn cứ phạm vi | Phân biệt dữ liệu trước freeze và runtime MVP trong acceptance; câu hỏi pilot gộp tại DECISIONS_AND_INPUTS | Owner xác nhận initial state/cargo/nhu cầu, một case đại diện; không suy initial state từ ảnh final |
| R2-02 | GIỮ phát hiện schema gap; CỤ THỂ HÓA xử lý | contracts/01: source registry, confirmation, actor server-side, action preconditions và transaction | Local reconcile schema/domain/API/DB; ADM runtime tests sau implementation. Chưa gọi là runtime bypass hoặc đã vá xong |
| R2-03 | SỬA workflow đề nghị cho thực dụng | contracts/01: reviewer ngoài app, recorder/verifier, ReviewPolicy, binding/current-status theo phương thức thực | Quy trình/nguồn thẩm quyền và action policy được chấp nhận; schema semantics mới, ER tests. Không đổi tên actor trên receipt cũ |
| R2-04 | GIỮ grams ở mức đề nghị; BỔ SUNG đo lường | contracts/03: exact decimal, locale, miền số/trung gian, migration, resolution khác source uncertainty | Mẫu manifest và geometry để reconcile precision/basis; contract mới có version; tests đổi đơn vị/biên sau implementation |
| R2-05 | GIỮ mở cho MVP | contracts/02: profile/checker khác generator; coverage có chiều; acceptance: representability/oracle | Profile đúng quan hệ thật của pilot; sinh/kiểm được trên case; mixed vertical khi bắt buộc; không tự cấp rating |
| R2-06 | GIỮ PENDING_ALTERNATE_SOURCE_BYTES_OR_SHA | evidence ghi rõ local tự so hai bản R1; receipt web lịch sử có phạm vi riêng | Nhận bytes hoặc SHA/nguồn của variant R2 để đối chứng. Không kết luận R2 sai hoặc tự giải thích là re-export |
| R2-07 | GIỮ ranh giới bằng chứng | README, evidence và acceptance tách reference, TP ứng dụng, MVP và field acceptance | Runtime/đúng vai trò để đóng từng gate sau này; không cộng acceptance IDs thành số tests đạt |
| R2-08 | GIỮ schema gap; CỤ THỂ HÓA field binding | contracts/01: CriticalFieldPolicy, target/draft/value/source binding, derived claims, stale và transaction | Resolver/schema/domain/API/DB thống nhất; ADM stale/replay/coverage tests; chưa có backend mới |

## 2. D3

| ID | Disposition Web R4 | Cách giữ/sửa/hoãn và điều kiện nghiệm thu |
|---|---|---|
| D3-01 | GIỮ | Tool-first, core AI-off, quyền backend riêng và CVF cho Agent actions được bật; runtime chứng minh sau implementation |
| D3-02 | GIỮ | TP ứng dụng và MVP nghiệp vụ là hai mốc; thêm phân biệt điều kiện freeze với điều kiện runtime acceptance |
| D3-03 | GIỮ, LÀM RÕ | Nhiều tầng/nhiều nhóm phải phản ánh case; mixed same-hold khác mixed vertical. Profile/checker/template phải biểu diễn đúng quan hệ required |
| D3-04 | GIỮ CÓ ĐIỀU KIỆN | BOX là inner usable domain có nguồn trên chiều cao sử dụng; đo representability/fidelity trên case. General mesh chưa tự trở thành bắt buộc |
| D3-05 | CHỜ OWNER | Empty initial hold là phạm vi pilot đề nghị; chưa tự kết luận đây là công việc chính. Occupied/replan cần delta nếu bắt buộc |
| D3-06 | GIỮ, CỤ THỂ HÓA | SourceLine, cargo form/packaging, HandlingUnit và group tách nghĩa; mẫu nguồn pin mapping; không chia total để bịa mass từng unit |
| D3-07 | GIỮ | Collision envelope, support/contact và display mesh riêng; AABB false rejection phải được chẩn đoán, không nới overlap để đạt |
| D3-08 | GIỮ, CỤ THỂ HÓA | Viewer theo nhiệm vụ: tìm unit, ẩn lớp, xem đỡ, sửa và đối soát export; 2D/text fallback. Rubric tại acceptance, chưa có UI test |
| D3-09 | HOÃN THUẬT TOÁN THEO SCOPE | Không mở thuật toán điều phối/di chuyển máy; scenario có máy/tải tạm vẫn cần review phù hợp trước field use. Ảnh 1 không cho tải/đường truyền lực |
| D3-10 | GIỮ NGOÀI SCOPE CÓ ĐIỀU KIỆN | Các phần hoãn theo MASTER v0.3 vẫn giữ; case phải chứng minh phạm vi còn đại diện cho công việc. Không âm thầm đổi nhu cầu để vừa model |
| D3-11 | GIỮ REVIEW_ONLY | R4 là supplement; vòng local tiếp theo chỉ review/reconcile và thu bằng chứng; chưa roadmap/treeview/thi công |
| D3-12 | GIỮ, RECONCILE | Bảo toàn atomic units, budgets, immutable refs, partition, manual revision, proof semantics, provenance và nguồn; thay unit/record tạo lineage mới |

## 3. W-01…W-08

| ID | Kết quả trả trong R4 | Trạng thái đúng phạm vi | Điều kiện đóng tiếp |
|---|---|---|---|
| W-01 | contracts/02 mục 2–3: lựa chọn semantics, ví dụ testOnly, trường/source còn cần | PROPOSAL_DELIVERED; PENDING_PILOT_DATA | Một manifest đủ rõ unit/packaging/mass/geometry và mục tiêu group; local reconcile wire/domain |
| W-02 | contracts/02 mục 4–5: mẫu profile, template/generator và coverage; contracts/01 thêm lifecycle/binding generator | PROPOSAL_DELIVERED; PENDING_PROFILE_AND_MODEL | Nguồn/profile thật cho pilot; cấu hình biểu diễn được; implementation/generation/validator được kiểm sau khi có app |
| W-03 | contracts/02 mục 6 và acceptance mục 4–6: containment, AABB, model/search gap, fidelity protocol | METHOD_DELIVERED; PENDING_CASE_GEOMETRY | Geometry/reference có nguồn, thử representability để chọn model; runtime consistency/fidelity sau implementation |
| W-04 | contracts/01 mục 3–5: receive/register/verify/use/expire-withdraw; action-specific blocking; phương thức review offline | PROPOSAL_DELIVERED; PENDING_REAL_PROCESS | Quy trình đơn vị xác nhận actor/method/freshness/binding theo loại hồ sơ; ER/CT runtime tests sau implementation |
| W-05 | contracts/01 và 03: 16 nhóm record, field coverage, transaction/concurrency/recovery, grams/mm/measurement/migration | PROPOSAL_DELIVERED; PENDING_CONTRACT_RECONCILIATION | Local đối chiếu domain/wire/lifecycle/persistence, mẫu dữ liệu và compatibility; chưa có schema/backend mới |
| W-06 | research/01: hai source pins, URL đã thử, giới hạn truy cập, nghiên cứu license chính thức và đường thu nguồn hợp lệ | BLOCKED_BY_SOURCE; API/LICENSE_AT_PIN_NOT_VERIFIED | Quyết định source + revision + source/license evidence. G4b cần runtime riêng sau đó |
| W-07 | acceptance: CASE-A/B/C, oracle theo lớp, rubric UI/export, fidelity và phương pháp đặt ngưỡng | METHOD_DELIVERED; PENDING_CASE_AND_THRESHOLDS | Mẫu workload/máy/mục tiêu; pin ngưỡng trước test tương ứng; thực thi sau implementation |
| W-08 | research/02: nguồn chính thức, edition/ngày/hiệu lực/mức truy cập, applicability record | PARTIAL; SOURCE_REGISTER_DELIVERED | Hồ sơ phương tiện/chuyến và người có trách nhiệm xác định applicability; chưa có rating thật hoặc kết luận pháp lý chung |

## 4. Các điểm mới nổi lên từ local và cách xử lý

| ID nội bộ R4 | Phát hiện/đề nghị | Hướng xử lý |
|---|---|---|
| R4-01 | Nguồn CVF local khác baseline pin | Giữ hai nhận diện; chưa thay nguồn; W-06 blocked đúng phạm vi |
| R4-02 | Profile và khả năng sinh bị dễ đánh đồng | Tách definition/lifecycle; dispatch pin template/profile/build và kiểm input support |
| R4-03 | Review có thể bị thiết kế thành chờ nguồn không tồn tại | Policy cho phương thức có thật; UNKNOWN chặn đúng action; không tự nâng core-hard thành external |
| R4-04 | Precision số nguyên bị dễ hiểu là độ chính xác vật lý | Metadata đo lường/basis; exact conversion, NOT_STATED khác 0, margin không tính hai lần |
| R4-05 | Báo cáo dẫn raw evidence chưa được gửi | Đánh dấu LOCAL_REPORTED; yêu cầu artifact gốc; không dựng log thay thế |
| R4-06 | Điều kiện freeze dễ bị lẫn với nghiệm thu MVP sau xây dựng | Một case để quyết mô hình trước freeze; runtime evidence ở gate ứng dụng tương ứng |

Các mã R4 và CT trong supplement là mã đề nghị review mới. Chúng không đổi số hiệu R2/D3/LAT/ADM/ER/MB lịch sử và không tự tạo thêm tests đã đạt.

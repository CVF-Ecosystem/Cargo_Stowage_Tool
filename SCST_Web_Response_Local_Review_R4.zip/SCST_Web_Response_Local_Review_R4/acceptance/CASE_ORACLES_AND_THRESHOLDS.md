# Case, oracle, fidelity và cách đặt ngưỡng nghiệm thu

**Trạng thái:** `REVIEW_RESPONSE` / `PROPOSED_FOR_RECONCILIATION`.  
**Đối chiếu:** LOCAL_REVIEW_REPORT.md W-03/W-07 và mục 5; v0.3 docs/01, docs/02; MB-01…14.  
**Giới hạn:** tài liệu thiết kế kiểm chứng. Chưa có solver/backend/UI mới, case nghiệp vụ hoàn chỉnh hoặc kết quả nghiệm thu sản phẩm. Không hứa thời gian giải, tỷ lệ tận dụng hoặc tính tối ưu khi chưa có dữ liệu và implementation.

## 1. Phân biệt ba thời điểm quyết định

### 1.1 Trước khi freeze baseline/contract

Cần đủ căn cứ để chọn **phạm vi và mô hình sẽ xây**, không yêu cầu phải có ứng dụng hoàn tất rồi mới được chốt yêu cầu. Đề nghị tối thiểu một case đầu vào đại diện có manifest, ý nghĩa handling unit, nguồn geometry hầm và mô tả cấu hình kê/xếp cần thiết để kiểm khả năng biểu diễn.

Case này giúp trả lời: record có diễn đạt đúng đơn vị hàng không; constraints/profile có nơi chứa rõ; model BOX/envelope có phục vụ đầu bài; profile/checker/generator có thể được mô tả đủ để local thực hiện. Những thông số chưa được chuyên môn xác nhận phải được chỉ rõ cùng điều kiện chặn sử dụng thật; không thay bằng rating tự đặt.

Mẫu/source chưa đủ thì chỉ chốt các quyết định độc lập đã có căn cứ. Không mở rộng phạm vi tùy ý để “bao được mọi trường hợp”, và không yêu cầu CASE-A/B hoàn thành runtime acceptance trước khi viết ứng dụng.

### 1.2 Khi kiểm Technical Proof

Ứng dụng/thành phần chạy trên bài toán nhỏ có expected độc lập, có dữ liệu giả lập được nhận diện rõ và phạm vi proof cụ thể. Các tests v0.2 hiện có vẫn chỉ là reference contract; không tự thay oracle của generator/solver/backend mới.

### 1.3 Khi nghiệm thu MVP nghiệp vụ

Giữ đề nghị v0.3: ít nhất hai case được lập hồ sơ độc lập thể hiện nhu cầu đại diện và một case âm tính/chờ đúng. Đây là ngưỡng kiểm chứng của dự án để chốt với owner/reviewer, không phải tiêu chuẩn ngành. Mọi case dùng nghiệm thu có snapshot và expected được thống nhất trước khi đánh giá kết quả.

## 2. Phiếu case dùng chung

| Thành phần | Nội dung cần ghi |
|---|---|
| Identity/scope | Case ID/version, mục tiêu, new/occupied initial state, ngày/phạm vi, người cung cấp/đối chiếu |
| Manifest | File nguồn/hash, unit mapping, counts/mass, required/optional/excluded và group policy |
| Geometry | Nguồn và phiên bản hầm, frame, miền sử dụng/exclusions/clearance, geometry từng unit và mức xấp xỉ |
| Profiles | Profile versions/refs, phạm vi trên-dưới, constraints, review coverage và điều kiện chưa có |
| Reference arrangement | Unit placements hoặc tài liệu đủ để tái dựng, source/binding, phần đã được kiểm và người kiểm |
| Scenario | Final layout và những trạng thái/tải tạm có liên quan; phần nào cần review ngoài thuật toán |
| Expected | Fulfillment, lỗi/chờ mong đợi, mục tiêu optional hoặc bố trí mẫu, limits/coverage cần giữ |
| Execution | Máy/OS/runtime/build/seed/config/time budget; raw timing và outputs |
| Interpretation | Verdict theo phạm vi, khác biệt so oracle, nguyên nhân, giới hạn và người chấp nhận |

Một ảnh chụp không thay phiếu case. Một bố trí từng được dùng cũng không tự là chứng nhận mọi điều kiện kỹ thuật đã đạt. Cần biết những constraints nào của reference đã được đối chiếu trước khi dùng nó đánh giá model/solver.

## 3. Oracle phải độc lập ở đúng lớp

| Lớp cần kiểm | Oracle phù hợp | Điều không đủ làm oracle |
|---|---|---|
| Đếm/khối lượng/partition | Đối soát từ units nguồn và phép cộng/đếm độc lập, case nhỏ tính tay | Total do solver hoặc UI tự khai |
| Geometry đơn giản | Bài toán nhỏ có biên/khoảng cách tính độc lập; checker không chỉ gọi lại routine đang được test | Screenshot nhìn vừa, hoặc expected sinh bằng cùng hàm lỗi |
| Support predicate | Điều kiện profile đã được review và case chấp nhận/từ chối có expected rõ | Generator tự nói nó theo template; diện tích box tự thay contact |
| Generation | Một reference arrangement biểu diễn được và đã qua checker, hoặc exhaustive enumeration trong miền rời rạc nhỏ đã khai | Không tìm thấy trong một lần heuristic |
| Optimization proof | Oracle/exhaustive method có miền và objective trùng; certificate/proof phù hợp model | Thời gian chạy lâu, score cao hoặc nhiều AI đồng ý |
| Fidelity nghiệp vụ | Case tham chiếu có nguồn, cùng mục tiêu/constraints và reviewer xác định phần thực tế đã đánh giá | Ba ảnh không liên hệ manifest; một cấu hình lịch sử không có scope/nguồn |
| UI/export | Unit ID và giá trị kỳ vọng từ snapshot backend, nhiệm vụ người dùng được quan sát | Chỉ ảnh giao diện đẹp hoặc số tổng lặp lại từ renderer |

Một phép vét cạn trên grid/slot/template hữu hạn chỉ chứng minh kết quả trong miền đó. Nó không chứng minh mọi bố trí liên tục của hàng ngoài thực tế là bất khả thi. Proof phải pin input/model/objective/domain; mọi export và lời giải thích giữ đúng giới hạn ấy.

“Độc lập” không bắt buộc phải là một đội phát triển khác cho mọi phép cộng, nhưng expected không được sinh từ cùng đường logic đang được kiểm. Những kiểm tra chuyên môn cần đúng nguồn và người đủ thẩm quyền; việc các agent cùng kết luận không thay oracle đó.

## 4. Tách bốn nguyên nhân không tìm được phương án

Trước khi quyết định đổi model hoặc solver, dùng reference arrangement và checker để phân loại:

| Phân loại đề nghị | Dấu hiệu | Hành động phù hợp |
|---|---|---|
| DATA_OR_REVIEW_GAP | Không biết unit mass/geometry/profile hoặc nguồn reference chưa đủ | Thu nhận/đối chiếu phần thiếu; vẫn làm được các review độc lập |
| MODEL_LIMIT | Reference đủ căn cứ cho phạm vi kiểm nhưng representation/predicates không diễn đạt được | Reconcile geometry/profile/support contract; không chỉ tăng time budget |
| SEARCH_LIMIT | Reference biểu diễn được, independent checker nhận trong model, generator chưa tìm được trong budget | Phân tích recipe/search order/heuristic/config; giữ timeout/NOT_PROVEN đúng nghĩa |
| CONSTRAINT_VIOLATION | Candidate cụ thể vi phạm một điều kiện đã khai và đủ nguồn | Báo đúng lỗi; không nới constraint hoặc epsilon để đạt benchmark |

Một kết quả validator FAIL cũng chưa tự phân biệt MODEL_LIMIT với CONSTRAINT_VIOLATION của thực tế. Phải biết reference, nguồn và giả định đang so là gì. Phân loại trên là semantics đề nghị cho báo cáo, chưa là enum runtime đã hiện thực.

## 5. Đánh giá fidelity của BOX/envelope

### Bước 1 — thống nhất miền và mục tiêu so sánh

Pin cùng manifest, required/optional/excluded, profile, allowance và scenario. Phân biệt vùng hầm thực được duyệt với vùng mô hình; ghi các khoản không gian bị loại và lý do. Không so một reference đã dùng vùng ngoài scope hoặc profile khác với một mô hình chặt hơn rồi kết luận solver kém.

### Bước 2 — thử tái biểu diễn reference

Kiểm từng unit có map được vào primitive/template đang chọn, giữ ID/mass/geometry và quan hệ đỡ hay không. Thử containment tại toàn occupied volume và các cao độ liên quan. Nếu không biểu diễn được, ghi unit/cấu hình/biên nào gây mất; đây là kết quả review model trước khi tối ưu.

### Bước 3 — kiểm độc lập bố trí đã biểu diễn

Checker đánh giá đúng constraints đã pin. Nếu checker bác bỏ, xác định do nguồn/reference thật vi phạm, do model bảo thủ, do dữ liệu thiếu hay do lỗi implementation. Không tự coi reference lịch sử là đúng hoặc checker là đúng chỉ vì nó chạy được.

### Bước 4 — đo khả năng sinh

Khi reference biểu diễn và kiểm được, mới dùng nó làm mốc cho generator. Ghi seed/build/config/budget, candidate đầu tiên, candidate tốt nhất và trạng thái kết thúc. Nếu chưa tìm thấy, giữ SEARCH_LIMIT/NOT_PROVEN theo bằng chứng; không nâng thành infeasibility của thế giới thực.

### Bước 5 — xét giá trị nghiệp vụ

Với case required, phải đáp ứng đúng tập required và các nhóm; không giảm tập hàng để đạt. Với optional, ghi objective khối lượng đã xếp và mức tối thiểu được chấp nhận cho công việc, thống nhất trước lần nghiệm thu. Nếu tool chỉ xử lý subset dễ nhưng case bắt buộc phần ngoài model, mốc nghiệp vụ còn chờ.

Không đặt trước một tỷ lệ mất không gian hoặc thời gian giải chung cho mọi manifest. Đầu ra của các bước trên giúp owner/reviewer chấp nhận mức xấp xỉ có căn cứ hoặc yêu cầu mở model trước MVP.

## 6. Chỉ số cần ghi và cách tránh hiểu nhầm

| Chỉ số | Cách diễn giải |
|---|---|
| Manifest reconciliation | Mọi dòng/unit được map hoặc nêu thiếu/unsupported; không mất ID hoặc total |
| Required fulfillment | Unit/nhóm required đã placed đủ trong đúng snapshot |
| Optional placed mass | Objective đúng đơn vị/basis; không bù thiếu required bằng thêm optional |
| Model representability | Case/reference nào biểu diễn được, unit/predicate nào bị model loại và lý do |
| Candidate validity | Từng rule đủ coverage, errors/unknown rõ; không chỉ một score tổng |
| Search outcome | Có candidate không, fulfillment, termination, proof và phạm vi proof |
| Workflow usability | Người dùng có hoàn thành nhiệm vụ, sửa lỗi và đối soát được không |
| Timing/resource | Từng giai đoạn và môi trường, số unit/profiles/groups/exclusions cùng cấu hình |

Nếu báo “tỷ lệ tận dụng hầm”, phải định nghĩa mẫu số và tử số. Thể tích thép thật, thể tích envelope, union vùng chiếm chỗ và thể tích miền BOX không phải cùng đại lượng. Không lấy tổng hộp hiển thị chia thể tích hầm rồi trình bày như năng lực chở thực tế. Khi geometry có các bounding boxes giao nhau nhưng primitive không giao, tổng thể tích boxes còn có thể đếm trùng. Các chỉ số unit/mass/fulfillment thường trực tiếp hơn với mục tiêu v0.3 đã chọn.

## 7. Benchmark trên máy local mà không bịa ngưỡng

### 7.1 Dữ kiện đội kỹ thuật tự thu thập

Local inventory CPU, RAM, OS, runtimes/dependencies, storage và GPU/WebGL khi liên quan. Báo cáo local hiện đã nêu Windows/Python/Node/RAM, nhưng raw evidence chưa đi kèm trong tệp được Web nhận; các giá trị ấy hiện là thông tin local báo cáo, chưa là benchmark app được Web kiểm độc lập.

Mỗi workload ghi ít nhất số units, số hình thức/geometry/profile khác nhau, số nhóm ALL_OR_NONE, exclusions, độ chặt của capacity/geometry và lớp/template được xét. Hai manifest cùng số unit có thể tạo khác biệt về cấu hình tìm kiếm; không chỉ ghi “N kiện”.

### 7.2 Cách đặt ngưỡng

1. Thu một case thường gặp và một case lớn/khó mà người vận hành xác nhận có ý nghĩa; không tự gọi “lớn” từ fixture nhỏ.
2. Ghi quy trình hiện tại, bước nào người dùng chờ, bước nào cần phản hồi tương tác và kết quả nào tối thiểu hữu ích.
3. Đội kỹ thuật đề nghị riêng time budget cho solve, kỳ vọng phản hồi UI/validation và yêu cầu cancel/recovery, dựa trên phép đo có thật. Owner chốt mức phù hợp công việc, không chọn thuật toán.
4. Pin ngưỡng cùng workload/máy/build trước lần nghiệm thu. Chưa có dữ liệu để đặt ngưỡng thì ghi pending của gate hiệu năng; không tuyên bố một fixture 86 tests chạy nhanh là app đạt hiệu năng.

### 7.3 Những dữ liệu thực thi cần lưu

Tách thời gian parse/intake, preflight, generate/solve, independent revalidation, render/filter và export. Ghi từng run, seed/config, cold/warm context khi ảnh hưởng và peak resource khi cần chẩn đoán. Giữ log timeout/cancel/error và candidate còn lại; các run không tìm được nghiệm không biến mất khỏi thống kê.

Có thể lặp cùng snapshot để đánh giá nhiễu và lặp seed khi thuật toán sử dụng seed, nhưng phải công bố protocol/đếm từng run. Không báo percentile hoặc độ chắc chắn thống kê mà số lượt quan sát không hỗ trợ. Kết quả chỉ có ý nghĩa trên bộ workload/máy đã đo, không là cam kết mọi manifest.

## 8. Rubric nhiệm vụ người dùng đề nghị

| Nhiệm vụ | Expected cần quan sát | Dữ liệu đối chiếu |
|---|---|---|
| Tìm một unit từ manifest | Đúng ID, nhóm, placement hoặc lý do chưa xếp | Snapshot/backend và source mapping |
| Ẩn lớp/nhóm hoặc xem mặt cắt | Nhìn được phần cần kiểm; totals/validator không thay do thao tác hiển thị | Cùng plan hash và bảng tổng trước/sau |
| Kiểm một quan hệ đỡ | Đọc được supporters/profile/điều kiện hoặc biết rõ chưa đánh giá | Support graph/profile refs và rule coverage |
| Thử một sửa tay vi phạm có chủ đích | Nhận lý do cụ thể; không có receipt hợp lệ cho bản lỗi | Negative candidate độc lập, version/lifecycle |
| Sửa thành bố trí hợp điều kiện model | Có version và validation mới; không kế thừa proof cũ | Parent/new refs và validation evidence |
| Xuất PDF/XLSX và đối soát | Cùng units, mass, status, coverage và version/hash | Backend snapshot, file thực mở được |
| Mất 3D hoặc hủy tác vụ | Giữ dữ liệu, dùng được đường fallback/phục hồi trong phạm vi đã chốt | UI/API/state logs thực |

Ghi người làm, nhiệm vụ được giao, lỗi/điểm không hiểu và kết quả; ghi thời gian thao tác nếu đó là mục tiêu đã thống nhất. Không dùng một screenshot để chấm cả rubric đạt.

## 9. Điều kiện đóng cho W-01/W-02/W-03/W-07

| Vấn đề | Có thể đóng phần thiết kế khi | Phần nghiệm thu để sau implementation |
|---|---|---|
| W-01 handling units | Một nguồn mẫu đủ để chốt unit/group/mapping; logic không làm mất tổng hoặc tạo mass giả | Import/confirmation/reconciliation chạy trên file và backend thật |
| W-02 profile/generator | Profile/checker/template có trách nhiệm, input/output và conditions rõ, model biểu diễn được cấu hình pilot | Generator tự tạo candidate; checker và chuyên môn đối chiếu đúng phạm vi |
| W-03 BOX/AABB | Đã xét containment/representability trên case đại diện và quyết định model có căn cứ | Geometry/solver/viewer/export nhất quán, fidelity đạt trên bộ case nghiệm thu |
| W-07 acceptance | Case protocol, oracle, rubric và cách đặt ngưỡng rõ; owner đồng ý mục tiêu trước nghiệm thu | Runtime logs và kết quả thật đáp ứng ngưỡng đã pin |

Không coi bảng tiêu chí là tests đã chạy. Không đòi nghiệm thu ứng dụng trước khi được chốt baseline để xây ứng dụng. Phạm vi còn mơ hồ hoặc model chưa biểu diễn được case thì giữ phần freeze phụ thuộc đó ở trạng thái chờ, đồng thời tiếp tục quyết định kỹ thuật độc lập.

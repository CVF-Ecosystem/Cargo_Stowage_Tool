# Bằng chứng đã có và còn thiếu trong vòng R4

Ngày lập: **31-10-2026**. Phân loại dưới đây nhằm giữ đúng phạm vi kết luận; không đánh giá độ tin cậy cá nhân của người lập báo cáo.

## 1. Đầu vào thực nhận

| Artifact | Nhận/đọc ở vòng Web | Hash hoặc vị trí |
|---|---|---|
| LOCAL_REVIEW_REPORT.md | Có; giữ nguyên bytes trong inputs | SHA-256 `31ab6145af63401f6289b0dae5370dc674cc1c9f409ddca1708142706c17c75b` |
| LOCAL_REVIEW_EVIDENCE_2026-10-31/ | **Chưa nhận** trong upload đi kèm; báo cáo có link tương đối tới thư mục này | Không có bytes để tự kiểm; không tạo hash/log giả |
| ZIP v0.3 Review Baseline | Có; giữ nguyên trong history | SHA-256 `2a83796d9410314c4b13c32f40df7e41dd155eeafac83b2d597c71e5ca7d213b` |
| ZIP v0.2 lịch sử | Có bên trong v0.3 nguyên bản | SHA-256 `6f587938f48b24daef5eaf0ba3fcab7532ec0397c3d2f7a39ca2caf686da44df` |
| Ba ảnh, R2, evidence web R3 | Có bên trong v0.3 nguyên bản; đã là đầu vào review trước | Không nâng thành manifest/profile hoặc evidence runtime mới |

Các hash được đối chiếu khi đóng gói R4. Danh sách checksum của R4 chỉ bao các artifact thực có, không bao thư mục local chưa được gửi.

## 2. Phần chỉ được local báo cáo

Báo cáo mục 1/6 nêu Windows 11 Home Single Language 64-bit build 26200, RAM 16,849,293,312 bytes, Python 3.11.9, Node 22.17.0, npm 10.9.2; venv replay dùng jsonschema 4.26.0. Mục 6 báo replay bắt đầu 16:07:24.739826 và kết thúc 16:07:27.395279 ngày 31-10-2026, UTC+07:00.

| Kết quả trong báo cáo local | Phân loại ở vòng Web R4 |
|---|---|
| V0.3 checksum 35/35; v0.2 65/65 | LOCAL_REPORTED cho lần chạy local |
| 86 tests, 0 failures/errors/skipped | LOCAL_REPORTED; CONTRACT_REFERENCE_ONLY |
| Bốn probes `[true,true,true,false]` | LOCAL_REPORTED; JSON_SCHEMA_ONLY |
| Reference default operationalEligible=false | LOCAL_REPORTED; không phải backend production |
| CVF origin/HEAD/clean tree; pin không có object trong clone | LOCAL_REPORTED; không chứng minh object không tồn tại ở nơi khác |
| LICENSE public checkout là CC BY-NC-ND 4.0 | LOCAL_REPORTED; chưa là license của Provenance |
| Local so hai bản R1 cùng hash | LOCAL_REPORTED cho hai vị trí đó; không nâng thành tự so bảy vị trí của receipt web trước |

Report có thể ghi đúng những lần chạy này, nhưng Web cần raw receipts/logs để đối chứng trực tiếp. Khoảng thời gian wrapper không phải benchmark ứng dụng.

## 3. Evidence web đã có từ R3

V0.3 giữ receipts/logs của các phép kiểm reference/probes trên môi trường Web, cùng source register. Phạm vi là schema/reference và integrity. Kết quả đó đã được nêu trong v0.3; R4 không chạy lại suite để tăng số tests hoặc diễn đạt thành xác minh môi trường Windows.

R1 khả dụng trong lịch sử có SHA-256 `adf11a5682ea541d01a5b3ed348c6274938532a45ced23c49e91fa6ea6a08d8f`. Đối với variant mà R2 nói đã thấy, giữ `PENDING_ALTERNATE_SOURCE_BYTES_OR_SHA`. Chưa có bản thay thế để đối chứng; không suy nguyên nhân khác biệt.

## 4. Việc làm ở R4

- Đọc/đối chiếu báo cáo local, các nguồn lịch sử và các proposal kỹ thuật.
- Nghiên cứu nguồn chính thức theo registry research/02, cùng tài liệu SQLite được dẫn ở contracts/01.
- Thử truy cập source/revision/license CVF và ghi giới hạn thật tại research/01. Không đọc được LICENSE đúng pin nên không tạo license-file hash.
- Viết disposition, contract proposals, acceptance method, đầu vào còn cần và work order review tiếp.
- Kiểm toàn vẹn artifact R4 và giữ nguyên bytes của report/ZIP lịch sử khi đóng gói.

R4 chưa tạo hoặc chạy backend, solver production, UI, DB recovery, CVF bridge, operational schema mới hoặc test hiện trường. CT-01…17 là tiêu chí đề nghị tương lai; không phải 17 tests đã chạy. Không cấp operational eligibility hoặc field approval từ tài liệu này.

## 5. Bổ sung evidence local thế nào?

Gửi ZIP của thư mục evidence gốc, có checksum và giữ receipt theo lần chạy thật. Nếu raw evidence không còn, ghi tình trạng đó; chỉ chạy lại khi cần giải quyết verification cụ thể và ghi receipt mới. Không tái tạo log bằng cách chép các con số trong report.

Source CVF cần bằng chứng riêng: nguồn được chọn, commit/tree, LICENSE/NOTICE tại revision, các package/lockfile và API/guard registration liên quan. Source inventory chưa là bridge integration test.

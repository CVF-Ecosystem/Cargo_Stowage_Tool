# Đầu vào còn cần, phân đúng người xử lý

**Mục tiêu:** bổ sung thông tin để chọn scope/model và reconcile contract. Không cần owner trả lời toàn bộ mới tiếp tục những phần kỹ thuật độc lập. Không dùng những mục dưới đây như một biểu mẫu cấp chứng nhận an toàn.

## 1. Ba nhóm thông tin nghiệp vụ ưu tiên

### A. Chọn công việc pilot

Owner/người lập phương án xác nhận công việc đầu tiên cần tool giải quyết:

- Lập kế hoạch trước cho hầm ban đầu trống, hay bổ sung/điều chỉnh khi hầm đã có hàng?
- Loại hàng nào bắt buộc; trong quy trình hiện tại, một đơn vị được nâng/đặt nguyên vẹn là bó, từng ống/chiếc hay đơn vị khác?
- Mục tiêu bắt buộc của chuyến: xếp hết danh sách required, hoặc phần nào được lựa chọn/loại có chủ đích?

**Tác động:** chốt initial-state/cargo semantics và fulfillment. Không chọn EMPTY_TARGET_HOLD chỉ vì thuận lợi phát triển nếu nó không giải quyết công việc pilot.

### B. Gửi một hồ sơ case đại diện đang có

Ưu tiên một manifest nguồn cùng bố trí tham chiếu và tài liệu/số đo hầm liên quan nếu có. Có thể ẩn tên khách hàng/thông tin thương mại, nhưng giữ mapping unit, đơn vị tính, dimensions/mass và liên hệ giữa các tài liệu; ghi rõ phần đã ẩn/chưa có.

Đội kỹ thuật tự đọc và liệt kê trường còn thiếu. Owner không cần chuyển file thành JSON, tự gán unit IDs, chia mass tổng hoặc vẽ lại hình học để phù hợp schema. Nếu nguồn chưa có mass từng bó, giữ đúng tình trạng ấy để cùng xác định nguồn bổ sung.

**Tác động:** đánh giá source→unit mapping, BOX/envelope và cấu hình xếp. Một hồ sơ đủ căn cứ để chọn mô hình trước freeze khác với bộ case dùng nghiệm thu ứng dụng sau này.

### C. Xác định nguồn review và điều kiện thao tác thực

Người vận hành/chuyên môn cho biết cấu hình nào bắt buộc, đặc biệt bó trên ống/nhóm trên nhóm khác; hồ sơ kê/chèn/chống lăn hoặc giới hạn đang dùng lấy ở đâu; ai có thể đối chiếu phạm vi đó. Đồng thời xác nhận có thiết bị lên hàng hoặc tải tạm ở giai đoạn nào và hồ sơ liên quan hiện có gì.

Chỉ cần mô tả quy trình review đang thực hiện: nhận hồ sơ từ ai, ai lưu/đối chiếu, khi thay đổi thì thông tin được chuyển bằng cách nào. Tool sẽ được thiết kế theo phương thức có căn cứ; không yêu cầu đơn vị phải tự tạo một cổng thu hồi online.

**Tác động:** profile applicability, coverage và review policy. Không yêu cầu người dùng đoán rating hoặc xác nhận một cấu hình an toàn từ ảnh.

## 2. Phần đội kỹ thuật/local chủ động làm

| Việc | Đầu ra cần có |
|---|---|
| Đính kèm evidence local đã báo cáo | Log/receipt gốc, command/cwd/environment/dependency/input/output hashes; không đổi lịch sử cho đẹp đường dẫn |
| Reconcile contract R4 | Domain/wire/lifecycle/persistence thống nhất; delta có lý do; không chuyển việc chọn serializer/DB protocol cho owner |
| Chuẩn bị oracle/model check | Đối soát đơn vị/mass, representability, expected độc lập và ca âm tính theo phạm vi |
| Inventory/benchmark protocol | Máy/workload có nguồn; đề nghị ngưỡng từ công việc và phép đo, owner chốt mục tiêu dùng được |
| Traceability | Map CT/R4 với LAT/ADM/ER/MB; không đếm trùng thành số tests hoặc tuyên bố tất cả đã chạy |

## 3. CVF: quyết định nguồn riêng

Owner/maintainer cần xác nhận dự án thực sự chọn nguồn Provenance đã pin hay muốn đề nghị thay sang public revision đang có. Đây là quyết định về dependency của dự án; local chịu trách nhiệm thu revision/license/API evidence.

Nếu dùng Provenance, cần quyền đọc hợp lệ hoặc source bundle được phép chia sẻ cùng bằng chứng commit/tree/license. Nếu đổi nguồn, lập change proposal, nêu actual SHA, quyền sử dụng và ảnh hưởng API/guards. Không gửi password/token trong tài liệu hoặc chat.

Thiếu source đúng bản chặn phần CVF phụ thuộc. Nếu core/manual được giữ độc lập, việc review phần đó vẫn tiếp tục; nếu MVP bắt buộc có Agent, cần ghi dependency này trong tiêu chí của phạm vi được chọn.

## 4. Dữ kiện hiệu năng lấy sau khi rõ case

Owner/người dùng mô tả quy mô thường/lớn và bước hiện tại mất thời gian hoặc phải chờ. Đội kỹ thuật chuyển thành workload, protocol và đề nghị ngưỡng. Không yêu cầu owner chọn heuristic, cấu trúc index, seed hoặc viết test.

Ngưỡng parse/solve/revalidate/render/export được pin trước nghiệm thu tương ứng. Hiện chưa có dữ liệu để cam kết thời gian giải hoặc tỷ lệ tận dụng; không lấy thời gian 86 reference tests làm benchmark app.

## 5. Quy tắc đóng quyết định

Mỗi quyết định được ghi: ID, nội dung chọn, người có thông tin/quyền quyết định, nguồn, ngày và phạm vi ảnh hưởng. Những gì chưa biết giữ pending cùng action bị chặn. Bản R4 này không tự điền câu trả lời thay owner hoặc reviewer.

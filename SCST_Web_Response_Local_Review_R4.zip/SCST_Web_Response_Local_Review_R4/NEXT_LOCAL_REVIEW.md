# Work order — đối chiếu phản hồi Web R4

**Chế độ:** REVIEW_ONLY. **Đầu vào:** v0.3 nguyên bản, LOCAL_REVIEW_REPORT nguyên bản và supplement SCST-WEB-RESPONSE-R4.  
**Mục tiêu:** đóng các khác biệt contract có thể xử lý, đối chiếu evidence và xác định những đầu vào cụ thể còn chặn freeze. Chưa dựng roadmap, treeview ứng dụng hoặc triển khai app.

## 1. Đọc theo thứ tự

1. README, WEB_RESPONSE_R4, DISPOSITION_MATRIX.
2. Contracts 01–03, acceptance và hai tài liệu research theo câu hỏi phụ trách.
3. Đối chiếu với v0.3/master/docs và schema/reference v0.2 trong history; không ghi đè lịch sử.
4. Đọc DECISIONS_AND_INPUTS để phân biệt việc cần nguồn nghiệp vụ với việc đội kỹ thuật tự làm.

## 2. Kết quả cần trả

### 2.1 Disposition cụ thể

Với mỗi W/R4 hoặc contract điểm còn khác biệt, ghi ACCEPT_PROPOSAL / REQUEST_CHANGE / REJECT_WITH_REASON / BLOCKED_BY_INPUT. Dẫn file/mục/field, lý do, ảnh hưởng và điều kiện đóng. Một trạng thái ACCEPT_PROPOSAL của local là kết luận review kỹ thuật, chưa thay owner hoặc reviewer chuyên môn.

Những điểm ưu tiên: template/generator lifecycle và input support; phân quyền/action-specific review; source/field coverage; numeric/basis/migration; persistence/crash recovery; model representability; exact source CVF.

### 2.2 Reconcile domain, wire, lifecycle, persistence

Đối chiếu ma trận 16 nhóm record với khả năng hiện thực trên môi trường local. Pin chiều refs để không tạo vòng hash; actor server-derived; idempotency/expected revision; receipt/status projection; blob/DB recovery; field claims và correction; schema/hash/lineage khi đổi unit. Ghi những thay đổi nào là breaking và migration phải tạo record/receipt mới.

Phân biệt catalog/profile áp dụng, model kiểm được và generator hỗ trợ inputs; dispatch không được chỉ dựa trên profile hợp lệ. Xác định cách run pin template/profile/build và cách validator độc lập kiểm candidate.

Đây là thiết kế/reconciliation, không phải lệnh viết schema production hoặc code ứng dụng trong vòng này. Không chỉ đổi version string để ghi nhận yêu cầu mới.

### 2.3 Evidence local đã có

Đính kèm thư mục `LOCAL_REVIEW_EVIDENCE_2026-10-31/` nguyên bản hoặc ZIP chứa nó, có checksum. Giữ raw commands, cwd, environment/dependencies, receipts và hashes. Không sửa timestamp/đường dẫn receipt để làm như đã chạy trong gói bàn giao.

Không cần chạy lại suite 86 tests khi source/input/dependency không đổi và evidence cũ còn đầy đủ. Nếu artifact cũ không còn hoặc cần resolve khác biệt cụ thể, lần chạy lại phải có receipt mới, ngày/môi trường mới và lý do rõ. Không dùng report tổng hợp để tự dựng lại raw log.

### 2.4 CVF đúng nguồn

Làm rõ nguồn mà owner/maintainer chọn; giữ khác biệt giữa pin Provenance và checkout public. Thu source/revision/license evidence theo research/01 qua quyền đọc hợp lệ; loại credential khỏi remote output. `@types/node` ở root không tự là runtime matrix của engine.

Chưa có source đúng pin thì giữ BLOCKED_BY_SOURCE, không tự thay repo hoặc suy API. Chưa có bridge/runtime thì G4b vẫn NOT_RUN/NOT_VERIFIED; không sửa CVF core để hợp protocol SCST đề xuất. Nếu đổi nguồn, trả change proposal có tác động.

### 2.5 Một case để chọn mô hình

Từ hồ sơ owner cung cấp, map source lines→handling units→groups, ghi dimensions/mass/basis, initial state, geometry/profile và reference arrangement. Đánh dấu phần thiếu thay vì bịa dữ liệu hoặc chia tổng mass. Dùng protocol acceptance để phân biệt data/review gap, model limit và search limit.

Nếu chưa có hồ sơ, trả bảng trường còn thiếu và nguồn/người có thể cung cấp, vẫn hoàn tất review contract độc lập. Không yêu cầu CASE-A/B runtime đã đạt trước khi có thể chốt yêu cầu để xây ứng dụng.

## 3. Dạng phản hồi gọn, có thể kiểm

Có thể dùng một báo cáo tổng hợp kèm evidence và phụ lục contract; không bắt buộc tách file cho đủ hình thức. Báo cáo cần đủ:

- Verdict và phạm vi đã đọc/đã chạy/chưa chạy.
- Disposition theo ID và delta được đề nghị.
- Evidence index với đúng bytes/hash/môi trường, không nâng report-only thành verified.
- Danh sách quyết định còn chờ, người/nguồn đóng và action/gate phụ thuộc.
- Khuyến nghị phần nào đủ căn cứ freeze, phần nào cần bổ sung và vì sao.

Mọi phép thử mới phải giải quyết một rủi ro/khác biệt cụ thể hoặc requirement gate có căn cứ. Không cộng CT/LAT/ADM/ER/MB IDs thành tổng tests, không chạy lặp để tạo số lượng.

## 4. Điều kiện kết thúc vòng local

Vòng review đạt mục tiêu khi các proposal đã có disposition rõ, bằng chứng đã được phân đúng mức, và phần chờ chỉ ra được đầu vào có thể thu nhận. Không cần mọi việc phụ thuộc chuyên môn được giải quyết mới trả báo cáo; không được đánh dấu đóng thay cho nguồn chưa có.

Sau vòng này, owner cùng các bên review mới xem xét chốt phạm vi/Final Baseline. Roadmap, treeview và triển khai là công việc tiếp theo khi được giao, không tự phát sinh từ việc nhận gói R4.

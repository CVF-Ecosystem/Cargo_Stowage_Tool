# Phát hành v0.2 — package chính thức cho Agent local

**Package ID:** `SCST-LOCAL-0.2`  
**Ngày:** 31-10-2026  
**Trạng thái:** `OFFICIAL_LOCAL_AGENT_HANDOFF` / `READY_FOR_LOCAL_VERIFICATION`

## Mục đích của bản phát hành

V0.2 chuyển baseline v0.1 và phản biện độc lập R1 thành một bộ yêu cầu có thể giao trực tiếp cho Agent local. Các quyết định thiết kế, contract dữ liệu, mã kiểm tham chiếu, tiêu chí nghiệm thu và việc cần xác minh tại local đã được đặt trong cùng package. Đọc `START_HERE_LOCAL_AGENT.md` để bắt đầu; dùng `PROMPT_DAN_VAO_LOCAL_AGENT.txt` nếu cần câu lệnh giao việc sẵn.

V0.2 là nguồn yêu cầu đang hiệu lực trong phạm vi package. Ba tệp trong `history/` được giữ nguyên bytes để tra cứu, gồm baseline v0.1, báo cáo R1 và handoff R1. Không cần chuyển thêm chúng riêng khi đã chuyển toàn bộ ZIP v0.2.

## Những thay đổi đã chốt

| Chủ đề | Quyết định v0.2 |
|---|---|
| Phạm vi khởi đầu | PC local, một người sử dụng, một hầm BOX đã xác nhận trống; AI tùy chọn. Hàng hiện hữu ngoài hầm vẫn cộng vào hạn mức toàn tàu. |
| Cargo và support | Mỗi bó là một đơn vị nguyên vẹn. Bó thép thanh và bó thép ống cần profile phù hợp. Xếp tầng bị khóa tới khi có profile được duyệt và bằng chứng gate tương ứng. |
| Hạn mức khối lượng | Tách GT, DWT và cargo capacity. Một công thức duy nhất cộng hàng hiện hữu, hàng mới thực xếp và dự phòng kê mới; không trừ kê hai lần hoặc bỏ reserve khi chỉ xếp một phần. |
| Intake | Dữ liệu thiếu/xung đột được giữ trong draft; OCR/AI chỉ đề xuất. Confirm cần actor và nguồn được backend đối chiếu. |
| Hình học | Chốt trục, điểm neo sau yaw, margins, excluded zones và cao độ kê. Giữ nguồn số đo thực, bản vẽ hoặc ước tính có xác nhận; không tự đặt số đo. |
| Nội dung bất biến | Ref có kind/ID/version/hash; case pin toàn bộ đầu vào. Hash dùng STOWAGE-JSON-0.2 với vectors có thể chạy lại. Run, plan, validation, quyết định và lifecycle là các record riêng. |
| Sửa tay | Tạo plan mới, pin parent cùng case và validation mới; không sửa solver run gốc hoặc kế thừa kết luận tối ưu của run đó. |
| Mục tiêu solver | ALL_REQUIRED giữ nguyên tập bắt buộc. MAXIMIZE_OPTIONAL giữ required và tối đa tổng khối lượng optional đã xếp; không có ưu tiên tùy chỉnh chưa được biểu diễn. |
| Kết quả solver | Tách termination/candidate/fulfillment/proof. Hết giờ hoặc không tìm thấy bằng heuristic không là bằng chứng vô nghiệm. |
| Coverage và quyền | HARD/HARD_GATE/GOVERNANCE thiếu hoặc không đạt thì chặn. Selection và field review có receipt, coverage và vai trò riêng; AI/CVF không thay quyền backend. |
| Nghiệm thu | G4a cho core; G4b cho AI/CVF. 25 kịch bản LAT là yêu cầu kiểm thử ở local, có mẫu log và báo cáo, không được tính thành các test đã chạy trong package. |
| UI và báo cáo | Tiếng Việt, ngày dd-mm-yyyy, drilldown, 2D fallback, PDF và XLSX; export gắn version/hash và phần chưa đánh giá. |

Chi tiết xử lý từng nhận định R1 nằm trong `docs/05_R1_DISPOSITION.md`. Những mục phụ thuộc code chạy thật, hồ sơ kỹ thuật hoặc repo CVF vẫn cần bằng chứng ở local; việc đã chốt cách xử lý trong thiết kế không tự đóng các gate đó.

## Thành phần chạy được

- 14 JSON Schema: 12 loại nội dung, một schema định nghĩa chung và một schema cho fixture bundle.
- 13 JSON fixtures: 12 ví dụ entity và một bundle có 12 record tham chiếu bằng hash thực; nguồn synthetic đi kèm có bytes để đối chiếu.
- 7 vectors cho serialization/hash STOWAGE-JSON-0.2.
- Reference validator và bộ kiểm tra tự động: **86/86 tests đạt**, không failure, error hoặc skipped, trên Python 3.12.14 và jsonschema 4.26.0.
- Công cụ kiểm SHA-256 cho các tệp trong bản phát hành.

Bằng chứng gốc, lệnh chạy, hash đầu vào và giới hạn kết luận nằm ở `evidence/`. Các test kiểm contract và logic tham chiếu trên dữ liệu tổng hợp. Chưa có backend/solver ứng dụng hoàn chỉnh, CVF bridge đã chạy hoặc nghiệm thu hiện trường trong bản phát hành này.

## Việc đầu tiên Agent local phải trả

Sau khi kiểm package và khảo sát checkout thật, trả `LOCAL_DESIGN_REVIEW.md`, `GATE_STATUS.md`, `OPEN_DECISIONS.md` cùng kế hoạch commit cụ thể. Tiếp tục các việc code/test độc lập có thể thực hiện, đồng thời yêu cầu người có trách nhiệm cung cấp hồ sơ và thông số thực cần thiết cho gate tiếp theo. Không cần hỏi lại các lựa chọn v0.2 đã ghi rõ khi chưa có bằng chứng mâu thuẫn hoặc yêu cầu đổi phạm vi.

## Không phải bản nâng cấp dữ liệu tự động

Contract v0.2 thay đổi đáng kể so với v0.1. Package không có migration production đã kiểm thử. Nếu local đã có dữ liệu v0.1, Agent phải lưu bản gốc, lập mapping, kiểm lỗi/thiếu nguồn và tạo phiên bản mới theo quy trình confirm; không chỉ đổi chuỗi schemaVersion rồi gọi là hợp lệ.

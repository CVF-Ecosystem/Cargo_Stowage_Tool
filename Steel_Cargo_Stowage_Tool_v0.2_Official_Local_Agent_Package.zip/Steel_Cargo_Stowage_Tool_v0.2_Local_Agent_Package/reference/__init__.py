"""Contract reference checks only; not a production application or safety engine."""

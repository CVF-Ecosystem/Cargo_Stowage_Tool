"""Executable contract examples for the restricted v0.2 BOX scope.

This module checks synthetic record consistency, integer arithmetic and simplified
geometry. It does not authenticate users, verify engineering evidence, calculate
stability/stresses, solve packing, or grant permission for field operations.
"""
from datetime import datetime
from functools import lru_cache
import json
import re
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

from .canonical import content_hash

ROOT = Path(__file__).resolve().parents[1]
CORE_RULE_IDS = {"S-001", "S-002", "S-003", "S-004", "S-005", "S-006", "S-007", "S-008", "S-013"}
ENGINEERING_RULE_IDS = {"S-009", "S-010", "S-011"}
FORMAT_CHECKER = FormatChecker()


@FORMAT_CHECKER.checks("date-time", raises=(ValueError, TypeError))
def _date_time(value):
    """Project timestamp subset: calendar-valid seconds plus an explicit offset.

    jsonschema's base installation does not always provide date-time checking.
    Leap seconds are not accepted by this project encoding; preserve them in
    IntakeDraft for resolution instead of silently changing the timestamp.
    """
    if not isinstance(value, str):
        return True
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}[Tt]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[Zz]|[+-]\d{2}:\d{2})", value):
        return False
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00").replace("z", "+00:00"))
    return parsed.tzinfo is not None and parsed.utcoffset() is not None


@lru_cache(maxsize=1)
def schema_registry():
    schemas = {}
    resources = []
    for path in sorted((ROOT / "contracts/schemas").glob("*.schema.json")):
        schema = json.loads(path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        schemas[path.name.removesuffix(".schema.json")] = schema
        uri = schema.get("$id", path.as_uri())
        resources.append((uri, Resource.from_contents(schema)))
        resources.append((path.as_uri(), Resource.from_contents(schema)))
    return schemas, Registry().with_resources(resources)


def schema_errors(kind, value):
    schemas, registry = schema_registry()
    if kind not in schemas:
        return [f"Unknown schema kind {kind}"]
    validator = Draft202012Validator(schemas[kind], registry=registry, format_checker=FORMAT_CHECKER)
    try:
        return [f"{'/'.join(str(x) for x in e.absolute_path) or '$'}: {e.message}" for e in validator.iter_errors(value)]
    except Exception as exc:
        return [f"Schema reference resolution error: {exc}"]


def _key(record):
    return record["kind"], record["id"], record["version"]


def _refs(value):
    if isinstance(value, dict):
        if set(value) == {"kind", "id", "version", "sha256"}:
            yield value
        else:
            for child in value.values():
                yield from _refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from _refs(child)


def _overlap(a, b):
    return all(a[i] < b[i + 3] and b[i] < a[i + 3] for i in range(3))


def _covered(rect, supporters):
    """Exact rectangle-union coverage using integer cell boundaries."""
    x0, y0, x1, y1 = rect
    xs = {x0, x1}; ys = {y0, y1}
    for sx0, sy0, sx1, sy1 in supporters:
        xs.update((max(x0, min(x1, sx0)), max(x0, min(x1, sx1))))
        ys.update((max(y0, min(y1, sy0)), max(y0, min(y1, sy1))))
    xs = sorted(xs); ys = sorted(ys)
    for xa, xb in zip(xs, xs[1:]):
        for ya, yb in zip(ys, ys[1:]):
            if xa == xb or ya == yb:
                continue
            if not any(sx0 <= xa and xb <= sx1 and sy0 <= ya and yb <= sy1 for sx0, sy0, sx1, sy1 in supporters):
                return False
    return True


def validate_bundle(bundle, *, fixture_mode=False):
    """Return diagnostics; operationalEligible is always False.

    fixture_mode enables arithmetic checks on TEST_ONLY records. It is not a
    production bypass or approval mode. No callable in this package grants an
    authenticated user/agent authority.
    """
    issues = []

    def issue(code, message, subject="bundle"):
        issues.append({"code": code, "subject": subject, "message": message})

    report = {"scope": "CONTRACT_REFERENCE_ONLY", "testOnly": True, "operationalEligible": False, "issues": issues}
    if not fixture_mode:
        issue("REFERENCE_NOT_OPERATIONAL", "This reference harness does not grant operational eligibility")
    if not isinstance(bundle, dict) or not isinstance(bundle.get("records"), list):
        issue("BUNDLE_SHAPE", "Expected records list")
        report["contractChecksPass"] = False
        return report
    if bundle.get("testOnly") is not True:
        issue("FIXTURE_QUARANTINE", "This reference bundle must be explicitly testOnly")
    for error in schema_errors("fixture_bundle", bundle):
        issue("SCHEMA", error)
    index = {}
    for record in bundle["records"]:
        try:
            key = _key(record)
            if key in index:
                issue("DUPLICATE_RECORD", "Duplicate kind/id/version", str(key))
            index[key] = record
            content = record["content"]
            if content.get("id") != record["id"] or content.get("version") != record["version"]:
                issue("ENVELOPE_IDENTITY", "Envelope and content identity differ", str(key))
            if content.get("testOnly") is not True:
                issue("FIXTURE_QUARANTINE", "All reference content must be TEST_ONLY", str(key))
            actual = content_hash(content)
            if record.get("sha256") != actual:
                issue("CONTENT_HASH", "Envelope hash does not match immutable content", str(key))
            for error in schema_errors(record["kind"], content):
                issue("SCHEMA", error, str(key))
        except (KeyError, TypeError, ValueError) as exc:
            issue("RECORD_SHAPE", str(exc))
    for reference in _refs(bundle):
        key = _key(reference)
        target = index.get(key)
        if not target:
            issue("MISSING_REFERENCE", "Pinned reference target is absent", str(key))
        elif target["sha256"] != reference["sha256"]:
            issue("REFERENCE_HASH", "Reference hash is stale or incorrect", str(key))
    evidence_root = (ROOT / "tests/fixtures").resolve()
    for evidence in bundle.get("evidenceFiles", []):
        import hashlib
        path = (evidence_root / evidence["path"]).resolve()
        if not path.is_relative_to(evidence_root) or not path.is_file():
            issue("EVIDENCE_PATH", "Evidence path must name a bundled fixture file")
        elif hashlib.sha256(path.read_bytes()).hexdigest() != evidence["sha256"]:
            issue("EVIDENCE_FILE_HASH", "Evidence bytes do not match the recorded hash")
    if any(i["code"] in {"SCHEMA", "RECORD_SHAPE", "MISSING_REFERENCE", "ENVELOPE_IDENTITY"} for i in issues):
        report["contractChecksPass"] = False
        return report

    def resolve(reference):
        return index[_key(reference)]["content"]

    try:
        case = resolve(bundle["caseRef"])
        plan = resolve(bundle["planRef"])
        run = resolve(bundle["runRef"]) if bundle.get("runRef") else None
        receipt = resolve(bundle["validationRef"])
        decision = resolve(bundle["decisionRef"])
        vessel = resolve(case["vesselRef"])
        hold = resolve(case["holdRef"])
        manifest = resolve(case["manifestRef"])
        ruleset = resolve(case["ruleSetRef"])
        profiles = {r["id"]: resolve(r) for r in case["supportProfileRefs"]}
    except (KeyError, TypeError) as exc:
        issue("BUNDLE_REQUIRED_REFERENCE", str(exc))
        report["contractChecksPass"] = False
        return report

    if len(profiles) != len(case["supportProfileRefs"]):
        issue("PROFILE_VERSION_AMBIGUITY", "Only one pinned version of each support profile ID is allowed per case")
    _check_case(case, plan, vessel, hold, issue)
    placed_mass, boxes = _check_cargo(case, plan, manifest, hold, profiles, issue)
    _check_rules(case, vessel, manifest, profiles, ruleset, receipt, decision, placed_mass, issue)
    if plan["generation"]["method"] != "MANUAL_EDIT":
        if run is None:
            issue("RUN_REQUIRED", "Generated candidates require their originating optimization run")
        else:
            _check_run(case, plan, run, receipt, bundle["planRef"], issue)
    else:
        if not plan.get("parentPlanRef"):
            issue("MANUAL_PARENT_REQUIRED", "A manual edit must point to its immutable parent plan")
        elif plan["parentPlanRef"] == bundle["planRef"]:
            issue("MANUAL_PARENT_SELF", "Manual plan cannot be its own parent")
        else:
            parent = resolve(plan["parentPlanRef"])
            if parent["loadingCaseRef"] != plan["loadingCaseRef"]:
                issue("MANUAL_PARENT_CASE", "A manual revision must retain the exact parent loading case; rebase is a separate operation")
            if parent["id"] == plan["id"] and parent["version"] >= plan["version"]:
                issue("MANUAL_VERSION", "A manual revision must advance the parent plan version")
            if run is not None:
                ancestor_ref = plan["parentPlanRef"]
                ancestor = parent
                visited_ancestors = set()
                while ancestor["generation"]["method"] == "MANUAL_EDIT" and ancestor.get("parentPlanRef"):
                    key = _key(ancestor_ref)
                    if key in visited_ancestors:
                        issue("MANUAL_PARENT_CYCLE", "Manual ancestry contains a cycle")
                        break
                    visited_ancestors.add(key)
                    ancestor_ref = ancestor["parentPlanRef"]
                    ancestor = resolve(ancestor_ref)
                if ancestor["generation"].get("runId") != run["id"] or ancestor_ref not in run["planRefs"]:
                    issue("MANUAL_ORIGIN_RUN_BINDING", "Optional origin run must contain the generated ancestor, not the edited plan")
    _check_receipts(bundle, case, plan, receipt, decision, issue)
    _check_lifecycle(index, issue)
    report["observedPlacedMassKg"] = placed_mass
    report["observedChargedMassKg"] = case["existingCargoKg"] + placed_mass + case["plannedDunnageMassKg"]
    report["contractChecksPass"] = not issues
    return report


def _check_case(case, plan, vessel, hold, issue):
    if case["scope"] != "EMPTY_TARGET_HOLD" or not case["targetHoldEmptyConfirmed"]:
        issue("TARGET_HOLD_NOT_EMPTY", "The initial scope requires a confirmed empty target hold")
    if case["existingCargoLocation"] != "OUTSIDE_TARGET_HOLD":
        issue("EXISTING_CARGO_LOCATION", "Existing cargo must be outside the target hold")
    if case["vesselRef"] != hold["vesselRef"]:
        issue("HOLD_VESSEL_MISMATCH", "Hold belongs to a different vessel snapshot")
    if plan["loadingCaseRef"]["id"] != case["id"] or plan["loadingCaseRef"]["version"] != case["version"]:
        issue("PLAN_CASE_MISMATCH", "Plan does not target the selected case version")
    if plan["inputSnapshotSha256"] != plan["loadingCaseRef"]["sha256"]:
        issue("INPUT_SNAPSHOT_HASH", "Plan input hash must match its pinned loading case")
    if case["voyageCargoLimitKg"] > vessel["certificateCargoLimitKg"]:
        issue("VOYAGE_LIMIT_EXCEEDS_CERTIFICATE", "Voyage cargo allowance exceeds certified cargo limit")
    if case["existingCargoKg"] + case["plannedDunnageMassKg"] > case["voyageCargoLimitKg"]:
        issue("NO_LOAD_ALLOWANCE", "Existing cargo and planned dunnage already exceed the allowance")
    if case["allowanceBasis"] != "CARGO_PLUS_PLANNED_DUNNAGE":
        issue("ALLOWANCE_BASIS", "The case uses a different accounting basis")
    if case["validThroughDate"] < case["operatingDate"]:
        issue("CASE_DATE_ORDER", "Case valid-through precedes operating date")
    if case["operatingRegionId"] not in vessel["operatingRegionIds"]:
        issue("VESSEL_REGION_SCOPE", "Vessel profile does not cover the case region")
    if vessel["identityVerification"] != "VERIFIED" or case["inputVerification"] != "VERIFIED_INPUT":
        issue("INPUT_NOT_VERIFIED", "Case or vessel input is not declared verified")
    usable_certificates = []
    for certificate in vessel["certificates"]:
        if certificate["verification"] != "VERIFIED":
            continue
        if certificate["documentType"] == "SAFETY_INSPECTION":
            if certificate["validityKind"] == "DATED" and certificate.get("validFrom", "9999") <= case["operatingDate"] and certificate.get("validUntil", "0000") >= case["validThroughDate"]:
                usable_certificates.append(certificate)
    if not usable_certificates:
        issue("CERTIFICATE_VALIDITY", "No dated verified safety certificate covers the complete case interval")
    payload_source = vessel["cargoLimitEvidence"]["documentSha256"]
    if not any(c["documentSha256"] == payload_source for c in usable_certificates):
        issue("PAYLOAD_SOURCE_BINDING", "Payload source must bind the valid safety certificate used by the case")
    if case["layeredStackingEnabled"] and not case.get("layeredStackingGateEvidence"):
        issue("LAYERED_GATE_MISSING", "Layered capability requires an explicit gate evidence reference")
    clear = hold["clearances"]
    if clear["xMinMm"] + clear["xMaxMm"] >= hold["lengthMm"] or clear["yMinMm"] + clear["yMaxMm"] >= hold["widthMm"] or clear["topMm"] >= hold["heightMm"]:
        issue("EMPTY_USABLE_DOMAIN", "Declared clearances remove the usable domain")


def _check_cargo(case, plan, manifest, hold, profiles, issue):
    units = {u["id"]: u for u in manifest["cargoUnits"]}
    if len(units) != len(manifest["cargoUnits"]):
        issue("DUPLICATE_CARGO_ID", "Cargo unit IDs must be unique")
    if sum(u["massKg"] for u in manifest["cargoUnits"]) != manifest["declaredTotalMassKg"]:
        issue("MANIFEST_TOTAL", "Declared total differs from individual unit masses")
    selected_sets = [case["requiredUnitIds"], case["optionalUnitIds"], case["excludedUnitIds"]]
    all_selections = sum(selected_sets, [])
    if len(all_selections) != len(set(all_selections)) or set(all_selections) != set(units):
        issue("CASE_SELECTION_PARTITION", "Required/optional/excluded must partition manifest exactly once")
    if case["mode"] == "ALL_REQUIRED" and case["optionalUnitIds"]:
        issue("ALL_REQUIRED_HAS_OPTIONAL", "ALL_REQUIRED does not permit optional units")
    placed_ids = [p["cargoUnitId"] for p in plan["placements"]]
    unplaced_ids = [u["cargoUnitId"] for u in plan["unplaced"]]
    all_results = placed_ids + unplaced_ids + plan["excludedUnitIds"]
    if len(all_results) != len(set(all_results)) or set(all_results) != set(units):
        issue("PLAN_PARTITION", "Placed/unplaced/excluded must partition manifest exactly once")
    if set(plan["excludedUnitIds"]) != set(case["excludedUnitIds"]):
        issue("EXCLUDED_MISMATCH", "Plan exclusion differs from pinned case selection")
    groups = {g["id"]: g for g in manifest["groups"]}
    if len(groups) != len(manifest["groups"]):
        issue("DUPLICATE_GROUP_ID", "Manifest group IDs must be unique")
    grouped_ids = []
    for group in manifest["groups"]:
        grouped_ids += group["unitIds"]
        if not set(group["unitIds"]) <= set(units):
            issue("GROUP_UNKNOWN_UNIT", "Manifest group references an unknown cargo unit", group["id"])
        chosen = set(group["unitIds"]) & set(placed_ids)
        if chosen and chosen != set(group["unitIds"]):
            issue("GROUP_PARTIAL", "An ALL_OR_NONE group cannot be partially placed", group["id"])
        for uid in group["unitIds"]:
            if uid in units and units[uid].get("groupId") != group["id"]:
                issue("GROUP_MEMBERSHIP", "Group member and cargo groupId disagree", uid)
    if len(grouped_ids) != len(set(grouped_ids)):
        issue("GROUP_OVERLAP", "One cargo unit cannot belong to multiple groups")
    for unit in units.values():
        if unit.get("groupId") and (unit["groupId"] not in groups or unit["id"] not in groups[unit["groupId"]]["unitIds"]):
            issue("GROUP_MEMBERSHIP", "Cargo groupId is not reciprocated by group membership", unit["id"])
    placed_mass = sum(units[x]["massKg"] for x in set(placed_ids) if x in units)
    if case["existingCargoKg"] + placed_mass + case["plannedDunnageMassKg"] > case["voyageCargoLimitKg"]:
        issue("MASS_LIMIT", "Existing cargo + placed cargo + reserved dunnage exceeds allowance")
    boxes = {}; placements = {}
    clear = hold["clearances"]
    for placement in plan["placements"]:
        uid = placement["cargoUnitId"]
        if uid not in units:
            issue("UNKNOWN_CARGO_ID", "Placement does not refer to manifest", uid)
            continue
        unit = units[uid]
        profile_ref = unit.get("supportProfileRef")
        profile_id = profile_ref["id"] if profile_ref else unit.get("supportProfileId")
        profile = profiles.get(profile_id)
        if not profile:
            issue("PROFILE_NOT_PINNED", "Cargo support profile is not pinned by case", uid)
            continue
        if profile_ref and profile_ref not in case["supportProfileRefs"]:
            issue("PROFILE_REFERENCE_MISMATCH", "Cargo and case profile snapshots differ", uid)
        if profile["cargoType"] != unit["cargoType"]:
            issue("PROFILE_CARGO_TYPE", "Profile cargo type does not match cargo", uid)
        if profile["reviewState"] not in {"APPROVED", "TEST_ONLY_APPROVED"}:
            issue("PROFILE_NOT_APPROVED", "Profile is not reviewed for fixture checks", uid)
        if placement["yawDegrees"] not in profile["allowedYawDegrees"]:
            issue("ORIENTATION", "Yaw is not permitted by profile", uid)
        length, width = unit["lengthMm"], unit["widthMm"]
        if placement["yawDegrees"] in {90, 270}:
            length, width = width, length
        x, y, z = placement["xMm"], placement["yMm"], placement["zMm"]
        box = (x, y, z, x + length, y + width, z + unit["heightMm"])
        boxes[uid] = box; placements[uid] = placement
        if x < clear["xMinMm"] or y < clear["yMinMm"] or z < 0 or box[3] > hold["lengthMm"] - clear["xMaxMm"] or box[4] > hold["widthMm"] - clear["yMaxMm"] or box[5] > hold["heightMm"] - clear["topMm"]:
            issue("OUTSIDE_HOLD", "Placement exceeds clearances or physical BOX bounds", uid)
        if box[5] > profile["maxStackHeightMm"]:
            issue("STACK_HEIGHT", "Stack top exceeds approved profile height", uid)
        if placement["layer"] >= profile["maxLayers"]:
            issue("MAX_LAYERS", "Layer exceeds profile allowance", uid)
        for zone in hold["excludedZones"]:
            zbox = (zone["xMm"], zone["yMm"], zone["zMm"], zone["xMm"] + zone["lengthMm"], zone["yMm"] + zone["widthMm"], zone["zMm"] + zone["heightMm"])
            if _overlap(box, zbox):
                issue("EXCLUDED_ZONE", "Cargo intersects an excluded zone", uid)
    ids = list(boxes)
    for i, uid in enumerate(ids):
        for other in ids[i + 1:]:
            a, b = boxes[uid], boxes[other]
            if _overlap(a, b):
                issue("CARGO_OVERLAP", f"Cargo overlaps {other}", uid)
            elif a[2] < b[5] and b[2] < a[5]:
                gap = clear["betweenCargoMm"]
                if not (a[3] + gap <= b[0] or b[3] + gap <= a[0] or a[4] + gap <= b[1] or b[4] + gap <= a[1]):
                    issue("CARGO_CLEARANCE", f"Lateral clearance to {other} is insufficient", uid)
    _check_support(case, units, profiles, placements, boxes, issue)
    return placed_mass, boxes


def _check_support(case, units, profiles, placements, boxes, issue):
    graph = {uid: list(p["supportedByIds"]) for uid, p in placements.items()}
    visiting = set(); visited = set()

    def visit(uid):
        if uid in visiting:
            issue("SUPPORT_CYCLE", "Support graph has a cycle", uid)
            return
        if uid in visited:
            return
        visiting.add(uid)
        for lower in graph.get(uid, []):
            if lower not in placements:
                issue("SUPPORT_MISSING", "Supporter is not a placed cargo unit", uid)
            else:
                visit(lower)
        visiting.remove(uid); visited.add(uid)

    for uid in graph:
        visit(uid)
    for uid, placement in placements.items():
        unit = units[uid]
        profile_id = unit.get("supportProfileRef", {}).get("id", unit.get("supportProfileId"))
        profile = profiles[profile_id]
        support_ids = graph[uid]
        if len(set(support_ids)) != len(support_ids) or uid in support_ids:
            issue("SUPPORT_IDENTITY", "Duplicate/self support is invalid", uid)
        if placement["layer"] == 0:
            if support_ids or placement["zMm"] != profile["baseDunnageHeightMm"]:
                issue("GROUND_SUPPORT", "Ground cargo must sit on the declared base dunnage", uid)
            continue
        if not case["layeredStackingEnabled"] or profile["stackingMode"] != "FULL_BASE_SUPPORT":
            issue("LAYERING_DISABLED", "Upper layers are outside the enabled profile/case scope", uid)
        if not support_ids:
            issue("FLOATING_CARGO", "Upper cargo has no supporter", uid)
            continue
        supporter_rects = []
        for lower in support_ids:
            if lower not in placements:
                continue
            lower_p = placements[lower]
            lower_box = boxes[lower]
            lower_unit = units[lower]
            lower_profile_id = lower_unit.get("supportProfileRef", {}).get("id", lower_unit.get("supportProfileId"))
            lower_profile = profiles[lower_profile_id]
            if lower_profile["stackingMode"] != "FULL_BASE_SUPPORT":
                issue("LOWER_PROFILE_CANNOT_SUPPORT", "SINGLE_LAYER profile cannot support an upper tier", lower)
            if placement["layer"] != lower_p["layer"] + 1 or placement["zMm"] != lower_box[5] + profile["interlayerDunnageHeightMm"]:
                issue("SUPPORT_ELEVATION", "Support is not the previous tier at the declared dunnage elevation", uid)
            if profile_id not in lower_profile["compatibleUpperProfileIds"]:
                issue("STACK_COMPATIBILITY", "Upper profile is not approved on the lower profile", uid)
            supporter_rects.append((lower_box[0], lower_box[1], lower_box[3], lower_box[4]))
        box = boxes[uid]
        if not _covered((box[0], box[1], box[3], box[4]), supporter_rects):
            issue("SUPPORT_COVERAGE", "Approved simplified support envelopes do not cover the upper base", uid)
    children = {uid: set() for uid in placements}
    for upper, lowers in graph.items():
        for lower in lowers:
            if lower in children:
                children[lower].add(upper)
    for uid in placements:
        above = set(); queue = list(children[uid])
        while queue:
            nxt = queue.pop()
            if nxt not in above and nxt != uid:
                above.add(nxt); queue.extend(children[nxt])
        unit = units[uid]
        profile_id = unit.get("supportProfileRef", {}).get("id", unit.get("supportProfileId"))
        profile = profiles[profile_id]
        # Conservative upper bound: each supporter must tolerate all distinct
        # descendants. This does not calculate force sharing or actual stresses.
        if sum(units[x]["massKg"] for x in above) > profile["maxSupportedMassKg"]:
            issue("SUPPORTED_CARGO_MASS", "Net supported-cargo allowance is exceeded", uid)
        stack = above | {uid}
        if max(placements[x]["layer"] for x in stack) >= profile["maxLayers"]:
            issue("DESCENDANT_LAYER_LIMIT", "Upper tiers exceed the lower profile's total stack-layer allowance", uid)
        if max(boxes[x][5] for x in stack) > profile["maxStackHeightMm"]:
            issue("DESCENDANT_STACK_HEIGHT", "Upper stack top exceeds the lower profile's height allowance", uid)


def _check_rules(case, vessel, manifest, profiles, ruleset, receipt, decision, placed_mass, issue):
    cargo_types = {u["cargoType"] for u in manifest["cargoUnits"]}

    def scope_covers(scope):
        return vessel["vesselClass"] in scope["vesselClasses"] and case["operatingRegionId"] in scope["regionIds"] and cargo_types <= set(scope.get("cargoTypes", cargo_types))

    for profile in profiles.values():
        if not scope_covers(profile["scope"]):
            issue("PROFILE_SCOPE", "Pinned support profile is outside vessel/region scope", profile["id"])
    if ruleset["reviewState"] != "APPROVED" or not scope_covers(ruleset["scope"]):
        issue("RULESET_SCOPE", "Rule set must be approved for the whole case scope")
    if ruleset["effectiveFrom"] > case["operatingDate"] or ruleset.get("effectiveTo", "9999-12-31") < case["validThroughDate"]:
        issue("RULESET_VALIDITY", "Rule set does not cover the complete case interval")
    rule_ids = [r["id"] for r in ruleset["rules"]]
    enabled = {r["id"]: r for r in ruleset["rules"] if r["enabled"]}
    if len(rule_ids) != len(set(rule_ids)):
        issue("DUPLICATE_RULE_ID", "Rule IDs must be unique in the pinned rule set")
    if not CORE_RULE_IDS | ENGINEERING_RULE_IDS <= set(enabled):
        issue("MANDATORY_RULE_REMOVED", "A baseline core/engineering rule is absent or disabled")
    outcomes = receipt["ruleEvaluations"]
    outcome_ids = [r["ruleId"] for r in outcomes]
    if len(outcome_ids) != len(set(outcome_ids)) or set(outcome_ids) != set(enabled):
        issue("RULE_COVERAGE", "Exactly one outcome for every enabled rule is required")
    outcomes_by_id = {r["ruleId"]: r for r in outcomes}
    applicable_hard = []
    for rid, rule in enabled.items():
        outcome = outcomes_by_id.get(rid)
        if not outcome:
            continue
        if outcome["ruleVersion"] != rule["version"] or outcome["severity"] != rule["severity"]:
            issue("RULE_OUTCOME_IDENTITY", "Outcome does not match the pinned rule version/severity", rid)
        if rid in CORE_RULE_IDS and rule["severity"] not in {"HARD", "HARD_GATE", "GOVERNANCE"}:
            issue("MANDATORY_RULE_DOWNGRADE", "A core rule cannot be downgraded to a soft check", rid)
        source = rule["source"]
        applies = scope_covers(rule["scope"]) and source["effectiveFrom"] <= case["operatingDate"] and source.get("effectiveTo", "9999-12-31") >= case["validThroughDate"]
        if rid in CORE_RULE_IDS | ENGINEERING_RULE_IDS and not applies:
            issue("MANDATORY_RULE_APPLICABILITY", "Mandatory rule/source does not cover this case", rid)
        if applies and outcome["decision"] == "NOT_APPLICABLE":
            issue("FALSE_NOT_APPLICABLE", "Applicable rule cannot be omitted via NOT_APPLICABLE", rid)
        if not applies and outcome["decision"] != "NOT_APPLICABLE":
            issue("RULE_OUTSIDE_SCOPE", "A rule outside scope/date cannot be evaluated as active", rid)
        if outcome["decision"] in {"PASS", "NOT_APPLICABLE"} and not outcome["evidenceRefs"]:
            issue("RULE_EVIDENCE_MISSING", "PASS/NOT_APPLICABLE requires traceable evidence", rid)
        if rule["implementationCoverage"] in {"RUNTIME_REQUIRED", "EXTERNAL_REVIEW"} and outcome["decision"] == "PASS":
            issue("UNSUPPORTED_ASSURANCE", "The synthetic reference package has no evidence for runtime or engineering PASS", rid)
        if applies and rule["severity"] in {"HARD", "HARD_GATE", "GOVERNANCE"}:
            applicable_hard.append(outcome["decision"] == "PASS")
    expected_hard = bool(applicable_hard) and all(applicable_hard) and set(enabled) == set(outcome_ids)
    if receipt["hardChecksPassed"] != expected_hard:
        issue("HARD_AGGREGATE", "hardChecksPassed does not match applicable hard outcomes")
    if receipt["observedPlacedMassKg"] != placed_mass:
        issue("OBSERVED_MASS", "Validation receipt mass differs from recomputed unique placements")
    if not expected_hard and decision["decision"] in {"SELECTED", "ACCEPTED_WITH_CONDITIONS"}:
        issue("HARD_BLOCKS_SELECTION", "Missing/failed hard checks cannot produce a successful decision")


def _check_run(case, plan, run, receipt, plan_ref, issue):
    if run["loadingCaseRef"] != plan["loadingCaseRef"] or run["mode"] != case["mode"]:
        issue("RUN_CONTEXT", "Run mode/case is not the pinned plan input")
    status = run["status"]
    if status["candidate"] == "NONE":
        if run["planRefs"] or status["fulfillment"] != "NO_CANDIDATE":
            issue("NO_CANDIDATE_CONTRADICTION", "No-candidate status cannot carry candidate plans")
    else:
        if plan_ref not in run["planRefs"]:
            issue("RUN_PLAN_BINDING", "Selected plan is not a candidate of this run")
        placed = {p["cargoUnitId"] for p in plan["placements"]}
        fulfillment = "ALL_REQUIRED_PLACED" if set(case["requiredUnitIds"]) <= placed else "REQUIRED_MISSING"
        if status["fulfillment"] != fulfillment:
            issue("FULFILLMENT_STATUS", "Run fulfillment differs from actual required-unit placements")
        if status["candidate"] == "VALIDATED" and not receipt["hardChecksPassed"]:
            issue("CANDIDATE_NOT_VALIDATED", "VALIDATED requires the complete hard-check receipt")
    if status["proof"] == "PROVEN_INFEASIBLE":
        if status["termination"] != "COMPLETED" or status["candidate"] != "NONE" or run["planRefs"] or not run["proofEvidenceRefs"]:
            issue("FALSE_INFEASIBILITY", "A proved-infeasible result requires a completed proof and no candidate")
        if case["mode"] == "MAXIMIZE_OPTIONAL" and not case["requiredUnitIds"]:
            issue("OPTIONAL_EMPTY_FEASIBLE", "With valid preconditions and no required cargo, an empty optional selection remains feasible")
    if status["proof"] == "PROVEN_OPTIMAL" and (status["termination"] != "COMPLETED" or status["candidate"] != "VALIDATED" or status["fulfillment"] != "ALL_REQUIRED_PLACED" or not run["proofEvidenceRefs"]):
        issue("FALSE_OPTIMALITY", "An optimality claim requires a validated complete-required candidate and proof")
    if status["termination"] in {"TIME_LIMIT", "ERROR", "CANCELLED"} and status["proof"] != "NOT_PROVEN":
        issue("TERMINATION_NOT_PROOF", "This contract does not equate an interrupted run with proof")
    if datetime.fromisoformat(run["finishedAt"].replace("Z", "+00:00")) < datetime.fromisoformat(run["startedAt"].replace("Z", "+00:00")):
        issue("RUN_TIME_ORDER", "Run finished before it started")
    if plan["generation"]["runId"] != run["id"] or plan["generation"]["seed"] != run["seed"] or plan["generation"]["timeLimitMs"] != run["timeLimitMs"]:
        issue("RUN_PROVENANCE", "Plan generation metadata differs from run")


def _check_receipts(bundle, case, plan, receipt, decision, issue):
    if receipt["planRef"] != bundle["planRef"] or receipt["loadingCaseRef"] != bundle["caseRef"] or receipt["ruleSetRef"] != case["ruleSetRef"]:
        issue("VALIDATION_BINDING", "Validation receipt targets a different plan/case/run/rule snapshot")
    if plan["generation"]["method"] != "MANUAL_EDIT" and (not receipt.get("runRef") or receipt.get("runRef") != bundle.get("runRef")):
        issue("VALIDATION_RUN_BINDING", "Generated candidate validation must bind its run")
    if plan["generation"]["method"] == "MANUAL_EDIT" and receipt.get("runRef"):
        issue("MANUAL_VALIDATION_RUN", "The new manual validation receipt must omit the immutable originating solver result")
    if receipt["inputSnapshotSha256"] != bundle["caseRef"]["sha256"]:
        issue("VALIDATION_INPUT_HASH", "Validation input hash is stale")
    if decision["planRef"] != bundle["planRef"] or decision["validationRef"] != bundle["validationRef"]:
        issue("DECISION_BINDING", "Decision belongs to a different plan or validation receipt")
    if decision["decision"] in {"SELECTED", "ACCEPTED_WITH_CONDITIONS"}:
        issue("TEST_ONLY_DECISION", "TEST_ONLY records can never authorize real selection or field use")
    if decision["decisionType"] == "FIELD_REVIEW":
        if decision["actorRole"] != "ENGINEERING_REVIEWER":
            issue("FIELD_REVIEW_ROLE", "Field review must identify the designated engineering reviewer")
        if decision["decision"] == "ACCEPTED_WITH_CONDITIONS" and not decision["evidenceRefs"]:
            issue("FIELD_REVIEW_EVIDENCE", "Field review requires scoped evidence, not only a status label")
        if decision["decision"] == "ACCEPTED_WITH_CONDITIONS":
            required_review = {r["ruleId"] for r in receipt["ruleEvaluations"] if r["severity"] == "ENGINEERING_CHECK" and r["decision"] != "NOT_APPLICABLE"}
            if not required_review <= set(decision["coveredRuleIds"]):
                issue("FIELD_REVIEW_COVERAGE", "Field review evidence does not cover all applicable engineering checks")
    elif decision["decisionType"] == "USER_SELECTION" and decision["coveredRuleIds"]:
        issue("SELECTION_NOT_ENGINEERING_REVIEW", "User selection cannot supply engineering coverage")
    if decision.get("validUntil") and datetime.fromisoformat(decision["validUntil"].replace("Z", "+00:00")) < datetime.fromisoformat(decision["occurredAt"].replace("Z", "+00:00")):
        issue("DECISION_TIME_ORDER", "Decision validity ends before the decision event")


def _check_lifecycle(index, issue):
    for record in index.values():
        if record["kind"] != "lifecycle_event":
            continue
        event = record["content"]
        if event["eventType"] not in {"USER_SELECTED", "FIELD_HANDOFF_RECORDED", "REVOKED"}:
            continue
        if not event.get("receiptRef"):
            issue("EVENT_RECEIPT_MISSING", "Lifecycle event requires its decision receipt", event["id"])
            continue
        decision = index[_key(event["receiptRef"])]["content"]
        if decision["planRef"] != event["planRef"]:
            issue("EVENT_PLAN_BINDING", "Event and receipt refer to different plan content", event["id"])
        expected = {"USER_SELECTED": ("USER_SELECTION", "SELECTED"), "FIELD_HANDOFF_RECORDED": ("FIELD_REVIEW", "ACCEPTED_WITH_CONDITIONS"), "REVOKED": ("REVOCATION", "REVOKED")}[event["eventType"]]
        if (decision["decisionType"], decision["decision"]) != expected:
            issue("EVENT_DECISION_KIND", "Receipt decision type/result cannot cause this event", event["id"])
        if event["eventType"] in {"USER_SELECTED", "FIELD_HANDOFF_RECORDED"}:
            issue("TEST_ONLY_EVENT", "Synthetic content cannot represent an operational permission event", event["id"])

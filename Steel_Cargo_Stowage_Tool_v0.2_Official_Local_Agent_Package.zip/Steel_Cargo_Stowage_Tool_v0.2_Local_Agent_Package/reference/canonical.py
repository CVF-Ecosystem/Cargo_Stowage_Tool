"""STOWAGE-JSON-0.2 canonical bytes and hashes.

This is an explicitly defined project encoding, NOT an implementation of RFC 8785.
The backend is the authority for generating these bytes. Cross-language clients
must reproduce the test vectors exactly before generating hashes themselves.
"""
import hashlib
import json

ALGORITHM = "STOWAGE-JSON-0.2"
MAX_SAFE_INTEGER = 9007199254740991


def _check(value, path="$", *, keys=False):
    if value is None or isinstance(value, bool):
        return
    if isinstance(value, int):
        if not -MAX_SAFE_INTEGER <= value <= MAX_SAFE_INTEGER:
            raise ValueError(f"{path}: integer outside exact JavaScript range")
        return
    if isinstance(value, str):
        try:
            value.encode("utf-8", errors="strict")
        except UnicodeEncodeError as exc:
            raise ValueError(f"{path}: unpaired surrogate is not allowed") from exc
        return
    if isinstance(value, list):
        for i, item in enumerate(value):
            _check(item, f"{path}[{i}]")
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str) or not key.isascii():
                raise ValueError(f"{path}: all object keys must be ASCII strings")
            _check(item, f"{path}.{key}")
        return
    raise ValueError(f"{path}: unsupported JSON value {type(value).__name__}; floats are forbidden")


def canonical_bytes(content):
    """Sorted ASCII keys, semantic array order, compact UTF-8; no normalization.

    String code points are preserved; canonically equivalent Unicode spellings
    therefore remain distinct unless intake explicitly normalizes before creating
    the immutable content. No file BOM, trailing newline, or envelope is hashed.
    """
    _check(content)
    return json.dumps(
        content, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def content_hash(content):
    return hashlib.sha256(canonical_bytes(content)).hexdigest()


def envelope(kind, content):
    """Build a fixture envelope; this function confers no verification authority."""
    return {
        "kind": kind, "id": content["id"], "version": content["version"],
        "sha256": content_hash(content), "content": content,
    }


def ref(record):
    return {name: record[name] for name in ("kind", "id", "version", "sha256")}

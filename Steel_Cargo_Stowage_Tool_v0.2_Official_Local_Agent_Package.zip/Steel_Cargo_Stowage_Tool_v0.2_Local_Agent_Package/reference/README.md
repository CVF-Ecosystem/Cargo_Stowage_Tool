# Reference contract checks v0.2

Các file trong thư mục này là **mã tham chiếu có thể chạy để kiểm hợp đồng dữ liệu**. Đây chưa phải backend của ứng dụng, CargoSafetyEngine đã nghiệm thu, packing solver, CVF bridge hoặc bộ tính toán kỹ thuật tàu.

## Cách chạy

Từ thư mục gốc package, dùng môi trường Python riêng:

```bash
python -m pip install -r requirements.txt
python tests/run_all.py --output ../contract-evidence-local
```

`--output` là tùy chọn. Nếu có, thư mục kết quả phải nằm **ngoài package**. Test chỉ thay đổi bản sao trong bộ nhớ; không ghi vào schema hoặc fixtures. Runner tắt tạo bytecode cache trong package. Kết quả gồm log và receipt ghi command, runtime, hash đầu vào, từng test và các phạm vi chưa kiểm.

Python 3.12 là môi trường đã dùng để tạo bằng chứng đi kèm. Dependency kiểm schema được pin ở `jsonschema==4.26.0`. Đây không phải danh sách dependencies của ứng dụng tương lai.

## Ý nghĩa kết quả

`validate_bundle(bundle, fixture_mode=True)` có thể trả `contractChecksPass=true` cho dữ liệu giả lập nhất quán. Hàm **luôn trả `operationalEligible=false`**. Không dùng kết quả này làm quyền chọn phương án thực hoặc bàn giao hiện trường.

Fixture mẫu cố ý giữ:

- `testOnly=true` ở bundle và mọi record.
- `optimization_run.status.candidate=UNVALIDATED`.
- S-008/S-013 và các kiểm tra kỹ thuật S-009–S-011 là `NOT_EVALUATED`.
- `validation_receipt.hardChecksPassed=false`.
- `decision_receipt.decision=REJECTED`.

Nhờ vậy, một kết quả toán học/hình học của fixture không được diễn giải thành xác nhận danh tính, kiểm thử transaction, phê duyệt của kỹ sư hoặc nghiệm thu vận hành. `fixture_mode=False` không biến reference thành chế độ production; nó từ chối cấp điều kiện vận hành.

## Những gì reference thực sự kiểm

| Nhóm | Kiểm tra được thực hiện |
|---|---|
| Schema | Draft 2020-12, local `$ref`, fields, enum, date và timestamp có timezone; timestamp có bộ kiểm tra stdlib riêng vì cài `jsonschema` cơ bản không bảo đảm có date-time checker |
| Nội dung bất biến | Hash payload, ref đúng kind/ID/version/hash, identity envelope và payload khớp, không trùng record, source bytes fixture khớp hash |
| Khối lượng | Tổng từng bó, phân hoạch manifest và kết quả, hạn mức chứng nhận/chuyến, hàng hiện hữu ngoài hầm, phần dự phòng kê mới được giữ nguyên khi xếp một phần |
| Hình học | BOX, margin từng mặt, khoảng cách ngang, yaw 0/90/180/270, không overlap, không vào excluded zone, tọa độ đáy kê |
| Support đơn giản | Profile đã khai báo review và được pin, một version/profile ID/case, tương thích profile, DAG, tầng và cao độ, phủ đáy theo bao hỗ trợ đơn giản đã khai báo |
| Giới hạn chồng | Tính toàn bộ distinct descendants; mỗi supporter phải chịu được toàn bộ khối lượng cargo phía trên theo net allowance; tổng tầng và z đỉnh không vượt giới hạn của profile phía dưới |
| Rule/result | Đủ outcome, không bỏ/downgrade mandatory rule, không giả NOT_APPLICABLE, ngày/phạm vi, không tạo runtime/engineering PASS bằng fixture |
| Solver metadata | Không đồng nhất timeout với proof, required-unit fulfillment, plan thuộc run, VALIDATED đòi hard-check receipt tương ứng |
| Receipt/event | Gắn đúng plan/case/validation/run, không dùng user selection thay field review, engineering coverage, manual revision có parent đúng case và receipt mới |

**Support ở đây là một mô hình kiểm hình học có giới hạn.** FULL_BASE_SUPPORT chỉ được hiểu là bao hỗ trợ bảo thủ của cấu hình kê được chuyên môn chấp thuận. Code không suy ra bề mặt tiếp xúc thật của bó ống từ hình hộp. `maxSupportedMassKg` là net supported cargo allowance đã dành ảnh hưởng của kê/đệm theo hồ sơ; code không biến rating kết cấu thô thành allowance.

Tính descendant cargo là một chặn bảo thủ: mỗi lower supporter được kiểm với toàn bộ cargo ở phía trên của nó. Code không tính chia lực giữa nhiều gối, tải tiếp xúc, biến dạng hoặc ứng suất cục bộ. Các việc đó vẫn cần chuyên môn và dữ liệu thật theo gate tương ứng.

## Hash STOWAGE-JSON-0.2

Đây là quy tắc serialization riêng của dự án, **không tuyên bố là RFC 8785**:

```python
json.dumps(content, sort_keys=True, ensure_ascii=False,
           separators=(',', ':'), allow_nan=False).encode('utf-8')
```

Tiền điều kiện:

- JSON null/boolean/string/list/object và số nguyên trong khoảng `[-9007199254740991, 9007199254740991]`.
- Không nhận float, NaN hoặc infinity.
- Tên key là chuỗi ASCII. Giá trị chuỗi có thể là Unicode, nhưng không có lone surrogate.
- Không thêm BOM hoặc newline vào bytes được băm.
- Không chuẩn hóa Unicode ngầm. Nếu intake cần chuẩn hóa thì thực hiện và ghi nhận trước khi tạo snapshot.
- Thứ tự key được sort; thứ tự phần tử mảng giữ nguyên và có ý nghĩa.
- Chỉ băm immutable **content**, không băm envelope chứa `sha256`, trạng thái vòng đời hoặc receipt khác.

`hash_test_vectors.json` cung cấp content, bytes UTF-8 dạng hex và SHA-256 để các bản triển khai khác đối chiếu. Backend là nơi có thẩm quyền tạo hash. Client ngôn ngữ khác chưa vượt qua các vector này thì không tự tạo hash có thẩm quyền.

## Sửa tay và nguồn solver

`MANUAL_EDIT` tạo `PlanContent` mới với `parentPlanRef`, giữ đúng loading-case snapshot của parent. `generation` chỉ cần method và generatorVersion; không giả một lần solver mới. Receipt validation mới bỏ runRef; run ban đầu không bị sửa để thêm kết quả do người dùng kéo/thả. Nếu bundle giữ runRef nguồn thì nó chỉ truy được tới generated ancestor, không phải bằng chứng solver đã tạo bản sửa tay.

Đổi input/case là một thao tác rebase hoặc optimize riêng cần đặc tả của local implementation; không được lén biến thành manual revision của một case khác.

## Những gì phải làm tại local

Reference không thực thi authenticated sessions, chống giả actor, credential của agent, CVF ALLOW/BLOCK/ESCALATE, transaction DB, race/ETag, crash recovery, restore authorization, tính packing tối ưu, parser Excel/PDF hoặc khả năng thao tác của cẩu. Test có tên liên quan đến các trạng thái đó chỉ chứng minh **quan hệ dữ liệu và điều kiện chặn trên fixture**, không chứng minh đường runtime tương ứng đã chạy.

Agent local phải xây các test integration/E2E và bằng chứng kỹ thuật riêng trước khi đánh dấu các gate triển khai đạt. Không copy nguyên boolean `contractChecksPass` thành cờ “an toàn” trên giao diện.

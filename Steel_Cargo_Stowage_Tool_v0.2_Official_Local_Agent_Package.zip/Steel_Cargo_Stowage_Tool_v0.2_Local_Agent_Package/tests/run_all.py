"""Run the package's contract checks without modifying package inputs.

Usage: python tests/run_all.py [--output ../local-contract-evidence]
The optional output directory must be outside the package. These checks are not
operational acceptance, a solver, CVF integration, or engineering certification.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import platform
import sys
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class ObservedResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.observed = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.observed.append({"testCaseId": test.id(), "verdict": "PASS"})

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.observed.append({"testCaseId": test.id(), "verdict": "FAIL", "reason": str(err[1])})

    def addError(self, test, err):
        super().addError(test, err)
        self.observed.append({"testCaseId": test.id(), "verdict": "ERROR", "reason": str(err[1])})

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        self.observed.append({"testCaseId": test.id(), "verdict": "SKIP", "reason": reason})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve() if args.output else None
    if output and (output == ROOT or ROOT in output.parents):
        parser.error("Evidence output must be outside the package; package inputs are read-only")
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_*.py")
    result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=ObservedResult).run(suite)
    log = stream.getvalue()
    print(log, end="")
    inputs = {}
    for folder in ["contracts/schemas", "tests/fixtures", "reference", "tests"]:
        for path in sorted((ROOT / folder).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts and path.suffix in {".json", ".py", ".md"}:
                inputs[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    receipt = {
        "schemaVersion": "0.2", "receiptKind": "CONTRACT_CHECKS_ONLY",
        "testOnly": True, "operationalEligible": False,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "command": [sys.executable, *sys.argv],
        "runtime": {"python": platform.python_version(), "platform": platform.platform(), "jsonschema": importlib.metadata.version("jsonschema")},
        "summary": {"testsRun": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped), "successful": result.wasSuccessful()},
        "cases": result.observed,
        "inputFileSha256": inputs,
        "notEvaluated": ["Production backend authentication and authorization", "CVF source compatibility and running bridge", "Packing solver correctness or optimality", "Real vessel data, support engineering, stability, hull and local loads", "Field approval, crane access, operational loading sequence", "Database crash recovery, backup and restore runtime"],
        "limitations": ["Synthetic fixtures only", "A reference arithmetic/hash check cannot authenticate actor statements", "Passing tests do not mark any production gate as PASS"],
    }
    if output:
        output.mkdir(parents=True, exist_ok=True)
        (output / "contract_checks.log").write_text(log, encoding="utf-8")
        (output / "contract_check_receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("Evidence written:", output)
    print("CONTRACT CHECKS ONLY; operationalEligible=false; production/engineering gates unchanged.")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())

import json
from pathlib import Path
import unittest

from reference.canonical import canonical_bytes, content_hash, MAX_SAFE_INTEGER


class CanonicalTests(unittest.TestCase):
    def test_key_order_has_same_hash(self):
        self.assertEqual(content_hash({"b": 2, "a": 1}), content_hash({"a": 1, "b": 2}))

    def test_array_order_is_semantic(self):
        self.assertNotEqual(content_hash({"units": ["A", "B"]}), content_hash({"units": ["B", "A"]}))

    def test_one_millimetre_changes_hash(self):
        self.assertNotEqual(content_hash({"xMm": 0}), content_hash({"xMm": 1}))

    def test_one_kilogram_changes_hash(self):
        self.assertNotEqual(content_hash({"massKg": 1}), content_hash({"massKg": 2}))

    def test_exact_integer_boundary(self):
        self.assertEqual(canonical_bytes({"n": MAX_SAFE_INTEGER}), b'{"n":9007199254740991}')
        with self.assertRaises(ValueError):
            canonical_bytes({"n": MAX_SAFE_INTEGER + 1})

    def test_float_and_nonfinite_are_rejected(self):
        for value in [1.0, -0.0, float("nan"), float("inf")]:
            with self.subTest(value=repr(value)), self.assertRaises(ValueError):
                canonical_bytes({"n": value})

    def test_non_ascii_key_is_rejected(self):
        with self.assertRaises(ValueError):
            canonical_bytes({"tên": "Tàu"})

    def test_unpaired_surrogate_is_rejected(self):
        with self.assertRaises(ValueError):
            canonical_bytes({"name": "\ud800"})

    def test_unicode_values_are_preserved_as_utf8(self):
        self.assertEqual(canonical_bytes({"name": "Tàu thép"}), '{"name":"Tàu thép"}'.encode('utf-8'))

    def test_published_vectors(self):
        path = Path(__file__).resolve().parents[1] / "reference/hash_test_vectors.json"
        vectors = json.loads(path.read_text(encoding="utf-8"))
        for vector in vectors["vectors"]:
            with self.subTest(vector=vector["id"]):
                self.assertEqual(canonical_bytes(vector["content"]).hex(), vector["canonicalUtf8Hex"])
                self.assertEqual(content_hash(vector["content"]), vector["sha256"])

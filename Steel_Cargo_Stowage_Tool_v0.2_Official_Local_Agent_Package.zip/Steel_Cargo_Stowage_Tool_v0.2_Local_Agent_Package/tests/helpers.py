"""In-memory fixture mutation helpers; never write fixture sources."""
import copy
import json
from pathlib import Path

from reference.canonical import content_hash

ROOT = Path(__file__).resolve().parents[1]


def fixture():
    return json.loads((ROOT / "tests/fixtures/valid_bundle.json").read_text(encoding="utf-8"))


def entity(bundle, kind):
    return next(r["content"] for r in bundle["records"] if r["kind"] == kind)


def record(bundle, kind):
    return next(r for r in bundle["records"] if r["kind"] == kind)


def reseal(bundle):
    """Recompute the hash DAG to isolate domain defects from stale-hash defects."""
    index = {(r["kind"], r["id"], r["version"]): r for r in bundle["records"]}
    done = set(); active = set()

    def refresh(value):
        if isinstance(value, dict):
            if set(value) == {"kind", "id", "version", "sha256"}:
                key = (value["kind"], value["id"], value["version"])
                if key in index:
                    visit(key)
                    value["sha256"] = index[key]["sha256"]
            else:
                for child in value.values():
                    refresh(child)
        elif isinstance(value, list):
            for child in value:
                refresh(child)

    def visit(key):
        if key in done:
            return
        if key in active:
            raise ValueError("Fixture content references contain a hash cycle")
        active.add(key)
        item = index[key]
        refresh(item["content"])
        if "inputSnapshotSha256" in item["content"]:
            item["content"]["inputSnapshotSha256"] = item["content"]["loadingCaseRef"]["sha256"]
        item["sha256"] = content_hash(item["content"])
        active.remove(key); done.add(key)

    for key in index:
        visit(key)
    for name, value in bundle.items():
        if name != "records":
            refresh(value)
    return bundle


def optional_partial(bundle):
    case = entity(bundle, "loading_case")
    plan = entity(bundle, "plan_content")
    run = entity(bundle, "optimization_run")
    receipt = entity(bundle, "validation_receipt")
    case["mode"] = run["mode"] = "MAXIMIZE_OPTIONAL"
    case["requiredUnitIds"] = ["TEST-CU-001"]
    case["optionalUnitIds"] = ["TEST-CU-002"]
    plan["placements"] = plan["placements"][:1]
    plan["unplaced"] = [{"cargoUnitId": "TEST-CU-002", "reasonCode": "CAPACITY", "reason": "Synthetic optional-unit omission for contract test"}]
    receipt["observedPlacedMassKg"] = 2000


def layered(bundle):
    profile = entity(bundle, "support_profile")
    case = entity(bundle, "loading_case")
    plan = entity(bundle, "plan_content")
    profile.update(stackingMode="FULL_BASE_SUPPORT", maxLayers=2, maxSupportedMassKg=2000, maxStackHeightMm=1500, compatibleUpperProfileIds=[profile["id"]])
    case["layeredStackingEnabled"] = True
    case["layeredStackingGateEvidence"] = copy.deepcopy(case["voyageLimitEvidence"])
    plan["placements"][1].update(xMm=100, yMm=100, zMm=550, layer=1, supportedByIds=["TEST-CU-001"])


def manual_edit(bundle):
    parent_ref = copy.deepcopy(bundle["planRef"])
    edited = copy.deepcopy(record(bundle, "plan_content"))
    edited["version"] = edited["content"]["version"] = 2
    edited["content"]["parentPlanRef"] = parent_ref
    edited["content"]["generation"] = {"method": "MANUAL_EDIT", "generatorVersion": "SYNTHETIC_MANUAL_EDIT"}
    edited["content"]["placements"][0]["xMm"] += 1
    edited["sha256"] = content_hash(edited["content"])
    bundle["records"].append(edited)
    bundle["planRef"] = {k: edited[k] for k in ("kind", "id", "version", "sha256")}
    validation = copy.deepcopy(record(bundle, "validation_receipt"))
    validation["id"] = validation["content"]["id"] = "TEST-VALIDATION-MANUAL"
    validation["content"]["planRef"] = copy.deepcopy(bundle["planRef"])
    validation["content"].pop("runRef", None)
    validation["sha256"] = content_hash(validation["content"])
    bundle["records"].append(validation)
    bundle["validationRef"] = {k: validation[k] for k in ("kind", "id", "version", "sha256")}
    decision = copy.deepcopy(record(bundle, "decision_receipt"))
    decision["id"] = decision["content"]["id"] = "TEST-DECISION-MANUAL"
    decision["content"]["planRef"] = copy.deepcopy(bundle["planRef"])
    decision["content"]["validationRef"] = copy.deepcopy(bundle["validationRef"])
    decision["sha256"] = content_hash(decision["content"])
    bundle["records"].append(decision)
    bundle["decisionRef"] = {k: decision[k] for k in ("kind", "id", "version", "sha256")}
    bundle.pop("runRef", None)

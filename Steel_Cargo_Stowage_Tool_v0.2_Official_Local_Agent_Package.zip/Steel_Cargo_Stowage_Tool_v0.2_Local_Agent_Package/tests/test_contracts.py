"""Independent boundary examples for the revised contracts, using TEST_ONLY data."""
import copy
import json
from pathlib import Path
import unittest

from reference.validator import validate_bundle, schema_errors, schema_registry
from reference.canonical import content_hash
from helpers import fixture, entity, record, reseal, optional_partial, layered, manual_edit, ROOT


class SchemaTests(unittest.TestCase):
    def test_all_definitions_compile(self):
        schemas, _ = schema_registry()
        self.assertGreaterEqual(len(schemas), 14)

    def test_bundle_and_all_content_fixtures(self):
        bundle = fixture()
        self.assertEqual(schema_errors("fixture_bundle", bundle), [])
        for item in bundle["records"]:
            with self.subTest(kind=item["kind"]):
                self.assertEqual(schema_errors(item["kind"], item["content"]), [])

    def test_R01_mixed_gross_tonnage_kg_field_rejected(self):
        obj = entity(fixture(), "vessel_profile")
        obj["grossTonnageOrFullLoadKg"] = 999000
        self.assertTrue(schema_errors("vessel_profile", obj))

    def test_R06_loading_case_version_is_representable(self):
        obj = entity(fixture(), "loading_case")
        obj["version"] = 2
        self.assertEqual(schema_errors("loading_case", obj), [])

    def test_R06_plan_cannot_contain_its_own_hash_or_lifecycle_status(self):
        for name, value in [("planSha256", "0" * 64), ("planStatus", "USER_SELECTED")]:
            obj = entity(fixture(), "plan_content")
            obj[name] = value
            with self.subTest(field=name):
                self.assertTrue(schema_errors("plan_content", obj))

    def test_R10_incomplete_intake_draft_is_representable(self):
        obj = entity(fixture(), "intake_draft")
        self.assertEqual(schema_errors("intake_draft", obj), [])
        self.assertNotIn("voyageCargoLimitKg", obj)
        self.assertEqual(obj["fields"][0]["status"], "MISSING_REQUIRED")

    def test_R11_safety_certificate_without_expiry_is_rejected(self):
        obj = entity(fixture(), "vessel_profile")
        del obj["certificates"][0]["validUntil"]
        self.assertTrue(schema_errors("vessel_profile", obj))

    def test_R11_invalid_date_format_is_rejected(self):
        obj = entity(fixture(), "loading_case")
        obj["operatingDate"] = "31-10-2026"
        self.assertTrue(schema_errors("loading_case", obj))

    def test_R11_timestamp_format_is_checked_without_optional_packages(self):
        for value in ["not-a-time", "2026-02-30T12:00:00+07:00", "2026-10-31T10:00:00", "2026-10-31T10:00:60Z"]:
            obj = entity(fixture(), "optimization_run")
            obj["finishedAt"] = value
            with self.subTest(value=value):
                self.assertTrue(schema_errors("optimization_run", obj))

    def test_R05_trapezoid_is_not_silently_enabled(self):
        obj = entity(fixture(), "hold_profile")
        obj["geometryType"] = "TRAPEZOID"
        self.assertTrue(schema_errors("hold_profile", obj))

    def test_R09_fractional_kg_cannot_be_truncated_by_schema(self):
        obj = entity(fixture(), "manifest")
        obj["cargoUnits"][0]["massKg"] = 2000.5
        self.assertTrue(schema_errors("manifest", obj))

    def test_R03_support_capacity_basis_is_required(self):
        obj = entity(fixture(), "support_profile")
        del obj["supportedMassBasis"]
        self.assertTrue(schema_errors("support_profile", obj))


class DomainTests(unittest.TestCase):
    def result(self, mutation=None, *, seal=True, fixture_mode=True):
        obj = fixture()
        if mutation:
            mutation(obj)
        if seal:
            reseal(obj)
        return validate_bundle(obj, fixture_mode=fixture_mode)

    def expect_error(self, code, mutation, *, seal=True):
        result = self.result(mutation, seal=seal)
        self.assertFalse(result["contractChecksPass"], result)
        self.assertIn(code, {i["code"] for i in result["issues"]}, result)
        self.assertFalse(result["operationalEligible"])

    def test_reference_fixture_is_mathematically_consistent_but_not_operational(self):
        result = self.result()
        self.assertTrue(result["contractChecksPass"], result)
        self.assertEqual(result["observedPlacedMassKg"], 4000)
        self.assertEqual(result["observedChargedMassKg"], 15000)
        self.assertFalse(result["operationalEligible"])

    def test_reference_mode_is_never_a_production_authorizer(self):
        result = self.result(fixture_mode=False)
        self.assertFalse(result["contractChecksPass"])
        self.assertIn("REFERENCE_NOT_OPERATIONAL", {i["code"] for i in result["issues"]})

    def test_R06_tampered_content_without_rehash_fails(self):
        self.expect_error("CONTENT_HASH", lambda b: entity(b, "plan_content")["placements"][0].update(xMm=101), seal=False)

    def test_R06_stale_top_level_ref_fails(self):
        self.expect_error("REFERENCE_HASH", lambda b: b["planRef"].update(sha256="0" * 64), seal=False)

    def test_R06_duplicate_record_identity_fails(self):
        self.expect_error("DUPLICATE_RECORD", lambda b: b["records"].append(copy.deepcopy(b["records"][0])))

    def test_R01_mass_exact_limit_passes_arithmetic(self):
        result = self.result(lambda b: entity(b, "loading_case").update(voyageCargoLimitKg=15000))
        self.assertTrue(result["contractChecksPass"], result)

    def test_R01_one_kg_over_limit_fails(self):
        self.expect_error("MASS_LIMIT", lambda b: entity(b, "loading_case").update(voyageCargoLimitKg=14999))

    def test_R01_voyage_limit_cannot_exceed_certificate(self):
        self.expect_error("VOYAGE_LIMIT_EXCEEDS_CERTIFICATE", lambda b: entity(b, "loading_case").update(voyageCargoLimitKg=500001))

    def test_R07_partial_plan_keeps_new_dunnage_reserve(self):
        result = self.result(optional_partial)
        self.assertTrue(result["contractChecksPass"], result)
        self.assertEqual(result["observedChargedMassKg"], 13000)

    def test_R02_target_hold_not_confirmed_empty_fails(self):
        self.expect_error("SCHEMA", lambda b: entity(b, "loading_case").update(targetHoldEmptyConfirmed=False))

    def test_R02_existing_cargo_inside_target_scope_fails(self):
        self.expect_error("SCHEMA", lambda b: entity(b, "loading_case").update(existingCargoLocation="INSIDE_TARGET_HOLD"))

    def test_R09_duplicate_cargo_ids_fail(self):
        self.expect_error("DUPLICATE_CARGO_ID", lambda b: entity(b, "manifest")["cargoUnits"][1].update(id="TEST-CU-001"))

    def test_R09_unknown_placed_cargo_fails(self):
        self.expect_error("UNKNOWN_CARGO_ID", lambda b: entity(b, "plan_content")["placements"][0].update(cargoUnitId="UNKNOWN"))

    def test_R09_placed_and_unplaced_cannot_overlap(self):
        self.expect_error("PLAN_PARTITION", lambda b: entity(b, "plan_content")["unplaced"].append({"cargoUnitId": "TEST-CU-001", "reasonCode": "OTHER", "reason": "duplicate"}))

    def test_R09_no_silent_missing_cargo(self):
        self.expect_error("PLAN_PARTITION", lambda b: entity(b, "plan_content")["placements"].pop())

    def test_R09_wrong_declared_manifest_total_fails(self):
        self.expect_error("MANIFEST_TOTAL", lambda b: entity(b, "manifest").update(declaredTotalMassKg=3999))

    def test_R09_wrong_receipt_mass_fails(self):
        self.expect_error("OBSERVED_MASS", lambda b: entity(b, "validation_receipt").update(observedPlacedMassKg=1))

    def test_R08_partial_all_or_none_group_fails(self):
        def mutation(b):
            optional_partial(b)
            m = entity(b, "manifest")
            m["groups"] = [{"id": "LOT-A", "unitIds": ["TEST-CU-001", "TEST-CU-002"], "policy": "ALL_OR_NONE"}]
            for unit in m["cargoUnits"]:
                unit["groupId"] = "LOT-A"
        self.expect_error("GROUP_PARTIAL", mutation)

    def test_R05_box_exact_boundary_passes(self):
        result = self.result(lambda b: entity(b, "plan_content")["placements"][0].update(xMm=7900))
        self.assertTrue(result["contractChecksPass"], result)

    def test_R05_box_boundary_one_mm_out_fails(self):
        self.expect_error("OUTSIDE_HOLD", lambda b: entity(b, "plan_content")["placements"][0].update(xMm=7901))

    def test_R05_lateral_gap_exact_boundary_passes(self):
        result = self.result(lambda b: entity(b, "plan_content")["placements"][1].update(yMm=1150))
        self.assertTrue(result["contractChecksPass"], result)

    def test_R05_lateral_gap_one_mm_short_fails(self):
        self.expect_error("CARGO_CLEARANCE", lambda b: entity(b, "plan_content")["placements"][1].update(yMm=1149))

    def test_R05_actual_overlap_fails(self):
        self.expect_error("CARGO_OVERLAP", lambda b: entity(b, "plan_content")["placements"][1].update(yMm=1099))

    def test_R05_yaw_90_changes_occupied_dimensions(self):
        def mutation(b):
            entity(b, "support_profile")["allowedYawDegrees"].append(90)
            entity(b, "manifest")["cargoUnits"][0].update(lengthMm=1000, widthMm=500)
            entity(b, "plan_content")["placements"][0]["yawDegrees"] = 90
        result = self.result(mutation)
        self.assertTrue(result["contractChecksPass"], result)

    def test_R05_yaw_must_be_permitted_by_profile(self):
        self.expect_error("ORIENTATION", lambda b: entity(b, "plan_content")["placements"][0].update(yawDegrees=90))

    def test_R05_excluded_zone_intersection_fails(self):
        self.expect_error("EXCLUDED_ZONE", lambda b: entity(b, "hold_profile")["excludedZones"].append({"id": "OBSTACLE", "xMm": 100, "yMm": 100, "zMm": 100, "lengthMm": 1, "widthMm": 1, "heightMm": 1}))

    def test_R05_clearance_cannot_remove_whole_hold(self):
        self.expect_error("EMPTY_USABLE_DOMAIN", lambda b: entity(b, "hold_profile")["clearances"].update(xMinMm=20000))

    def test_R07_base_dunnage_elevation_is_not_ignored(self):
        self.expect_error("GROUND_SUPPORT", lambda b: entity(b, "plan_content")["placements"][0].update(zMm=0))

    def test_R07_dunnage_can_make_height_infeasible(self):
        def mutation(b):
            entity(b, "support_profile")["baseDunnageHeightMm"] = 2600
            for placement in entity(b, "plan_content")["placements"]:
                placement["zMm"] = 2600
        self.expect_error("OUTSIDE_HOLD", mutation)

    def test_R03_revoked_profile_fails(self):
        self.expect_error("PROFILE_NOT_APPROVED", lambda b: entity(b, "support_profile").update(reviewState="REVOKED"))

    def test_R03_wrong_profile_cargo_type_fails(self):
        self.expect_error("PROFILE_CARGO_TYPE", lambda b: entity(b, "support_profile").update(cargoType="BUNDLED_PIPE"))

    def test_R03_profile_outside_region_fails(self):
        self.expect_error("PROFILE_SCOPE", lambda b: entity(b, "support_profile")["scope"].update(regionIds=["ANOTHER_REGION"]))

    def test_R03_two_versions_of_same_profile_are_ambiguous(self):
        def mutation(b):
            second = copy.deepcopy(record(b, "support_profile"))
            second["version"] = second["content"]["version"] = 2
            second["sha256"] = content_hash(second["content"])
            b["records"].append(second)
            entity(b, "loading_case")["supportProfileRefs"].append({k: second[k] for k in ("kind", "id", "version", "sha256")})
        self.expect_error("PROFILE_VERSION_AMBIGUITY", mutation)

    def test_R03_synthetic_two_tier_full_base_math(self):
        result = self.result(layered)
        self.assertTrue(result["contractChecksPass"], result)
        self.assertFalse(result["operationalEligible"])

    def test_R03_partial_support_footprint_fails(self):
        def mutation(b):
            layered(b)
            entity(b, "plan_content")["placements"][1]["xMm"] += 1
        self.expect_error("SUPPORT_COVERAGE", mutation)

    def test_R03_support_descendant_mass_limit_fails(self):
        def mutation(b):
            layered(b)
            entity(b, "support_profile")["maxSupportedMassKg"] = 1999
        self.expect_error("SUPPORTED_CARGO_MASS", mutation)

    def test_R03_supported_mass_includes_every_upper_tier(self):
        def mutation(b):
            layered(b)
            profile = entity(b, "support_profile")
            profile.update(maxLayers=3, maxSupportedMassKg=3500)
            manifest = entity(b, "manifest")
            third = copy.deepcopy(manifest["cargoUnits"][0])
            third["id"] = "TEST-CU-003"
            manifest["cargoUnits"].append(third)
            manifest["declaredTotalMassKg"] = 6000
            entity(b, "loading_case")["requiredUnitIds"].append("TEST-CU-003")
            entity(b, "plan_content")["placements"].append({"cargoUnitId": "TEST-CU-003", "xMm": 100, "yMm": 100, "zMm": 1000, "yawDegrees": 0, "layer": 2, "supportedByIds": ["TEST-CU-002"]})
            entity(b, "validation_receipt")["observedPlacedMassKg"] = 6000
        self.expect_error("SUPPORTED_CARGO_MASS", mutation)

    def test_R03_support_cycle_fails(self):
        def mutation(b):
            layered(b)
            entity(b, "plan_content")["placements"][0]["supportedByIds"] = ["TEST-CU-002"]
        self.expect_error("SUPPORT_CYCLE", mutation)

    def test_R03_single_layer_lower_profile_cannot_support_upper_cargo(self):
        def mutation(b):
            layered(b)
            upper = copy.deepcopy(record(b, "support_profile"))
            upper["id"] = upper["content"]["id"] = "TEST-SUPPORT-UPPER"
            upper["sha256"] = content_hash(upper["content"])
            b["records"].append(upper)
            upper_ref = {k: upper[k] for k in ("kind", "id", "version", "sha256")}
            entity(b, "loading_case")["supportProfileRefs"].append(copy.deepcopy(upper_ref))
            entity(b, "manifest")["cargoUnits"][1]["supportProfileRef"] = copy.deepcopy(upper_ref)
            entity(b, "support_profile").update(stackingMode="SINGLE_LAYER", maxLayers=1, compatibleUpperProfileIds=[upper["id"]])
        self.expect_error("LOWER_PROFILE_CANNOT_SUPPORT", mutation)

    def test_R03_lower_profile_height_applies_to_upper_descendants(self):
        def mutation(b):
            layered(b)
            upper = copy.deepcopy(record(b, "support_profile"))
            upper["id"] = upper["content"]["id"] = "TEST-SUPPORT-UPPER"
            upper["sha256"] = content_hash(upper["content"])
            b["records"].append(upper)
            upper_ref = {k: upper[k] for k in ("kind", "id", "version", "sha256")}
            entity(b, "loading_case")["supportProfileRefs"].append(copy.deepcopy(upper_ref))
            entity(b, "manifest")["cargoUnits"][1]["supportProfileRef"] = copy.deepcopy(upper_ref)
            entity(b, "support_profile").update(maxStackHeightMm=800, compatibleUpperProfileIds=[upper["id"]])
        self.expect_error("DESCENDANT_STACK_HEIGHT", mutation)

    def test_R03_no_layered_gate_fails(self):
        def mutation(b):
            layered(b)
            entity(b, "loading_case").pop("layeredStackingGateEvidence")
        self.expect_error("SCHEMA", mutation)

    def test_R04_omitted_rule_outcome_fails(self):
        self.expect_error("RULE_COVERAGE", lambda b: entity(b, "validation_receipt")["ruleEvaluations"].pop())

    def test_R04_mandatory_rule_cannot_be_disabled(self):
        self.expect_error("MANDATORY_RULE_REMOVED", lambda b: entity(b, "rule_set")["rules"][0].update(enabled=False))

    def test_R04_false_not_applicable_fails(self):
        self.expect_error("FALSE_NOT_APPLICABLE", lambda b: entity(b, "validation_receipt")["ruleEvaluations"][0].update(decision="NOT_APPLICABLE"))

    def test_R04_unknown_hard_cannot_be_selected(self):
        def mutation(b):
            entity(b, "validation_receipt")["ruleEvaluations"][6]["decision"] = "NOT_EVALUATED"
            entity(b, "decision_receipt")["decision"] = "SELECTED"
        self.expect_error("HARD_BLOCKS_SELECTION", mutation)

    def test_R04_false_hard_pass_aggregate_fails(self):
        self.expect_error("HARD_AGGREGATE", lambda b: entity(b, "validation_receipt").update(hardChecksPassed=True))

    def test_R12_reference_cannot_fabricate_runtime_pass(self):
        self.expect_error("UNSUPPORTED_ASSURANCE", lambda b: entity(b, "validation_receipt")["ruleEvaluations"][-1].update(decision="PASS", evidenceRefs=["FAKE-AUTH"]))

    def test_R08_timeout_with_candidate_is_not_proof(self):
        result = self.result(lambda b: entity(b, "optimization_run")["status"].update(termination="TIME_LIMIT"))
        self.assertTrue(result["contractChecksPass"], result)

    def test_R08_timeout_cannot_claim_infeasible(self):
        self.expect_error("TERMINATION_NOT_PROOF", lambda b: entity(b, "optimization_run")["status"].update(termination="TIME_LIMIT", proof="PROVEN_INFEASIBLE"))

    def test_R08_candidate_contradicts_proven_infeasible(self):
        self.expect_error("FALSE_INFEASIBILITY", lambda b: entity(b, "optimization_run")["status"].update(proof="PROVEN_INFEASIBLE"))

    def test_R08_unvalidated_candidate_cannot_be_marked_validated(self):
        self.expect_error("CANDIDATE_NOT_VALIDATED", lambda b: entity(b, "optimization_run")["status"].update(candidate="VALIDATED"))

    def test_R08_wrong_required_fulfillment_fails(self):
        def mutation(b):
            optional_partial(b)
            entity(b, "loading_case")["requiredUnitIds"] = ["TEST-CU-001", "TEST-CU-002"]
            entity(b, "loading_case")["optionalUnitIds"] = []
        self.expect_error("FULFILLMENT_STATUS", mutation)

    def test_R11_certificate_must_cover_end_of_case(self):
        self.expect_error("CERTIFICATE_VALIDITY", lambda b: entity(b, "vessel_profile")["certificates"][0].update(validUntil="2026-11-01"))

    def test_R11_certificate_end_date_is_inclusive(self):
        result = self.result(lambda b: entity(b, "vessel_profile")["certificates"][0].update(validUntil="2026-11-02"))
        self.assertTrue(result["contractChecksPass"], result)

    def test_R11_restored_old_certificate_cannot_cover_new_case(self):
        def mutation(b):
            entity(b, "loading_case").update(operatingDate="2029-01-01", validThroughDate="2029-01-02")
        self.expect_error("CERTIFICATE_VALIDITY", mutation)

    def test_R13_future_rule_does_not_become_active(self):
        self.expect_error("MANDATORY_RULE_APPLICABILITY", lambda b: entity(b, "rule_set")["rules"][0]["source"].update(effectiveFrom="2027-05-01"))

    def test_R06_old_receipt_cannot_attach_to_new_plan_version(self):
        def mutation(b):
            second = copy.deepcopy(record(b, "plan_content"))
            second["version"] = second["content"]["version"] = 2
            second["content"]["placements"][0]["xMm"] += 1
            second["sha256"] = content_hash(second["content"])
            b["records"].append(second)
            b["planRef"] = {k: second[k] for k in ("kind", "id", "version", "sha256")}
        self.expect_error("VALIDATION_BINDING", mutation)

    def test_R04_handoff_event_cannot_reuse_rejected_selection(self):
        def mutation(b):
            event = entity(b, "lifecycle_event")
            event.update(eventType="FIELD_HANDOFF_RECORDED", receiptRef=copy.deepcopy(b["decisionRef"]))
        self.expect_error("EVENT_DECISION_KIND", mutation)

    def test_R04_field_review_must_cover_engineering_checks(self):
        def mutation(b):
            entity(b, "decision_receipt").update(decisionType="FIELD_REVIEW", actorRole="ENGINEERING_REVIEWER", decision="ACCEPTED_WITH_CONDITIONS", evidenceRefs=["TEST_REVIEW"], coveredRuleIds=["S-009"])
        self.expect_error("FIELD_REVIEW_COVERAGE", mutation)

    def test_R06_manual_edit_has_new_plan_and_preserves_original_run(self):
        b = fixture()
        original_run_sha = record(b, "optimization_run")["sha256"]
        manual_edit(b)
        reseal(b)
        result = validate_bundle(b, fixture_mode=True)
        self.assertTrue(result["contractChecksPass"], result)
        self.assertEqual(record(b, "optimization_run")["sha256"], original_run_sha)
        self.assertEqual(b["planRef"]["version"], 2)
        self.assertNotIn("runRef", b)
        self.assertFalse(result["operationalEligible"])

    def test_R06_manual_validation_cannot_reuse_origin_run_binding(self):
        def mutation(b):
            origin_run = copy.deepcopy(b["runRef"])
            manual_edit(b)
            next(r["content"] for r in b["records"] if r["id"] == "TEST-VALIDATION-MANUAL")["runRef"] = origin_run
        self.expect_error("MANUAL_VALIDATION_RUN", mutation)

    def test_R06_manual_parent_cannot_be_from_different_case(self):
        def mutation(b):
            manual_edit(b)
            second_case = copy.deepcopy(record(b, "loading_case"))
            second_case["id"] = second_case["content"]["id"] = "TEST-CASE-OTHER"
            second_case["sha256"] = content_hash(second_case["content"])
            b["records"].append(second_case)
            case_ref = {k: second_case[k] for k in ("kind", "id", "version", "sha256")}
            edited = next(r["content"] for r in b["records"] if r["kind"] == "plan_content" and r["version"] == 2)
            edited["loadingCaseRef"] = copy.deepcopy(case_ref)
            b["caseRef"] = copy.deepcopy(case_ref)
            validation = next(r["content"] for r in b["records"] if r["id"] == "TEST-VALIDATION-MANUAL")
            validation["loadingCaseRef"] = copy.deepcopy(case_ref)
        self.expect_error("MANUAL_PARENT_CASE", mutation)

    def test_R06_evidence_hash_is_checked_against_bytes(self):
        self.expect_error("EVIDENCE_FILE_HASH", lambda b: b["evidenceFiles"][0].update(sha256="0" * 64))

    def test_evidence_path_cannot_escape_fixture_directory(self):
        self.expect_error("EVIDENCE_PATH", lambda b: b["evidenceFiles"][0].update(path="../run_all.py"))

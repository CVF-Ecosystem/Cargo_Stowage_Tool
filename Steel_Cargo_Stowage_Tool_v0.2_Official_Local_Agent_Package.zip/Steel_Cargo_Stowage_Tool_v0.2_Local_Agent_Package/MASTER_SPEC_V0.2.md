# Đặc tả chính thức Steel Cargo Stowage Tool v0.2

## 1 Mục tiêu sản phẩm

Từ manifest hàng, hồ sơ tàu/sà lan và số đo vùng hầm hữu dụng, công cụ tạo phương án sơ bộ bố trí từng bó thép; kiểm tra các điều kiện đã có đủ dữ liệu; hiển thị vị trí bằng 2D/3D; thống kê hàng xếp/chưa xếp; lưu, so sánh và ghi nhận lựa chọn của người dùng. Người có trách nhiệm thực hiện review kỹ thuật và hiện trường theo quy trình đơn vị.

Đối tượng sử dụng bản đầu là một người vận hành trên PC local. Giao diện, lý do lỗi, tooltip và báo cáo cho người dùng bằng tiếng Việt. Ngày hiển thị dd-mm-yyyy; lưu thời gian theo ISO-8601 có timezone và ngày hoạt động theo Asia/Ho_Chi_Minh. Tên kỹ thuật/ID trong API có thể bằng tiếng Anh.

## 2 Mức hoàn thiện của package

Package này là yêu cầu chính thức cho công việc với Agent local. Nó bao gồm schema, fixtures và reference contract checks có thể chạy. Nó chưa bao gồm một ứng dụng FE/BE hoàn chỉnh, optimizer sản xuất, chứng nhận CVF tích hợp hoặc hồ sơ kỹ thuật của phương tiện thật.

Nội dung SPECIFIED đã được chốt để triển khai trong phạm vi nêu dưới đây. Tham số kỹ thuật và nguồn pháp lý cụ thể vẫn cần người được đơn vị giao trách nhiệm xác minh. Phân biệt ba mốc: chốt tài liệu, nghiệm thu ứng dụng chạy thật, chấp nhận điều kiện hiện trường.

## 3 Phạm vi khởi đầu

### 3.1 Phương tiện và hầm

- Một loading case tương ứng một phương tiện và một hầm mục tiêu dạng BOX.
- Hầm mục tiêu bắt buộc đã được xác nhận trống; vật cản cố định được mô tả bằng excluded zones.
- Hàng hiện hữu ở khu vực khác vẫn phải khai báo đầy đủ trong budget toàn tàu, có xác nhận nó nằm ngoài hầm mục tiêu.
- Mọi thay đổi số đo, giấy tờ, ngày chuyến, hạn mức, hàng hiện hữu hoặc manifest tạo phiên bản case/snapshot mới; không sửa âm thầm phương án đã chọn.
- Vùng hầm sử dụng là vùng có thể tiếp cận theo khai báo đã được xác nhận. Tool chưa chứng minh đường cẩu/đưa hàng qua miệng hầm hoặc ổn định từng bước thao tác.

### 3.2 Hàng hóa

Hỗ trợ `BUNDLED_REBAR` và `BUNDLED_PIPE` khi có bao hình học của từng bó, khối lượng, ID, nguồn dữ liệu và support profile phù hợp đã được duyệt. CargoUnit là đơn vị nguyên vẹn mà solver được phép chọn; không tách một bó thành các mảnh để vượt hạn mức hoặc làm vừa hầm.

Chỉ xoay đứng quanh trục z theo góc được profile cho phép. Không lật nghiêng bó để giảm chiều cao. Xếp nhiều tầng cần profile đã xác minh, cấu hình tầng/đỡ rõ và gate kỹ thuật liên quan đạt. Nếu chưa có profile, không tạo giá trị mặc định để cho solver chạy. Mixed stacking giữa các profile không được tự suy ra từ việc mỗi loại hàng được hỗ trợ riêng.

### 3.3 Ngoài phạm vi hoạt động ban đầu

Hầm hình thang/đa giác, xếp thêm vào hầm đã có hàng, xếp lên hàng hiện hữu, nhiều hầm tối ưu đồng thời, thép cuộn, hàng rời, kế hoạch móc cẩu, điều phối xe/bến, tính ổn định/sức bền tổng quát, cloud/multiuser và AI tự xác nhận dữ liệu. Các mục này cần change request, schema/rules và test trước khi bật; không phải tính năng ngầm có sẵn trong v0.2.

## 4 Các năng lực bắt buộc

### 4.1 Nhập và xác minh dữ liệu

- Nhận chứng từ ảnh/PDF và manifest Excel/CSV; cho nhập tay theo nguồn MANUAL_ENTRY.
- Giữ bản gốc bất biến, hash file, vị trí nguồn như trang/bounding box hoặc sheet/row/cell, giá trị nguyên văn, đơn vị gốc và kết quả chuẩn hóa.
- OCR/AI chỉ tạo candidate chưa xác minh. Hiển thị cạnh nguồn; hỏi lại khi thiếu, xung đột tên/số đăng ký/ngày/khối lượng/đơn vị.
- Lưu IntakeDraft với dữ liệu thiếu thật; không điền 0 hoặc VERIFIED giả để thỏa schema.
- Confirm là hành động người dùng có phiên/quyền thật; backend kiểm nguồn, tính đầy đủ và tạo immutable record mới.
- Giữ đối soát số dòng, số bó, tổng khối lượng, ID và unit conversion. Không chia đều tổng line thành các bó khi nguồn không cho phép.

### 4.2 Lập loading case

Chọn đúng versions của vessel, hold, manifest, rules và profiles; xác nhận thời gian hoạt động, trạng thái hầm trống, hàng hiện hữu ngoài hầm, cargo allowance và dự phòng kê mới. Backend tạo snapshot refs và hash; client không tự cấp trạng thái sẵn sàng.

Preflight phải cho thấy từng điều kiện đạt/thiếu/sai và liên kết đến trường cần sửa. Các trường bắt buộc chưa đủ làm nút optimize bị khóa, kể cả gọi API trực tiếp.

### 4.3 Kiểm tra và tối ưu

- Bộ kiểm tra xác định hoạt động độc lập AI/CVF và được gọi lại với mọi candidate/sửa tay.
- Mode `ALL_REQUIRED`: xét tập kiện đã chỉ định bắt buộc; không thay bằng một tập nhẹ hơn mà vẫn báo hoàn thành.
- Mode `MAXIMIZE_OPTIONAL`: mọi kiện bắt buộc vẫn phải có; mục tiêu v0.2 cố định là tối đa tổng massKg của các unit optional được xếp. Không có ưu tiên tùy chỉnh hoặc trọng số chưa được biểu diễn trong contract.
- Excluded là hàng người dùng chủ động không yêu cầu xét; unplaced là hàng trong tập xét chưa được bố trí. Hai trạng thái phải tách biệt trong dữ liệu và báo cáo.
- Ràng buộc đi đủ nhóm/lô phải biểu diễn rõ nếu dùng; khi chưa hỗ trợ, giao diện không hứa có tính năng đó. Không tự coi sourceLineId là nhóm phải đi đủ.
- Candidate có thể khả thi mà chưa tối ưu. Không tìm thấy bằng heuristic hoặc hết thời gian không phải chứng minh INFEASIBLE.
- Mỗi run pin case chứa required/optional/excluded và lưu mode, seed, time budget, thuật toán/build, trạng thái kết thúc và căn cứ kết luận. Mục tiêu cố định được xác định bởi mode và phiên bản spec; quy tắc tie-break phải được pin trong solverBuild. ALL_REQUIRED chỉ cần tìm phương án đáp ứng toàn bộ required; không tự tuyên bố một tiêu chí tối ưu phụ.
- Hủy run hoặc run cũ hoàn tất muộn không được thay phương án mới của case. Candidate cũ có thể lưu lịch sử dưới đúng snapshot, không tự trở thành lựa chọn hiện hành.

### 4.4 Chỉnh sửa và lựa chọn

Người dùng có thể di chuyển/xoay bó trong phạm vi profile. Frontend preview ngay; backend mới được kiểm và ghi version. Khi chưa đạt, giữ draft chẩn đoán và lỗi cụ thể. Chọn phương án yêu cầu validation hiện hành, toàn bộ HARD áp dụng đạt, actor thật và receipt gắn đúng content hash. Chỉnh phương án đã chọn tạo version mới và cần lựa chọn lại.

### 4.5 Xem và xuất báo cáo

Màn hình tổng quan trình bày: phương tiện/case, kg hiện hữu, kg dự kiến xếp, kê mới dự phòng, hạn mức, số bó đã xếp/chưa xếp/chủ động loại, trạng thái run và các phần chưa đánh giá. Click vào chỉ tiêu để mở danh sách bó, vị trí, lý do và bằng chứng.

Báo cáo tối thiểu có PDF dễ đọc và XLSX phục vụ đối soát; CSV có thể bổ sung. Local chọn thư viện và kiểm file xuất thực. Có top/front/side view với kích thước và trục, tên/ID bó; 3D không thay bảng số liệu. Mọi export mang case/version, plan content hash, ngày tạo, đơn vị, coverage và các điều kiện sử dụng. Không in SAFE/CERTIFIED/EXECUTION_READY chỉ từ solver hoặc user selection.

### 4.6 Lịch sử và phục hồi

Tìm theo phương tiện, case, manifest, ngày, cargoUnitId và phiên bản. Giữ lịch sử readonly. SQLite local và file store có content hash; transaction, crash recovery, backup nhất quán và thử restore là bắt buộc. Restore giữ tính toàn vẹn lịch sử nhưng hành động mới phải kiểm lại hiệu lực hiện tại và quyền; credential/session không được khôi phục như dữ liệu nghiệp vụ.

## 5 Bất biến nghiệp vụ

1. Cargo capacity lấy từ trường có thẩm quyền; GT và DWT không được tự thay payload.
2. V0.2 dùng integer kg/mm trong immutable records. Dữ liệu nguồn chưa chuẩn hóa chính xác được giữ nháp; không truncate hoặc làm tròn xuống để lọt hạn mức.
3. Hạn mức case có một basis duy nhất: `CARGO_PLUS_PLANNED_DUNNAGE`. Công thức chi tiết ở docs/02; mọi thành phần tính đúng một lần.
4. Mỗi cargo trong manifest xuất hiện đúng một lần trong placed, unplaced hoặc excluded; chỉ ID có thật được dùng; mass được backend tính lại từ nguồn đã pin.
5. Mỗi rule áp dụng có đúng một kết quả, phiên bản và căn cứ. Rule bị thiếu không được hiểu là PASS; NOT_APPLICABLE cần phạm vi phù hợp.
6. HARD/HARD_GATE/GOVERNANCE áp dụng không đạt hoặc thiếu dữ liệu thì chặn lựa chọn và bàn giao; không cho override bằng score, AI hoặc CVF.
7. Geometry, support và mass được kiểm độc lập sau solver; viewer dựng từ cùng PlanContent.
8. Content bất biến được hash theo thuật toán công bố. Trạng thái/receipt là các record riêng; không đưa self hash vào preimage.
9. Nguồn TEST_ONLY chỉ đi qua harness/thử nghiệm riêng; không đủ điều kiện xác minh hoặc dùng hiện trường.
10. Mọi dữ liệu kỹ thuật chưa có căn cứ phải hiện chưa đánh giá; không tự đặt thông số để làm đủ bằng chứng.

## 6 Kiến trúc và phân công

Giữ modular monolith trong một repo: React/TypeScript + viewer 2D/3D; backend Python/FastAPI; SQLite local và file store bất biến; solver phía backend; adapter AI/CVF tùy chọn. Frontend không truy cập SQLite hoặc CVF internals. Backend serve frontend build cho một launcher local; không cần microservices.

Pin runtime/dependency ở local sau compatibility check; đề xuất stack không phải bằng chứng các phiên bản mới nhất đã được kiểm. Pydantic/OpenAPI tạo typed client; schema snapshots trong package là contract cần reconcile bằng test, không duy trì hai mô hình tự phát khác nhau.

| Bên chịu trách nhiệm | Trách nhiệm |
|---|---|
| Owner/người vận hành | Mục tiêu chuyến, quyền quyết định, nguồn dữ liệu, lựa chọn phương án |
| Người có chuyên môn | Giới hạn, hiệu lực áp dụng, profile kê/chồng và review hiện trường |
| Agent local | Code, kiểm nguồn CVF, migration, test/log và discrepancy |
| Reviewer | Đối chứng kết quả theo gate và bằng chứng có thể chạy lại |

Tên người và vai trò thật được ghi ở local. Package không điền giả người phê duyệt.

## 7 Các tài liệu quy định chi tiết

- docs/01: quyết định v0.2, những khác biệt so với baseline và điều kiện mở rộng.
- docs/02 + contracts/: dữ liệu, geometry, hash, rule coverage và transitions.
- docs/03: gates, criteria và evidence.
- docs/04: local auth, CVF bridge và fail-closed Agent actions.
- docs/05: xử lý R1 và phần implementation còn phải chứng minh.
- docs/06: UI/UX, API, storage, import/export và backup.
- docs/07: nguồn kỹ thuật/pháp lý và việc xác minh còn lại.

Mọi thay đổi chạm cargo model, hard rules, hash hoặc approval cần version, impact analysis, regression tests và review trước khi kích hoạt. Thay mục tiêu tối ưu không được vô hiệu hóa hard constraints.

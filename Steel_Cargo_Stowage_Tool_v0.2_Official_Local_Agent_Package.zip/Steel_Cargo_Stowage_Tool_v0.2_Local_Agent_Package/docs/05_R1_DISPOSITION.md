# Xử lý các nhận định phản biện R1 trong v0.2

**Kết luận về phạm vi:** v0.2 là package chính thức làm việc với Agent local, thay cho việc dùng riêng baseline v0.1 và tự suy diễn các kiến nghị R1. Những quyết định thiết kế dưới đây đã được đưa vào package. Việc này không chứng minh backend, solver, CVF hoặc cấu hình kỹ thuật thực đã đạt nghiệm thu.

`INCORPORATED` trong bảng nghĩa là nhận định đã được xử lý bằng contract hoặc giới hạn phạm vi cụ thể. `LOCAL_EVIDENCE_PENDING` nghĩa là Agent local vẫn phải nộp bằng chứng implementation tương ứng. Những phần `ENGINEERING_INPUT_REQUIRED` chỉ được mở khi có dữ liệu và xác nhận chuyên môn thực, không dùng số trong fixture synthetic thay thế.

## 1 Ma trận disposition

| R1 | Xử lý trong v0.2 | Vị trí thực hiện | Điều kiện còn lại |
|---|---|---|---|
| R01 Tải trọng và GT | `INCORPORATED`: bỏ trường ghép; tách `grossTonnageGt`, `deadweightKg` và cargo limit có evidence; chốt basis cộng kê mới | `vessel_profile`, `loading_case`; đặc tả chính | `LOCAL_EVIDENCE_PENDING`: parser đúng cột/đơn vị; `ENGINEERING_INPUT_REQUIRED`: nguồn hạn mức thật |
| R02 Hàng hiện hữu | `INCORPORATED_BY_SCOPE`: core chỉ một hầm BOX được xác nhận trống; existing cargo chỉ ở ngoài hầm mục tiêu và vẫn tính vào toàn tàu | `loading_case.scope=EMPTY_TARGET_HOLD`, `targetHoldEmptyConfirmed`, `existingCargoLocation` | Test dữ liệu hầm không trống bị từ chối. Muốn xếp tiếp trong hầm có hàng phải mở change request bổ sung occupancy, không giả bằng số kg |
| R03 Hồ sơ kê đỡ | `INCORPORATED`: immutable `support_profile`, refs có version/hash, loại hàng/orientation/kê/stacking/tải/phạm vi được biểu diễn | `support_profile`, `manifest`, `loading_case.supportProfileRefs` | `ENGINEERING_INPUT_REQUIRED`: profile thực được duyệt. `LOCAL_EVIDENCE_PENDING`: resolve pin, scope, support graph, tải truyền; fixture không cấp phép sử dụng |
| R04 Rule và chuyển trạng thái | `INCORPORATED`: validation, decision và lifecycle tách riêng; hard checks/coverage là preconditions do backend bảo vệ; field review có rule coverage và evidence được server resolve | `validation_receipt`, `decision_receipt`, `lifecycle_event`; đặc tả chính; docs 03–04 | Test thiếu rule, HARD unknown/FAIL, receipt sai loại/sai target, evidence không tồn tại và giả actor. JSON shape không thay auth/state machine |
| R05 Hình học | `INCORPORATED_BY_SCOPE`: BOX, hệ trục, dimensions basis, clearance, yaw và điểm neo được chuẩn hóa; TRAPEZOID chưa active | `hold_profile`, `plan_content`; đặc tả chính | Test biên 1 mm/xoay/margin/excluded zones và viewer projection; số đo thật vẫn cần người xác nhận |
| R06 Version và hash | `INCORPORATED`: mọi immutable content có ID/version; envelope chứa hash ngoài content; refs pin hash; input snapshot là case hash | `contracts/MODEL_INTERFACE.json`, schema bundle/ref; reference canonicalization | Test mutation 1 mm/ref, canonical bytes, stale run, selection không sửa content. Hash không tự chứng minh người duyệt |
| R07 Kê lót | `INCORPORATED`: profile lưu chiều dày kê; case lưu dự phòng kê mới; công thức và basis không còn tùy chọn mơ hồ | `support_profile`, `loading_case.allowanceBasis=CARGO_PLUS_PLANNED_DUNNAGE` | `ENGINEERING_INPUT_REQUIRED`: cấu hình/dự phòng thật; test vượt chiều cao/tải và không cộng/trừ hai lần |
| R08 Ý nghĩa solver | `INCORPORATED`: mode và tập required/optional/excluded nằm trong case; run tách termination/candidate/fulfillment/proof | `loading_case`, `optimization_run.status` | Test mode, nguyên kiện/nhóm, timeout và bằng chứng proof; chưa có solver thực trong package |
| R09 Bảo toàn manifest | `INCORPORATED`: CargoUnit nguyên vẹn, nguồn và mass precision; plan có placements/unplaced với reason/excluded | `manifest`, `plan_content`; reference checks | Test phân hoạch toàn manifest, unique/ref, tổng mass, rounding/import và nhóm; quy trình tách dòng tổng phải được xác nhận |
| R10 Dữ liệu nháp | `INCORPORATED`: `intake_draft` riêng; missing/conflict không buộc giả VERIFIED | `intake_draft`; đặc tả luồng intake | Test lưu/mở lại draft, xác nhận tạo snapshot, nhập tay có provenance thật |
| R11 Hiệu lực và restore | `INCORPORATED`: dữ liệu thời hạn có cấu trúc; case xét khoảng hoạt động; lịch sử và hiệu lực hiện tại được tách | `vessel_profile`, `loading_case.operatingDate/validThroughDate`; docs 03 | Test expiry/boundary/restore; `ENGINEERING_INPUT_REQUIRED`: giấy tờ/quy định hiện hành và các tải áp dụng |
| R12 Local auth và CVF | `INCORPORATED`: operator session tách agent capability; actor từ backend; adapter request/receipt binding; ba nhánh spike | `docs/04_CVF_AND_LOCAL_AUTH.md`; các receipt nghiệp vụ | `LOCAL_EVIDENCE_PENDING`: source/build/exports/license/guards/auth/bridge. Package không xác nhận public pinned source đã kiểm được |
| R13 Khả năng thao tác và nguồn rule | `INCORPORATED_BY_SCOPE`: nguồn/phạm vi rule có cấu trúc; tiếp cận cần evidence; không scoring số lần đảo hay quy tắc dài/ngắn chung chưa được duyệt | `rule_set`, `hold_profile.accessEvidence`; đặc tả chính | Review applicability, khả năng thao tác và các engineering checks còn ngoài phạm vi; không tự áp hướng dẫn cảng nước ngoài |
| R14 Evidence và gates | `INCORPORATED`: G4a/G4b tách; reference checks có phạm vi rõ; tiêu chí LAT-001…025 và mẫu báo cáo | `docs/03_ACCEPTANCE_AND_EVIDENCE.md`, `templates/LOCAL_AGENT_REPORT.md`, `tests/` | Chạy implementation thật và nộp evidence; skeleton không làm gate PASS |

## 2 Các lựa chọn phạm vi đã cụ thể hóa

1. **BOX và hầm mục tiêu rỗng là phạm vi khởi động.** Tính năng hình thang hoặc xếp thêm vào hầm có hàng không được âm thầm bật qua một tùy chọn UI. Muốn mở phải bổ sung schema/validator/fixture/coverage và đánh giá lại gate liên quan.
2. **Bó thép thanh và bó thép ống là hai loại dữ liệu được hỗ trợ.** Khả năng sử dụng một cấu hình cụ thể còn phụ thuộc profile có nguồn, phạm vi và phê duyệt phù hợp. Không tạo một profile chung chưa được duyệt chỉ để mở đủ hai lựa chọn.
3. **Xếp tầng có điều kiện rõ.** `layeredStackingEnabled` phải gắn bằng chứng gate khi bật; profile phải hỗ trợ cấu hình và giới hạn tương ứng. Tắt chế độ này thì tầng trên bị chặn, kể cả khi viewer vẽ được.
4. **Khối lượng kế hoạch có kê mới.** Cộng existing cargo, mass của unit thực xếp và dự phòng kê mới; không dùng GT/DWT làm payload. Giá trị số thực phải lấy từ nguồn được giao xác nhận.
5. **Mode là quyết định của case.** `ALL_REQUIRED` không có optional units; `MAXIMIZE_OPTIONAL` vẫn phải đáp ứng required units trước khi coi candidate đủ điều kiện chọn và có mục tiêu cố định tối đa tổng massKg của optional đã xếp. V0.2 không có trọng số hay ưu tiên tùy chỉnh. Tie-break phải được xác định trong solver build nếu tuyên bố tái lập kết quả. Loại một unit trước khi solve phải được lưu riêng, không biến thành unit thất lạc.
6. **AI có thể tắt hoàn toàn.** Core vẫn phải đáp ứng G4a. Bật AI actions sau này cần G4b; không dùng manual bypass dưới danh agent để lách bridge lỗi.

Các IDs tương thích giữa các support profiles chỉ được giải trong tập profile refs đã pin của case. Case không được mơ hồ có nhiều version của cùng một profile ID để backend tự lấy “latest”. Compatibility không làm mất binding phiên bản/hash.

## 3 Điều đã chốt và điều không thể tự điền

| Đã chốt trong package | Cần dữ liệu hoặc quyết định thực |
|---|---|
| Công thức, loại dữ liệu, ref/hash, mode, geometry và quyền hạn | Hạn mức chứng nhận/chuyến, số đo hầm, người có thẩm quyền |
| Nơi lưu profile, các loại giới hạn và cách kiểm cơ bản | Cấu hình kê, tải đỡ, tầng cao, chống lăn và giới hạn vật tư cụ thể |
| Schema sources/scope/hiệu lực và coverage | Văn bản/điều khoản áp dụng cho đúng phương tiện, vùng và ngày |
| Trạng thái solver và yêu cầu proof | Solver được chọn, build/runtime, kết quả chạy và hiệu năng thực |
| Protocol adapter, các nhánh phải test | API CVF thật tại checkout local, exports/license/guards và tương thích runtime |
| Phân biệt selection, field review, CVF receipt | Danh tính/vai trò thực, nội dung review và điều kiện vận hành được chấp thuận |

## 4 Cách Agent local phản hồi package

Với từng R1, giữ nguyên ID và báo một trong các disposition triển khai: `IMPLEMENTED_AND_TESTED`, `IMPLEMENTED_NOT_TESTED`, `BLOCKED_BY_INPUT`, `CHANGE_PROPOSED` hoặc `NOT_STARTED`. Dẫn file/test/log thực; không biến bảng “INCORPORATED” ở trên thành lời xác nhận code đã đúng.

Nếu phát hiện contract v0.2 không khớp dữ liệu hoặc source local, ghi tình huống, bằng chứng, ảnh hưởng và patch đề xuất. Thay đổi điều kiện hard, cargo model, allowance, quyền hạn hoặc phạm vi hoạt động phải có version và đánh giá tác động. Không sửa các yêu cầu ấy để cho fixture đang có qua test.

Các bản R1 và v0.1 là nguồn lịch sử để truy vết. Trong công việc triển khai mới, đọc đặc tả chính, schema và contract v0.2; nếu có mâu thuẫn giữa các thành phần hiện hành, ghi issue và giải quyết trước phần việc phụ thuộc, không tự chọn cách hiểu thuận tiện hơn.

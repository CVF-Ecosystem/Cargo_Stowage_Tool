# Phạm vi và quyết định v0.2

## Quyết định đã chốt cho package làm việc

| ID | Quyết định | Lý do và hệ quả |
|---|---|---|
| D01 | Local, một người, một repo FE/BE | Giữ hướng baseline; core không phụ thuộc cloud/AI |
| D02 | Một hầm mục tiêu BOX | Có định nghĩa hình học và oracle cụ thể; TRAPEZOID chưa bật |
| D03 | EMPTY_TARGET_HOLD | Tránh suy ra không gian hàng cũ từ một số kg; phải xác nhận hầm trống |
| D04 | Hàng hiện hữu ngoài hầm vẫn vào budget toàn tàu | Không cho mỗi vùng tự sử dụng toàn bộ hạn mức |
| D05 | Hai cargo types theo từng profile được duyệt | Giữ mục tiêu bó thép thanh/ống; không mặc định mixed stacking |
| D06 | Tầng 0 chạy theo profile; tầng cao có gate riêng | Không tự chọn tầng hoặc tải đỡ từ dữ liệu giả lập |
| D07 | Case pin cả profile và rules bằng version/hash | Chạy lại đúng dữ liệu cũ; thay nguồn có ảnh hưởng thì phải kiểm lại |
| D08 | Cargo plus new dunnage budget | Một phương trình tải; nguồn allowance phải dùng cùng basis |
| D09 | IntakeDraft tách immutable records | Không giả số đo hoặc VERIFIED chỉ để lưu nháp |
| D10 | PlanContent tách run, validation, decision và lifecycle | Hash không tự tham chiếu; chọn plan không đổi bố trí |
| D11 | Run tách termination/candidate/fulfillment/proof | Không gọi hết thời gian là bất khả thi hoặc có nghiệm là tối ưu |
| D12 | G4a core và G4b AI/CVF riêng | Core vẫn có nghiệm thu quyền/receipt dù AI đang tắt |
| D13 | Bằng chứng TEST_ONLY được cách ly | Hash thật của file test chỉ chứng minh đúng nội dung test |
| D14 | v0.2 là nguồn yêu cầu đang hiệu lực | Baseline và R1 giữ trong history để tra cứu, không trộn yêu cầu |

Đây là những lựa chọn thiết kế để Agent local bắt đầu làm việc. Chúng không gán giá trị kỹ thuật cho một tàu thật và không ngụ ý owner đã ký nghiệm thu G0–G5. Agent local ghi discrepancy nếu dữ liệu/cách khai thác thực cần scope rộng hơn.

## Điều kiện mở rộng

### Hầm đã có hàng

Cần case-scoped occupied regions/fixed placements, hash và nguồn xác minh, đối soát mass với vị trí, collision trong solver/validator/viewer. Nếu đặt hàng mới lên hàng cũ, cần mô hình đỡ tương ứng. Không tái dùng excludedZones để âm thầm bỏ qua điều kiện EMPTY_TARGET_HOLD.

### Hình thang hoặc nhiều hầm

Hình thang cần hàm biên/mặt cắt/offset, margin và oracle độc lập. Nhiều hầm cần một budget toàn tàu chung và trạng thái chuyến nhất quán; không tạo nhiều case đồng thời mỗi case được dùng toàn bộ cargo allowance.

### Nhiều tầng

Core có contract cho profile `SINGLE_LAYER` và cấu hình `FULL_BASE_SUPPORT` khi được schema hỗ trợ. Tầng cao chỉ bật khi `layeredStackingEnabled` có bằng chứng gate, profile có trạng thái review phù hợp, số tầng/chiều cao/net supported cargo allowance và điều kiện kê đều xác minh.

FULL_BASE_SUPPORT là mô hình hình học cho cấu hình kê đã được review; không tự chứng minh tiếp xúc thật của bó ống, áp suất, độ bền dây bó hoặc tính ổn định. Không dùng các giá trị trong fixtures làm giá trị mặc định. Những dạng kê không thỏa điều kiện phủ đầy đủ footprint của mô hình, nhô ra hoặc cơ học phức tạp ngoài mô hình đơn giản cần extension riêng. Khi có nhiều bó cùng đỡ, reference kiểm tổng tải phía trên bảo thủ tại từng support; việc phân tải lực thực không nằm trong reference.

### AI và CVF

Chỉ bật agent actions sau G4b. READ/EXPLAIN có scope riêng; quyền tạo revision draft khác quyền xác nhận hoặc lựa chọn. Không thêm tool confirm/select/change_limit vào catalog của AI. Core manual vẫn cần auth, receipt và validation khi không có CVF.

## Dữ liệu và quyết định thật còn phải bổ sung

| ID | Nội dung cần người có trách nhiệm cung cấp | Chặn việc gì | Có thể tiếp tục |
|---|---|---|---|
| O01 | Giấy hiện hành, lượng hàng cho phép và cách xác nhận allowance chuyến | Case vận hành thật | Schema, nhập nháp, synthetic tests |
| O02 | Số đo BOX, margin, vật cản, hướng trục và khả năng tiếp cận | Plan cho hầm thật | Viewer mock và geometry tests |
| O03 | Profile bó thanh/ống, kê, net supported allowance, tầng và điều kiện chống lăn | Cargo/profile hoặc tầng chưa được review | Core một tầng trên fixture TEST_ONLY |
| O04 | Danh tính người xác minh, chọn plan và review hiện trường | Receipt thực | Auth design và negative tests |
| O05 | Manifest có ID/số bó/khối lượng từng bó, quy tắc nhóm hàng | Import và tối ưu chuyến thật | Parser/error handling trên mẫu ẩn danh |
| O06 | Điều khoản áp dụng theo loại tàu, vùng và toàn khoảng ngày hoạt động | Rules operational active và field review | Registry và date/scope tests |
| O07 | Máy mục tiêu, quy mô số bó và time budget | Tiêu chí hiệu năng cuối cùng | Solver nhỏ và đo baseline |
| O08 | Repo CVF local, build/license/dependency và policy tương thích | AI actions G4b | Core manual G4a |

Không hỏi lại owner những lựa chọn kỹ thuật routine đã được chốt trong package. Chỉ hỏi khi thiếu thông tin thuộc bảng trên hoặc phát hiện một mâu thuẫn thật làm thay đổi phạm vi/quyền hạn.

## Thay đổi so với v0.1

V0.2 chuẩn hóa BOX/empty target hold, bổ sung support profile/version/hash, case version và khoảng ngày, một basis tải có dunnage, intake nháp, typed statuses, receipts riêng và test có liên kết hash thật. Giao diện/AI/architecture vẫn theo mục tiêu cũ. TRAPEZOID và existing cargo trong hầm được ghi rõ là extension; đây là thay đổi phạm vi triển khai ban đầu, không phải tính năng đã hoàn thành rồi bị bỏ.

Các phần chưa được chứng minh tại local có trạng thái chờ tương ứng, thay vì giữ một câu hỏi mơ hồ ngay trong invariant lõi.

# Hợp đồng dữ liệu hình học và trạng thái

Đọc cùng `contracts/WIRE_MODEL.md`, `contracts/MODEL_INTERFACE.json` và schemas. Tên field/enum chính xác nằm ở contracts; các điều kiện nghiệp vụ bên dưới do backend thực thi, không giao hết cho JSON Schema.

## 1 Immutable content và references

Mỗi content có `schemaVersion`, `id`, `version`, `testOnly`. Record envelope lưu `kind`, `id`, `version`, `sha256`, `content`; các refs pin `kind/id/version/sha256`. Envelope identity phải khớp content. Không có self hash trong content.

Thuật toán **STOWAGE-JSON-0.2**: UTF-8 JSON compact, key ASCII được sort, strings giữ nguyên Unicode code points, không surrogate, số nguyên trong safe integer range, không float/nonfinite. Arrays giữ thứ tự. Xem canonical module và test vectors. Đây là thuật toán của package; không tuyên bố là RFC 8785. Backend là nơi canonicalize/hash chính thức.

Một ký tự Unicode ở dạng tổ hợp khác tạo bytes/hash khác nếu chuỗi không giống nhau; importer chuẩn hóa theo policy trước confirm, không sửa chuỗi đã pin. JSON keys cố định ASCII tránh khác thứ tự giữa các ngôn ngữ. Client triển khai khác ngôn ngữ phải chạy test vectors trước khi so hash; không tự dùng serializer mặc định rồi cho rằng tương đương.

`inputSnapshotSha256` bằng hash của loading case content vì case đã pin toàn bộ dependency DAG. Thay bất kỳ dependency phải đổi ref và case version. Kiểm digest mọi record, identity/ref resolution và tính đúng của DAG; một chuỗi đủ 64 hex không phải bằng chứng liên kết hợp lệ.

PlanContent chứa tọa độ và kết quả phân hoạch hàng, không có trạng thái phê duyệt hoặc solverStatus. OptimizationRun trỏ plan; plan do SOLVER/SYNTHETIC sinh chỉ giữ run ID/build provenance cần thiết để tránh hash cycle. Plan MANUAL_EDIT pin parentPlanRef và không có run fields. ValidationReceipt trỏ plan/case/rules; runRef bắt buộc cho SOLVER/SYNTHETIC và phải bỏ cho MANUAL_EDIT. DecisionReceipt trỏ plan/validation. LifecycleEvent ghi sự kiện; trạng thái hiển thị do backend suy ra từ các record hợp lệ. Sửa tay không thay run cũ hoặc kế thừa proof của run cha.

## 2 Giá trị số và intake

Immutable records dùng integer kg/mm; no epsilon cho phép vượt khối lượng. UI có thể hiện tấn/m nhưng cần ghi đơn vị và convert chính xác. Dấu phẩy/chấm/đơn vị mơ hồ tạo NEEDS_CONFIRMATION. Thiếu giá trị khác với 0. Khối lượng cargo unit thực phải dương.

Nếu nguồn có phần kg lẻ, giữ raw value/unit trong draft và chặn confirm theo contract integer hiện tại cho tới khi có cách xử lý độ chính xác được xác nhận. Không tự truncate, làm tròn xuống hoặc chia tổng line đều cho các bó. Extension dùng gram/decimal hoặc mass bound cần change contract và test trước khi sử dụng.

Source MANUAL_ENTRY ghi sự kiện nhập và người xác nhận thật; không tạo document hash giả. SOURCE/SYNTHETIC không được tự nâng thành source hợp lệ bằng cách sửa cờ. Backend lưu provenance từ intake và kiểm quyền xác nhận; các chuỗi actor trong JSON chỉ là dữ liệu mô tả.

GT là trường riêng với ý nghĩa không phải kg; DWT chỉ nhập từ nguồn xác định đúng DWT. `certificateCargoLimitKg` là cargo limit đã xác minh, không suy ra từ hai trường đó. [Nguồn W1/W2 tại docs/07]

## 3 Khoảng thời gian và hiệu lực

Case có `operatingDate` và `validThroughDate`, inclusive theo `timeZone`. Start không được sau end. Giấy safety inspection và mọi nguồn có hiệu lực giới hạn phải phù hợp toàn khoảng ngày hoạt động đã khai báo. Đây là preflight bảo thủ của package; chuyên môn vẫn phải xác định giấy nào áp dụng và các điều kiện khác.

Thiếu expiry không mặc nhiên là không hết hạn. Loại chứng từ được xác minh không có ngày kết thúc phải được biểu diễn đúng loại/nguồn. Không tự chọn một giấy bất kỳ trong certificates chỉ vì nó còn hạn nếu cargo limit lấy từ giấy khác đã hết hiệu lực.

Đổi ngày chuyến tạo version mới và chạy lại applicability/validity. Tái sử dụng sau restore hoặc sau thay rule/chứng từ cần kiểm hiệu lực hiện tại; bản lịch sử vẫn giữ nguyên để truy vết.

## 4 Một phương trình cân đối khối lượng

V0.2 chỉ dùng `allowanceBasis = CARGO_PLUS_PLANNED_DUNNAGE`:

```text
existingCargoKg + placedCargoMassKg + plannedDunnageMassKg
    <= voyageCargoLimitKg
    <= vessel.certificateCargoLimitKg
```

- `placedCargoMassKg`: backend cộng từ CargoUnit thực sự có placement, không nhận total do frontend/AI khai.
- `existingCargoKg`: hàng hiện hữu và phần kê liên quan đã nằm trên tàu trong cùng accounting budget; ở ngoài hầm mục tiêu.
- `plannedDunnageMassKg`: dự phòng cho kê/chèn mới của phương án, chưa bị trừ khỏi voyage limit; không chứa lại phần kê cũ đã tính ở existing.
- `voyageCargoLimitKg`: budget tổng của chuyến cho các thành phần trên, được người có trách nhiệm xác nhận sau khi đã xét các tải khác và điều kiện chuyến. Không phải chỉ phần còn nhận thêm.

Đây là quy ước budget bảo thủ của tool, không tự phân loại pháp lý mọi vật kê là hàng. Nếu nguồn cung cấp hạn mức net đã trừ kê mới hoặc chỉ residual allowance, giữ draft và yêu cầu chuyển đổi có căn cứ trước confirm; không tự cộng thêm capacity. Không tự lấy certificate capacity rồi coi bằng voyage capacity.

Dự phòng kê giữ nguyên khi solver xếp một phần. Muốn giảm dự phòng phải xác nhận basis mới, tạo case version mới và kiểm lại; không để solver tự tăng lượng hàng bằng cách giảm reserve.

## 5 Mô hình BOX và clearance

`lengthMm/widthMm/heightMm` là kích thước vùng mô hình khai báo trước khi áp `clearances`, với `dimensionsBasis=DECLARED_BEFORE_CLEARANCE`. `measurementMethod` phân biệt MEASURED, DRAWING và ESTIMATED_CONFIRMED; phương pháp, nguồn và margin phải được xác nhận. X/Y nằm ngang, Z hướng lên; gốc ở góc đáy vùng mô hình. Hướng về mũi/lái/mạn là metadata được xác nhận, không đoán từ dấu X/Y.

Vùng biên hợp lệ sau clearance:

```text
xMinMm <= x
x + rotatedLength <= lengthMm - xMaxMm
yMinMm <= y
y + rotatedWidth  <= widthMm - yMaxMm
0 <= z
z + cargoHeight   <= heightMm - topMm
```

Margin không trừ hai lần. Không có generic floor clearance; cao độ lớp đáy do dunnage profile quyết định. Nếu vùng sau clearance không còn kích thước dương thì reject.

Placement `(xMm,yMm,zMm)` là góc dưới của axis-aligned envelope SAU yaw. Yaw 0/180 giữ length/width; 90/270 đổi hai kích thước; height không đổi. Chỉ dùng yaw nằm trong profile. Không dùng mesh trang trí để đổi occupied envelope.

`betweenCargoMm` áp cho khoảng hở nằm ngang giữa các bó cùng vùng cao độ có thể va chạm; vertical support được kiểm theo profile và chiều dày kê giữa tầng. Không cộng khoảng hở này như một tầng kê thứ hai. Touching khi clearance=0 không phải volume overlap; overlap có thể tích dương bị chặn. Excluded zones dùng cùng frame, cấm occupied envelope xâm nhập vùng đã khai báo.

Solver, reference validator và viewer phải thống nhất biến đổi. Frontend Three.js có thể dùng Y-up nội bộ nhưng adapter phải chuyển tọa độ rõ và test round trip; source of truth vẫn XYZ của contract.

## 6 Kê đỡ và profile

Profile bất biến có review evidence, type/scope, allowed yaw, stacking mode, số tầng, base/interlayer dunnage height, maximum stack height và supported cargo allowance.

Ở layer 0, z của bó bằng `baseDunnageHeightMm` theo profile. Ở tầng cao, model đơn giản yêu cầu mặt đỡ phù hợp và cao độ bằng đỉnh mặt đỡ cộng `interlayerDunnageHeightMm` theo quy ước trong WIRE_MODEL. Không được trừ dunnage khỏi height rồi lại nâng z lần nữa. Stack height được kiểm theo cao độ thực và giới hạn profile.

`maxSupportedMassKg` với `supportedMassBasis = NET_CARGO_ABOVE_AFTER_DUNNAGE_RESERVE` là cargo allowance phía trên mà chuyên môn đã dành ảnh hưởng của kê và cấu hình đỡ. Backend không tự chuyển total structural capacity thành giá trị net. Tải kiểm phải tính toàn bộ descendants phía trên trong graph; không chỉ bó kế tiếp.

Graph đỡ không có self edge/chu trình/ref lạ và phải có đường xuống base hợp lệ. Profile trên/dưới phải tương thích theo ID đã pin trong cùng case. Tầng cao cần `layeredStackingEnabled` và gate evidence; profile SINGLE_LAYER không được nhận bó phía trên.

Mô hình FULL_BASE_SUPPORT kiểm envelope theo cấu hình kê đã được review; không đồng nhất diện tích đáy box với diện tích chịu lực thật. Áp suất/tải đáy, độ bền bó, chống lăn và lashing chưa được tính thì vẫn phải hiển thị NOT_EVALUATED theo phạm vi. [W3/W4]

## 7 Phân hoạch manifest và ý nghĩa solver

Case phân hoạch toàn manifest thành required/optional/excluded, không trùng hoặc mất ID. Plan phân hoạch thành placed/unplaced/excluded; excluded phải khớp case. Mọi unplaced có reason code và diễn giải. Group đi đủ nếu được khai báo phải có semantics và kiểm tương ứng; không suy ra từ tên line.

ALL_REQUIRED yêu cầu đặt đủ tập required; MAXIMIZE_OPTIONAL không được bỏ required để tăng tấn optional. Plan không thỏa fulfillment có thể lưu draft/phân tích, nhưng không có quyền chọn như phương án đáp ứng yêu cầu chuyến.

Run.status tách `termination`, `candidate`, `fulfillment`, `proof`; enum chính xác ở schema. TIME_LIMIT/NOT_PROVEN diễn đạt hết thời gian chưa chứng minh. PROVEN_INFEASIBLE/OPTIMAL chỉ được ghi khi có proof evidence phù hợp mô hình, input và objective. Reference checks không tạo proof tối ưu hoặc chạy optimizer.

## 8 Rule coverage và lifecycle

Rule set/profile active cần version, scope theo type/vessel/region/date, nguồn, owner/review và test liên quan. Backend xác định tập applicable, không dùng tập outcomes do client gửi để tự thu hẹp coverage. Một rule áp dụng có đúng một outcome với rule version và reason/evidence. Thiếu, lặp hoặc không khớp rule version đều không đạt coverage.

| Điều kiện | Lưu để xem/chẩn đoán | Chọn phương án | Field handoff |
|---|---|---|---|
| Thiếu đầu vào bắt buộc | Draft | Chặn | Chặn |
| HARD/HARD_GATE/GOVERNANCE áp dụng FAIL/NEEDS_REVIEW/NOT_EVALUATED | Draft với issue | Chặn | Chặn |
| Core HARD đạt, engineering checks còn thiếu | Phương án sơ bộ, hiển thị coverage | Có thể chọn sơ bộ đúng quy trình | Cần review/evidence đúng plan và điều kiện |
| Vi phạm giới hạn kỹ thuật bắt buộc đã xác minh | Lưu FAIL | Chặn | Chặn |
| Có thay đổi dependency hoặc hiệu lực | Giữ lịch sử, stale | Kiểm và quyết định mới | Receipt cũ không đủ |
| TEST_ONLY hoặc nguồn synthetic | Sandbox/test | Không cấp quyết định operational | Không |

NOT_APPLICABLE chỉ hợp lệ khi có căn cứ phạm vi; không dùng làm lối bỏ qua HARD. S-009–S-011 chưa tính không tự thành PASS. RULES_CHECKED mô tả đã chạy/đủ coverage, không dùng màu xanh chung thay cho kết luận từng rule.

Receipt USER_SELECTION và FIELD_REVIEW có loại/mục đích riêng, actor/time/authority thật, plan/validation refs và điều kiện. CVF receipt chỉ kiểm quyền agent action và không thay hai receipt nghiệp vụ. Lifecycle events không làm thay content hash; backend xác minh event/receipt trước khi suy ra trạng thái.

## 9 Trách nhiệm backend ngoài reference checks

Xác minh danh tính/session/authority; truy xuất original blobs; chứng từ hiện hành/revocation; tính đầy đủ kê thực tế; giải proof của solver; giao dịch DB; chống replay; stale race; đồng bộ UI và nguồn pháp lý là việc local phải hiện thực/kiểm riêng. Reference module trả operationalEligible=false dù các phép kiểm số học đạt. Không nâng nhãn của nó thành clearance.

# Luồng người dùng API và lưu trữ

## 1 Các màn hình bắt buộc

| Màn hình | Nội dung | Điều kiện cần giữ |
|---|---|---|
| Hồ sơ dữ liệu | Tàu, hầm, manifest, case, plan, tìm kiếm và lịch sử | Bản cũ readonly; trạng thái hiện tại tách khỏi lịch sử |
| Nhập chứng từ | File nguồn cạnh trường trích xuất, nguồn từng trường, xung đột và expiry | AI/OCR chưa xác minh; confirm qua actor thật |
| Nhập manifest | Preview sheet/row/unit, đơn vị, số bó, total và discrepancy | ID ổn định; không chia đều khối lượng thiếu căn cứ |
| Mô hình hầm | BOX, số đo trước clearance, vật cản, trục và nguồn đo | Không mở TRAPEZOID hoặc hầm có hàng ngầm |
| Loading case | Versions, khoảng ngày, budget, dunnage reserve, mục tiêu và required/optional/excluded | Preflight do server; source/basis rõ; hầm trống |
| Không gian phương án | Bảng bó, 2D/3D, rotate/zoom, top/front/side/section, hide layers, coverage | Chọn đúng cargoUnitId; mesh không quyết định safety |
| Review và xuất | So sánh versions, chọn sơ bộ, ghi nhận review, PDF và bảng đối soát | Receipt đúng hash/actor; phần chưa đánh giá luôn hiện |
| Cài đặt và dữ liệu | Backup/restore verification, rules/profiles, quyền và AI enable | Bật AI actions phải qua G4b; rules thay bằng version mới |

Giao diện đi từ tổng quát đến chi tiết. Hiển thị rõ kg/tấn, mm/m và dd-mm-yyyy. Không hiện một màu xanh chung làm che HARD FAIL hoặc NOT_EVALUATED. Error panel có lý do bằng tiếng Việt, cargo/field liên quan và thao tác sửa phù hợp.

Máy không có GPU mạnh vẫn dùng bảng và 2D. WebGL lỗi không làm mất dữ liệu hoặc khóa chức năng nhập/kiểm/lưu. Các lệnh chính có thể thao tác bằng bàn phím; tab focus và trạng thái pending phải rõ.

## 2 Hành trình và biên ghi dữ liệu

### Intake chưa đủ

Upload → kiểm file → lưu original hash → OCR/parser tạo draft → chuẩn hóa có nguồn → hiện thiếu/xung đột → operator xác minh → backend tạo immutable version. Nhập tay có provenance riêng; không tạo hash của một file không tồn tại. Draft vẫn mở lại được khi thoát ứng dụng.

### Chạy solver

Người dùng chọn mode và tập hàng → server resolve/pin case → preflight → tạo job ID → worker dùng snapshot cố định → candidate qua validator độc lập → lưu run, content và receipt. UI polling job không tự sửa input đang chạy. Cancel hoặc case đổi không cho late result tự trở thành phương án hiện hành.

### Sửa tay

Preview di chuyển/xoay → request revision của đúng parent plan/version/hash → backend tạo PlanContent mới → kiểm lại → trả issues hoặc validation mới. Plan cũ và receipt cũ giữ nguyên. Manual edit không tạo kết luận tối ưu hoặc sửa chứng cứ của solver run cũ. Người dùng chọn lại nếu muốn dùng bản mới.

### Chọn và review hiện trường

UI hiển thị đúng case/plan/hash, totals, coverage và điều kiện → thao tác xác nhận có phiên thật → server kiểm quyền, current snapshot và receipt → ghi decision/lifecycle trong transaction. FIELD_REVIEW là hành động riêng với phạm vi, coveredRuleIds, evidence và kết luận; USER_SELECTION hoặc CVF ALLOW không tự tạo FIELD_HANDOFF_RECORDED.

## 3 Hợp đồng API ứng dụng

Đây là bản đồ operations để Agent local sinh OpenAPI từ các model v0.2. Nó chưa tuyên bố có server đang chạy. Tách request DTO chưa tin cậy với immutable content/receipt server sinh; không expose endpoint ghi raw record hoặc sửa cờ VERIFIED.

| Operation | Quyền caller | Precondition chính | Output |
|---|---|---|---|
| POST /api/v1/documents/intake | Operator; agent chỉ theo scope nếu bật | File format/size, untrusted content, local consent cloud | Document ID + intake draft/issues |
| POST /api/v1/vessels/{id}/confirm-profile | Operator có quyền xác minh | Source/identity/validity đầy đủ | VesselProfileVersion + server provenance |
| POST /api/v1/manifests/intake | Operator | Parser preview/units/errors | Manifest draft |
| POST /api/v1/manifests/{id}/confirm | Operator | Unit IDs/mass/source reconciliation | ManifestVersion |
| POST /api/v1/loading-cases | Operator | Valid refs/basis/mode/time interval | CaseVersion hoặc draft issues |
| POST /api/v1/loading-cases/{id}/versions | Operator | If-Match và thay đổi có nguồn | Version mới |
| POST /api/v1/loading-cases/{id}/optimize | Operator; agent bounded theo policy | Server preflight, exact case ref | Run/job ID |
| GET /api/v1/optimization-runs/{id} | Caller có read scope | Scope case | Job state/result/provenance |
| POST /api/v1/optimization-runs/{id}/cancel | Operator hoặc capability đúng run | Run chưa kết thúc; idempotent | Cancellation acknowledgement |
| GET /api/v1/plans/{id}/versions/{v} | Caller có read scope | Exact version | Plan content + derived lifecycle/coverage |
| POST /api/v1/plans/{id}/revisions | Operator; agent bounded draft-only | Parent ref/hash; no approval rights | New draft content và validation/issues |
| POST /api/v1/plans/{id}/revalidate | Operator; service theo policy | Sources/current applicability | New ValidationReceipt |
| POST /api/v1/plans/{id}/select | Operator có quyền lựa chọn | Current validation, HARD pass, fulfillment | USER_SELECTION receipt |
| POST /api/v1/plans/{id}/field-reviews | Người được giao review | Exact plan, coverage, evidence/role | FIELD_REVIEW receipt; lifecycle nếu đủ |
| POST /api/v1/plans/{id}/revoke | Người có quyền tương ứng | Scope/target/reason thật | Revocation event |
| GET /api/v1/plans/{id}/exports | Caller có read/export scope | Đúng version và format | PDF/bảng + metadata |
| POST /api/v1/backups | Operator | Consistent snapshot, target local | Backup manifest và checksum |
| POST /api/v1/restore/verify | Operator | Staging isolated, full checks | Verification report; chưa thay DB đang dùng |
| POST /api/v1/restore/commit | Operator xác nhận | Verified staging + rollback backup | Restored data, current eligibility pending recheck |

Các thao tác mutation dùng optimistic concurrency với version/ETag và idempotency khi phù hợp. Request chậm hoặc retry không được tạo decision trùng. Kiểm quyền và current hash ngay tại thời điểm commit để tránh time-of-check/time-of-use.

Responses lỗi có code ổn định, message tiếng Việt, subject/field/cargo ID và retriable. 401/403 cho quyền, 409 cho version/stale, 422 cho validation; không trả HTTP success với một plan được gắn trạng thái cao dù vi phạm. Local cụ thể hóa error schema và test trước khi freeze generated client.

## 4 Lưu trữ và transaction

SQLite WAL chỉ trên ổ local hợp lệ, không writable qua network share. Metadata/snapshots/index/receipts/audit có foreign keys và transaction. File gốc lưu theo hash, MIME sniffing và tên server cấp; tên upload không thành đường dẫn thực.

Ghi file vào staging, kiểm hash rồi atomic rename; commit record/refs/audit có recovery marker. Crash không để VERIFIED record trỏ blob thiếu. Có kiểm orphaned blobs và cleanup có kiểm soát. Audit append-only ở tầng ứng dụng; không tuyên bố chống được người có toàn quyền OS sửa cả DB và log.

Migration có schema version, backup trước migrate và test đọc/migrate/rollback theo chính sách đã chọn. Không silently migrate bản duy nhất rồi mất khả năng phục hồi. Dữ liệu thật, credentials và runtime-data ngoài Git.

## 5 Backup và restore

Backup dùng SQLite backup API hoặc transaction-consistent snapshot cùng file-store manifest; mỗi blob/record cần checksum và version. Manifest có thời điểm, database schema version, phần mềm, số record và danh sách blobs cần có.

Restore vào staging, verify checksum/ref/invariants và khả năng mở đúng các versions; sau đó operator mới commit thay dữ liệu đang dùng. Có bản rollback trước commit. Lịch sử receipts không bị viết lại, nhưng eligibility hiện tại cần revalidate. Không khôi phục credential/session đang sống từ backup nghiệp vụ; không giả định biết thu hồi nằm ngoài bản backup nếu chưa có nguồn hiện hành.

## 6 File và AI privacy

Kiểm extension/MIME/kích thước thực, traversal, archive bombs, executable/macro. Excel formulas không được tự thực thi như lệnh; parser chỉ đọc dữ liệu theo policy. CSV/Excel export ngăn formula injection. Giới hạn tài nguyên OCR/parser được cấu hình và kiểm trên máy mục tiêu.

AI cloud, nếu bật, chỉ nhận trường tối thiểu sau quyền cho phép phù hợp; không âm thầm gửi toàn bộ chứng từ. Nội dung tài liệu là dữ liệu untrusted, không có quyền thay rules, gọi tool hoặc tự cấp scope. Bản core không cần API key hoặc tài khoản AI để hoạt động.

## 7 Cây triển khai đích

| Đường dẫn dự kiến | Trách nhiệm |
|---|---|
| apps/frontend | Intake, case, workspace, viewer, history/export; generated API client |
| services/backend/app/domain | Pure domain validation, geometry, profiles/rules, optimizer interface, lifecycle |
| services/backend/app/adapters | SQLite, file store, optional AI, optional CVF bridge |
| services/backend/app/api | Authenticated typed API, jobs, error mapping |
| packages/cvf-guard-bridge | Node bridge bounded sau compatibility spike |
| tests | Domain, solver oracle, integration, UI, security, recovery |
| tooling/local-launcher | Một điểm khởi chạy local, đóng service đúng và thông báo lỗi |

Đây là cấu trúc đích. Agent local phải xuất TREEVIEW_AS_BUILT từ repo thực sau khi code, không coi bảng này là repo đã tạo.

# Nghiệm thu và bằng chứng v0.2

**Vai trò của tài liệu:** yêu cầu nghiệm thu thuộc package `OFFICIAL_LOCAL_AGENT_HANDOFF`, trạng thái `READY_FOR_LOCAL_VERIFICATION`.

Các tiêu chí dưới đây là công việc Agent local phải chứng minh khi triển khai. Kết quả kiểm schema hoặc reference checks đi kèm package chỉ chứng minh phần kiểm tra được ghi rõ trong log. Chúng không làm G1–G5 tự chuyển thành PASS và không thay xác nhận kỹ thuật của phương tiện.

## 1 Phạm vi nghiệm thu bản đầu

Core v0.2 lập phương án sơ bộ cho một hầm mục tiêu BOX được xác nhận đang trống. Hàng có sẵn ở ngoài hầm mục tiêu vẫn tham gia hạn mức toàn tàu và phải có nguồn xác nhận. Không có luồng xếp lên hàng hiện hữu trong hầm mục tiêu ở phạm vi khởi động. Hai nhóm bó thép thanh và bó thép ống chỉ được dùng khi có profile phù hợp; cấu hình xếp tầng bị khóa cho tới khi profile và bằng chứng theo gate tương ứng đủ điều kiện.

Basis khối lượng đã chốt là `CARGO_PLUS_PLANNED_DUNNAGE`: `existingCargoKg + tổng massKg của unit thực xếp + plannedDunnageMassKg <= voyageCargoLimitKg <= certificateCargoLimitKg`. Hạn mức chuyến đã dành các tải không thuộc phần cargo budget được người có trách nhiệm xác nhận; chưa trừ phần kê mới dự kiến. `existingCargoKg` đã bao gồm phần kê hiện hữu thuộc khoản tải đã khai, còn `plannedDunnageMassKg` chỉ dành cho kê mới. Backend không tự trừ thêm một lần nữa. Thời hạn nguồn áp dụng được xét cho khoảng ngày bao gồm cả `operatingDate` và `validThroughDate`, theo timezone của case.

Geometry, validator, UI và export phải dùng cùng dữ liệu đã pin. Field review có trách nhiệm riêng với ổn định, sức bền, tải cục bộ, chằng buộc và khả năng thao tác còn ngoài phạm vi tự tính. Không cấp nhãn SAFE/CERTIFIED/EXECUTION_READY từ việc tìm được nghiệm hình học.

## 2 Các cổng nghiệm thu

| Gate | Phạm vi cần chứng minh | Bằng chứng tối thiểu | Người quyết định |
|---|---|---|---|
| G0 | Phạm vi triển khai và dữ liệu mẫu | Owner xác nhận chế độ xếp đủ/tùy chọn, hầm mục tiêu, nhóm hàng, vai trò xác minh; danh sách điều kiện kỹ thuật chưa có | Owner; chuyên môn xác nhận phần thuộc trách nhiệm kỹ thuật |
| G1 | Dữ liệu và lưu trữ | Schema, import thực, phân biệt draft/verified, đơn vị, IDs, refs/hash, immutable versions, migrations, crash recovery và backup/restore chạy thật | Người triển khai và reviewer |
| G2 | Validator và profile áp dụng | Rule coverage, negative tests, profile có nguồn/phạm vi/phiên bản; kiểm khối lượng, hình học và điều kiện đỡ; chuyên môn xác nhận tham số thực | Reviewer kỹ thuật; chuyên môn cho phần thông số/phạm vi |
| G3 | Solver | Oracle nhỏ độc lập, required/optional/excluded, feasible/infeasible/timeout, candidate revalidation, seed/build/config và hiệu năng trên máy mục tiêu | Người triển khai và reviewer |
| G4a | Core UI, API và quyền người dùng | E2E nhập–kiểm–xếp–chỉnh–chọn–xuất; operator authentication; receipts; stale/race tests; 2D fallback; hoạt động khi AI tắt | Owner và reviewer |
| G4b | AI actions và CVF | Xác minh pinned source, bridge contract, read/deny/allowed bounded action, lỗi/timeout/ESCALATE/replay, authority isolation | Reviewer; owner quyết định bật khả năng AI |
| G5 | Đối chiếu thực tế có kiểm soát | 2–3 chuyến tham chiếu phù hợp phạm vi; manifest–vị trí–tải–thao tác đối chiếu; review hồ sơ và điều kiện sử dụng thực | Người có trách nhiệm chuyên môn và owner |

G4a là gate bắt buộc cho core. Với bản không bật AI actions, G4b được ghi `NOT_IN_SCOPE`, kèm bằng chứng rằng các capability tương ứng bị vô hiệu hóa. Trước khi bật AI actions sau này phải đánh giá G4b; không dùng trạng thái NOT_IN_SCOPE làm miễn trừ vĩnh viễn.

Có thể dựng skeleton, parser và test harness sau khi đã đọc, rà và chốt phạm vi công việc phù hợp. Không yêu cầu phải có runtime PASS trước khi được viết code; ngược lại, việc có skeleton không đủ để PASS gate.

### Trạng thái gate

- `NOT_STARTED`: chưa bắt đầu công việc hoặc chưa có bằng chứng.
- `PENDING`: đang có bằng chứng nhưng chưa đủ hoặc chưa có người rà soát.
- `BLOCKED`: một điều kiện phụ thuộc chưa được đáp ứng; nêu điều kiện và người xử lý.
- `FAIL`: đã chạy kiểm tra và không đạt; dẫn log cụ thể.
- `PASS`: đã có bằng chứng phù hợp và quyết định của người được giao trách nhiệm.
- `NOT_IN_SCOPE`: chỉ dùng với khả năng không bật trong bản phát hành; phải ghi điều kiện để mở lại gate. G4a, G1 và G2 không được bỏ bằng trạng thái này.

Không điền tên reviewer, thời điểm, chữ ký hoặc kết luận giả để đủ bảng. Những ô chưa có thông tin phải giữ `CHƯA_CÓ` hoặc `NOT_RUN`.

## 3 Bằng chứng cho một ca kiểm tra

Mỗi lần chạy cần ghi: test ID; mục yêu cầu/finding liên quan; source commit thực; lệnh chính xác; timestamp có timezone; runtime và dependency versions; máy/OS khi ảnh hưởng kết quả; input fixture hash; rule/profile/snapshot hashes; expected; actual; verdict; đường dẫn log; giới hạn kết luận. Hash chỉ chứng minh tính toàn vẹn so với nội dung được băm, không tự chứng minh nguồn hay người duyệt.

| Trường hợp | Cách báo cáo |
|---|---|
| Chưa chạy | `NOT_RUN`; không điền actual hoặc log giả |
| Reference check trên fixture synthetic | Ghi `CONTRACT_REFERENCE_ONLY`; không gọi là API/solver/engineering test |
| Runtime test thật trên môi trường local | Ghi commit, dependency, command, actual và log |
| Kết quả quan sát thủ công | Ghi người thực hiện, quy trình và dữ liệu đối chiếu; screenshot bổ trợ, không thay oracle số |
| Bị hạn chế bởi dữ liệu hoặc quyền truy cập | Ghi `BLOCKED` cùng điều kiện để tiếp tục |

Đối với kiểm thử âm tính, PASS nghĩa là hệ thống đã từ chối đúng điều kiện sai được thử; không có nghĩa fixture đó trở thành dữ liệu được phép sử dụng.

## 4 Ma trận kiểm thử bắt buộc tại local

Các mã `LAT-*` dưới đây là mã nghiệm thu nghiệp vụ ổn định. Agent local ánh xạ chúng tới test function/fixture cụ thể trong implementation; không coi bảng này là danh sách test đã chạy.

| ID | Input hoặc hành động | Expected phải chứng minh | Gate |
|---|---|---|---|
| LAT-001 | GT, DWT và cargo limit cùng xuất hiện; payload thiếu nguồn | Không đổi GT/DWT thành payload; thiếu nguồn payload thì không tạo đầu vào đủ điều kiện solver | G1/G2 |
| LAT-002 | Chứng từ hết hạn, thiếu thời hạn bắt buộc, hoặc ngày chuyến đổi | Kiểm loại chứng từ và ngày biên; thiếu/hết hiệu lực thì chặn hành động mới | G1/G2 |
| LAT-003 | CSV/Excel có mm/m, kg/tấn, decimal locale mơ hồ hoặc phần kg lẻ | Không âm thầm đoán đơn vị hoặc làm tròn xuống; giữ nguồn và yêu cầu xử lý đúng policy | G1 |
| LAT-004 | Draft thiếu hạn mức và có trường xung đột | Lưu/mở lại đúng trạng thái thiếu/xung đột; không tạo verified snapshot giả | G1/G4a |
| LAT-005 | Trùng/mất/ID lạ; cùng unit vừa placed vừa unplaced; tổng mass khai sai | Validator đối soát đầy đủ manifest và phân hoạch, tính lại tổng từ unit thực | G1/G2 |
| LAT-006 | Tổng cargo đúng hạn mức và vượt đúng 1 kg | Đúng hạn mức chỉ qua bước mass; vượt 1 kg bị chặn, không tăng epsilon tải | G2 |
| LAT-007 | Hầm mục tiêu chưa xác nhận trống hoặc có hàng cũ | Core v0.2 từ chối; hàng ngoài hầm mục tiêu chỉ được nhận khi có nguồn và vẫn cộng vào tải toàn tàu | G1/G2 |
| LAT-008 | Profile không tồn tại, sai loại hàng, chưa duyệt hoặc hash/version sai | Chặn dữ liệu thuộc profile đó; không dùng profile mặc định tự suy ra | G2 |
| LAT-009 | BOX vừa biên/vượt 1 mm, xoay 90 độ, overlap, excluded zone, margin làm miền rỗng | Kết luận hình học theo cùng công thức, điểm neo và tọa độ; expected độc lập renderer | G2/G3 |
| LAT-010 | Tầng trên thiếu đỡ, support cycle/ID lạ, hỗn hợp tầng chưa hỗ trợ | Không tạo candidate đủ hard checks; layered mode chưa được kích hoạt thì bị chặn | G2/G3 |
| LAT-011 | Thêm kê làm vượt chiều cao; thay dự phòng phụ trợ | Geometry và mass basis nhất quán; không bỏ sót hoặc trừ hai lần; snapshot đổi | G2/G3 |
| LAT-012 | Bỏ outcome của rule bắt buộc, outcome trùng, HARD/HARD_GATE/GOVERNANCE unknown hoặc FAIL, NOT_APPLICABLE không có căn cứ | Coverage được tính từ rule snapshot; không tạo selection receipt hợp lệ | G2/G4a |
| LAT-013 | Fixture có required/optional khác nhau; ALL_OR_NONE khi manifest khai báo nhóm | Kết quả phản ánh đúng mode, tập bắt buộc và nguyên tắc chọn nguyên kiện/đi đủ nhóm; MAXIMIZE_OPTIONAL dùng mục tiêu cố định tối đa tổng massKg của optional đã xếp, không đổi trọng số hoặc bỏ required | G3 |
| LAT-014 | Fixture đã biết có nghiệm nhưng time budget không đủ | `termination=TIME_LIMIT`, `proof=NOT_PROVEN`; candidate/fulfillment phản ánh kết quả thật; không báo `PROVEN_INFEASIBLE` chỉ vì hết giờ | G3 |
| LAT-015 | Candidate do solver trả về vi phạm hoặc mang ID ngoài manifest | Validator độc lập từ chối; không tin solverStatus hoặc mass do solver gửi | G3 |
| LAT-016 | Đổi thứ tự key, đổi 1 mm/1 kg/ref, sửa nội dung sau validation | Hash chuẩn tái lập; thay nội dung đổi hash; receipt cũ không chuyển sang nội dung mới | G1/G4a |
| LAT-017 | UI kéo ra ngoài hầm; request cũ về sau khi case đổi version | Preview không ghi đè snapshot; backend reject/mark stale, UI rollback hoặc mở phiên bản mới | G4a |
| LAT-018 | AI credential giả tên operator; browser giả role/traceHash | Server lấy actor từ kênh đã xác thực; confirm/select và field review bị chặn cho agent | G4a/G4b |
| LAT-019 | CVF read hợp lệ, forbidden mutation, allowed bounded draft revision | Cả ba nhánh hoạt động đúng action/scope/target và tạo audit thích hợp | G4b |
| LAT-020 | Bridge timeout, thiếu/malformed response, ESCALATE, replay, sai nonce/hash/version hoặc false ALLOW | Agent action fail closed; backend không bỏ qua nghiệp vụ; core thủ công vẫn hoạt động | G4b |
| LAT-021 | Crash giữa file/DB; duplicate intake; restore dữ liệu cũ | Không có verified record trỏ file thiếu; restore giữ lịch sử và yêu cầu kiểm hiệu lực hiện tại trước hành động mới | G1/G4a |
| LAT-022 | Không có AI, WebGL lỗi hoặc máy GPU yếu | Core nhập/kiểm/lưu/xuất vẫn dùng được; có 2D/text fallback; không mất dữ liệu | G4a |
| LAT-023 | Field-review attachment/receipt thuộc plan khác; CVF ALLOW thay cho review | Không ghi nhận bàn giao hợp lệ cho plan hiện tại; loại bằng chứng không thay thế nhau | G4a/G5 |
| LAT-024 | Final geometry vừa nhưng tiếp cận/thứ tự/ổn định chưa được đánh giá | Báo phương án sơ bộ và coverage; không tự nâng thành điều kiện thi công | G2/G5 |
| LAT-025 | Dữ liệu testOnly cố đi vào luồng vận hành | Bị chặn ở backend; chỉ được dùng trong test harness hoặc môi trường thử riêng | G1/G4a |

Các test về bảo mật đầu vào của baseline vẫn bắt buộc: tài liệu chứa lệnh prompt bị coi là dữ liệu; traversal/macro/executable upload bị từ chối; file lớn và archive được giới hạn; export không biến nội dung người dùng thành công thức thực thi. Ghi rõ case, oracle và biện pháp đã hiện thực, không chỉ đánh dấu “đã xử lý”.

## 5 Hiệu năng và tiêu chí sử dụng

Không tự đặt phần trăm cải thiện năng suất hoặc cam kết thời gian giải từ fixture nhỏ. Trước G3, chọn máy mục tiêu, khoảng số bó thông thường/lớn, time budget, mục tiêu required/optional và tiêu chí UI phản hồi từ dữ liệu mẫu thực. Báo riêng thời gian parse, preflight, solve, revalidate, render và export khi cần chẩn đoán.

Timeout phải giữ được thông tin run và candidate nếu có; candidate chỉ được dùng sau kiểm lại. Hủy tác vụ không được tạo receipt hoặc ghi đè phương án đã chọn. Không dùng một lần chạy nhanh làm bảo đảm hiệu năng cho mọi manifest.

## 6 Khôi phục và hiệu lực hiện tại

Restore cần kiểm tính toàn vẹn của DB/files/refs, mở đúng phiên bản và giữ nguyên lịch sử. Sau restore, quyền sử dụng hiện tại là bước đánh giá riêng: thời hạn chứng từ, case đang chọn, rule/profile còn áp dụng và các quyết định liên quan cần được kiểm lại trước thao tác mới. Không khôi phục session/credential đang hoạt động cùng backup nghiệp vụ. Nếu không có dữ liệu hiện hành để biết một receipt đã bị thu hồi hay chưa, ghi chưa xác minh; không suy ra trạng thái từ sự vắng mặt của thông tin.

## 7 Đầu ra bắt buộc của Agent local

1. `LOCAL_DESIGN_REVIEW.md`: điểm phù hợp/khác biệt với v0.2, disposition từng finding R1 và đề nghị thay đổi có căn cứ.
2. `GATE_STATUS.md`: gate, trạng thái, phạm vi áp dụng, evidence và người quyết định thật.
3. `RUNTIME_EVIDENCE/`: lệnh, input và hashes, expected/actual, logs, giới hạn kết luận; không đưa giấy tờ cá nhân vào log công khai.
4. `CVF_COMPATIBILITY_REPORT.md`: source SHA, package/import/license/dependencies, guards và các nhánh bridge thực tế; nếu G4b không áp dụng thì ghi lý do và bằng chứng capability đã tắt.
5. `OPEN_DECISIONS.md`: chỉ các câu hỏi cần owner/chuyên môn quyết định để tiến tới gate kế tiếp.
6. `TREEVIEW_AS_BUILT.md`: cấu trúc đã tạo, không chép cây dự kiến rồi gọi là đã triển khai.

Mẫu báo cáo khởi đầu nằm trong `templates/LOCAL_AGENT_REPORT.md`. Mỗi kết quả phải phân biệt rõ `SPECIFIED`, `IMPLEMENTED`, `TEST_EVIDENCED` và `FIELD_REVIEWED` theo phạm vi cụ thể.

# Nguồn và phạm vi áp dụng

Ngày đối chiếu nguồn của vòng phản biện: **31-10-2026**. Package không đưa guideline nước ngoài hoặc quy định chưa hiệu lực thành hard rule cho mọi sà lan. Đây là danh mục provenance để Agent local và chuyên môn kiểm cụ thể trước khi tạo rule operational.

## Nguồn kỹ thuật và pháp lý

| ID | Nguồn | Điều đã đối chiếu | Giới hạn |
|---|---|---|---|
| W1 | IHO Geospatial Information Registry, Gross Ton | GT là chỉ số từ thể tích, không phải kg | Không dùng làm nguồn cargo capacity của tàu |
| W2 | IMO Compendium, Ship Reporting Systems, IMO0376 | Actual deadweight là đại lượng riêng với gross tonnage | Không tự suy payload từ DWT |
| W3 | IMO CSS Code và Annex 7 | Phân bố hàng, tải đáy/boong, kê/chèn là các kiểm tra riêng | Không chứng minh áp dụng nội địa hoặc clearance cho tàu cụ thể |
| W4 | Jurong Port Stowage Requirements | Phạm vi cảng và nội dung stowage/lashing/dunnage/bundling | Thực hành cảng riêng; không nhập các con số thành default |
| W5 | Thông tư 78/2026/TT-BXD, cổng Chính phủ | Ban hành 27-10-2026; hiệu lực 01-05-2027; sửa đổi QCVN 72:2025/BGTVT | Chưa dùng như sửa đổi có hiệu lực ngày 31-10-2026 |
| W6 | Thông tư 02/2025/TT-BGTVT, cơ sở dữ liệu VBPL | Kết quả tra cứu chính thức ghi ban hành QCVN 72:2025/BGTVT và hiệu lực 01-08-2025 | Chưa rà mọi điều khoản của quy chuẩn cho phương tiện cụ thể |

### URL nguồn

- W1: https://registry.iho.int/fdd/view5.do?idx=2652&type=5&valueType=0
- W2: https://imocompendium.imo.org/public/IMO-Compendium/Current/DS/Ship%20Reporting%20System/d11.htm
- W3 trang IMO: https://www.imo.org/en/ourwork/safety/pages/css-code.aspx
- W3 bản A.714(17) của IMO: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/AssemblyDocuments/A.714%2817%29.pdf
- W3 bản nội dung Annex 7 đã đọc qua cơ quan Hà Lan: https://puc.overheid.nl/nsi/doc/PUC_2092_14/
- W4: https://www.jp.com.sg/faqs/stowage-requirements/
- W5: https://vanban.chinhphu.vn/?classid=1&docid=220128&pageid=27160
- W6: https://vbpl.moj.gov.vn/TW/Pages/vbpq-toanvan.aspx?ItemID=174773

PDF A.714(17) trực tiếp vượt giới hạn truy xuất trong vòng phản biện; nội dung Annex 7 được đọc từ bản cơ quan Hà Lan. Toàn trang W6 có lần trả 502, trong khi kết quả tra cứu chính thức đọc được thông tin văn bản. Hai giới hạn truy xuất này được giữ để không trình bày như đã rà toàn văn hiện hành. Local kiểm phiên bản/sửa đổi và điều khoản trước activation của rule.

Không có hồ sơ tàu thật trong fixtures. Các số đăng ký, payload hoặc ngày hết hạn được thuật lại ở baseline lịch sử chưa được vòng này đối chiếu bản gốc; không sao chép chúng vào source of truth của sản phẩm.

## Nguồn CVF

Baseline tham chiếu repo `Blackbird081/Controlled-Vibe-Framework-CVF-Provenance`, commit:

```text
ebf31b9f5c42e4de58f40a434409c3441a5d8383
```

Các file cần kiểm tại local:

- `EXTENSIONS/CVF_GUARD_CONTRACT/src/engine.ts`
- `EXTENSIONS/CVF_GUARD_CONTRACT/src/types.ts`
- `EXTENSIONS/CVF_GUARD_CONTRACT/package.json` và exports/build output thực
- License và lockfile/runtime dependencies
- `docs/reference/CVF_SEMANTIC_POLICY_INTENT_REGISTRY.md`
- Review liên quan RiskGate/approval trong snapshot

URL mốc: https://github.com/Blackbird081/Controlled-Vibe-Framework-CVF-Provenance/tree/ebf31b9f5c42e4de58f40a434409c3441a5d8383

Vòng phản biện chưa xác minh độc lập cây source pinned qua truy cập công khai. Điều này không kết luận repo/commit không tồn tại. Local phải chứng minh imports, registration và runtime decisions thật; protocol adapter trong docs/04 không tự được coi là API canonical có sẵn trong CVF.

## Hồ sơ activation của một rule operational

Người có trách nhiệm xác định: nguồn/phiên bản/điều khoản, cargo type, vessel class, vùng hoạt động, khoảng ngày, điều kiện và dữ liệu cần có, output/decision policy, người rà và ca test. Lưu snapshot/hash nguồn khi được phép, kèm locator và ngày kiểm. Evidence ref phải resolve đến record bất biến trong hệ thống.

S-012 về ưu tiên chiều dài chưa có profile và nguồn đủ cụ thể nên không active ở cấu hình ban đầu. Các engineering checks S-009–S-011 vẫn xuất hiện trong coverage ngay khi chưa tính. Profile của cảng nước ngoài có thể là đầu vào tham khảo; việc chấp thuận nội bộ không tự thay các yêu cầu pháp lý bắt buộc.

## Nguồn phát sinh package

- Baseline: `history/Steel_Cargo_Stowage_Tool_MVP_v0.1_Design_Baseline.zip`.
- Báo cáo độc lập: `history/CVF_Steel_Cargo_Independent_Review_R1.docx`.
- Replay và kết quả R1: `history/CVF_Steel_Cargo_Review_R1_Local_Handoff.zip`.

Các file lịch sử giữ nguyên byte; SHA-256 ghi trong PACKAGE_MANIFEST và checksum của release. Các quyết định đang hiệu lực nằm ở v0.2, không ở bản lịch sử.

# Quyền local và adapter CVF v0.2

**Trạng thái yêu cầu:** `READY_FOR_LOCAL_VERIFICATION`. Đây là contract của ứng dụng cần triển khai và kiểm chứng; không phải báo cáo CVF đã tích hợp.

## 1 Quyền nghiệp vụ và CVF

Backend quản lý actor, dữ liệu đã xác minh, phiên bản bất biến và quyền chuyển trạng thái. Cargo validator kiểm các bất biến nghiệp vụ. CVF chỉ quyết định một agent có được thực hiện hành động trong phạm vi được cấp hay không. Cả ba phần đều phải đạt điều kiện tương ứng trước khi một agent mutation được commit.

UI không cấp quyền bằng cờ trong payload. Tài liệu người dùng tải lên, text do AI tạo, client-supplied actor/role/risk level/traceHash và kết quả solver đều không phải nguồn thẩm quyền. `confirmedBy` hay một hash trong JSON là dữ liệu truy vết; backend phải kiểm actor và đối tượng thật trước khi tạo bản ghi đó.

## 2 Mô hình quyền local tối thiểu

Core triển khai một backend local và frontend do backend phục vụ hoặc được cấu hình cùng một origin được phép. Bản local mặc định chỉ lắng nghe loopback; không tự mở `0.0.0.0` hoặc công bố ra mạng. Nếu cần chế độ LAN/multi-user, phải có thay đổi phạm vi và thiết kế xác thực riêng trước khi bật.

- **Operator session:** phiên do backend phát hành sau quy trình khởi tạo/xác thực local; quyền confirm/select gắn với phiên operator và thao tác xác nhận cụ thể trên đúng target/version/hash.
- **Agent capability:** credential riêng, có allowlist action/scope và có thể thu hồi. Không dùng chung credential operator, không truyền operator session vào prompt hoặc tools.
- **Actor authoritative:** backend lấy actor từ phiên/capability đã kiểm; bỏ qua hoặc từ chối trường tự khai quyền ở payload. Tên hiển thị không phải proof of identity.
- **Request protection:** kiểm Origin/Host theo cấu hình local; bảo vệ CSRF cho các endpoint dùng cookie; không dùng CORS rộng để thay xác thực; không nhận credential nhạy cảm qua URL. Khi dùng cookie, chọn cấu hình cookie phù hợp giao thức thực và chống gửi chéo site.
- **Concurrency:** confirm/select/edit dùng target version/hash hiện tại và optimistic concurrency. Xác nhận đến muộn cho snapshot cũ bị từ chối hoặc mở một luồng xem lại, không gắn sang bản mới.
- **Audit:** ghi principal, action, target, timestamp, request/correlation ID, outcome và hashes; không ghi token/API key hay toàn bộ chứng từ nhạy cảm.

Mô hình này phân biệt đường operator và đường agent trong ứng dụng. Nó không tự chứng minh người bấm nút là một người cụ thể trước kẻ kiểm soát toàn bộ hệ điều hành hoặc tài khoản local. Local implementer phải ghi rõ giới hạn đó, quyền truy cập file/DB và phạm vi bảo vệ; không gọi audit trong SQLite là bất khả sửa bởi chủ máy.

## 3 Các hành động và quyền

| Action | Operator | Agent | Điều kiện chính |
|---|---|---|---|
| Đọc hồ sơ trong case được cấp | Theo phiên và phạm vi | Có thể cấp | Đúng scope, không mở tài liệu ngoài yêu cầu |
| Trích xuất tài liệu thành draft | Cho phép | Có thể cấp | Nội dung là dữ liệu chưa xác minh; cloud gửi dữ liệu tối thiểu sau quyền đã cấp |
| Đề xuất hoặc chạy tối ưu sơ bộ | Cho phép khi readiness đạt | Có thể cấp qua CVF | Snapshot pin đầy đủ; backend preflight; kết quả qua validator |
| Tạo đề nghị sửa/draft revision | Cho phép | Có thể cấp qua CVF | Đúng plan/version, không ghi đè nội dung đã chọn; không tự tạo selection receipt |
| Xác nhận intake/profile/manifest | Theo vai trò đã được giao | Luôn từ chối | Nguồn đúng, actor thật trong hệ thống, xác nhận rõ và tạo version |
| Đổi cargo limit hoặc xác nhận hạn mức chuyến | Theo vai trò và nguồn hợp lệ | Luôn từ chối | Không sửa âm thầm dữ liệu cũ; tạo snapshot mới |
| Chọn phương án | Theo vai trò | Luôn từ chối | Validation receipt hiện hành, hard checks đủ, target hash đúng |
| Ghi nhận review/bàn giao hiện trường | Theo vai trò chuyên môn/quy trình | Luôn từ chối | Bằng chứng đúng loại, phạm vi, case và plan; không suy từ CVF ALLOW |
| Sửa/duyệt rule hoặc support profile | Luồng quản trị có review | Planning agent không được cấp | Nguồn, phạm vi, phiên bản và tests; không sửa trong cuộc tối ưu đang chạy |
| Restore hoặc thao tác quản trị file | Luồng local có quyền tương ứng | Không nằm trong allowlist v0.2 | Kiểm toàn vẹn, audit và tái kiểm hiệu lực |

Read-only scope cũng cần kiểm, kể cả khi không có mutation. Một tool không được cấp quyền vì tên của nó nghe như thao tác đọc nếu thực tế có side effect.

## 4 Phiên bản CVF phải xác minh

Baseline dẫn repository `Blackbird081/Controlled-Vibe-Framework-CVF-Provenance`, commit `ebf31b9f5c42e4de58f40a434409c3441a5d8383`. Package này giữ commit làm mốc cần đối chiếu, chưa tuyên bố đã xác minh source/runtime độc lập ở local.

Agent local phải kiểm: checkout thực; tree/diff so với mốc; package/import/export surface; license; dependency/lockfile và runtime hỗ trợ; cách đăng ký mandatory guards; kiểu request/evidence; aggregation ALLOW/BLOCK/ESCALATE; lỗi và timeout. Các tên file/symbol đã được baseline dẫn là đầu mối tra cứu, không phải bằng chứng chúng tồn tại hoặc hoạt động trong checkout hiện tại.

Nếu checkout khác commit, ghi sự khác biệt trước khi chọn runtime pin. Không sửa CVF core để ép bridge đi qua gate. Nếu cần thay đổi upstream, ghi đề nghị riêng; core thủ công vẫn có thể tiếp tục với AI actions tắt.

## 5 Contract truyền thông của adapter ứng dụng

Đây là protocol v0.2 giữa backend và bridge của ứng dụng. Nó phải được ánh xạ sang API canonical của CVF sau kiểm nguồn; các trường dưới đây không được trình bày như schema sẵn có của CVF.

Ưu tiên bounded Node child process hoặc một IPC local được cô lập, với timeout, giới hạn kích thước thông điệp và kiểm schema hai chiều. Không import CVF runtime vào React, không sao chép luật canonical vào Python để gọi đó là tích hợp. Transport cụ thể được local spike chọn và ghi trong báo cáo tương thích.

### Request do backend tạo

| Thành phần | Yêu cầu |
|---|---|
| `protocolVersion` | Giá trị cố định của adapter đã pin; mismatch thì từ chối |
| `requestId`, `nonce` | Do backend tạo, ràng buộc một action attempt; nonce không nhận từ tài liệu/AI |
| `issuedAt`, `deadlineAt` | Backend đặt; dùng deadline tương thích giữa hai process, timeout không tạo ALLOW |
| `action` | Trong allowlist đã cấp cho principal; không dùng arbitrary method execution |
| `principal` | Backend tạo từ agent capability đã xác thực; gồm identity/capability/scope cần thiết, không chuyển secret |
| `targetRefs` | Tham chiếu immutable target theo kind, ID, version, hash của contract dữ liệu |
| `inputSnapshotSha256` | Snapshot đầu vào mà action được phép tác động |
| `actionPayloadSha256` | Nội dung action được chuẩn hóa theo `STOWAGE-JSON-0.2` và băm; tránh dùng receipt cho payload khác |
| `policySnapshotRef` | Phiên bản policy/guard configuration dùng cho action |
| `requestDigest` | Băm toàn bộ phần request có nghĩa, loại trừ chính digest; dùng `STOWAGE-JSON-0.2` và test vector được pin |

Backend lưu bản request đầy đủ. Việc thiếu một thành phần binding phải làm request không đủ điều kiện mutation. `targetRefs` đọc nội dung từ snapshot store đã kiểm hash, không lấy trực tiếp trạng thái quyền do browser gửi.

### Response và receipt của bridge

Response phải chứa protocol version; request ID; request digest; nonce; decision chính xác `ALLOW`, `BLOCK` hoặc `ESCALATE`; reason codes; engine/policy build hoặc version đã pin; evaluatedAt và expiry theo contract; kết quả guard cần thiết để trace. Backend kiểm response từ đúng process/channel được cấu hình, không từ dữ liệu người dùng hoặc một JSON đính kèm.

Chỉ có chuỗi ALLOW là chưa đủ. Backend phải kiểm tất cả bindings, thời hạn và mandatory guard coverage. Không tin response chỉ vì có hash: hash không chứng minh nguồn phát. Nếu transport không bảo đảm nguồn hoặc có nhiều process không tin cậy cùng kênh, cần cơ chế xác thực thông điệp thích hợp trước khi nghiệm thu.

### Kiểm lại trước commit

1. Xác minh response tương ứng request còn đang chờ, đúng nonce/action/payload/target/input/policy.
2. Kiểm capability chưa bị thu hồi và target snapshot vẫn là phiên bản được phép tác động.
3. Áp backend authorization, preconditions, rule coverage và CargoSafetyEngine độc lập.
4. Commit bằng transaction với optimistic concurrency và audit. Nếu có thay đổi cạnh tranh, từ chối hoặc yêu cầu revision mới.
5. Đánh dấu request đã sử dụng. Replay không thực hiện lại mutation; retry có idempotency hợp lệ chỉ trả lại kết quả của chính action đã commit, không đổi target hay payload.

Response lỗi, thiếu dữ liệu, khác digest/nonce/version, hết hạn, đến muộn, process lỗi hoặc bridge không liên lạc được đều chặn agent mutation. `ESCALATE` ghi yêu cầu rà soát; nó không tự cấp quyền và không được biến thành ALLOW khi người dùng bấm một nút không có receipt thích hợp.

## 6 Bằng chứng spike và gate G4b

Tối thiểu ba nhánh:

1. Một `read_profile` đúng scope được thực hiện, có audit và giới hạn tài liệu.
2. Một `change_cargo_limit` bị chặn dù agent gửi actor/role giống operator.
3. Một `request_plan_revision` được cho phép trong phạm vi đã cấp, chỉ tạo draft/revision hợp lệ; không chọn hoặc bàn giao phương án.

Sau đó kiểm: sai action, sai target/version/hash, payload bị đổi, nonce replay, request hết hạn, revocation, policy mismatch, mandatory guard thiếu, malformed response, timeout, BLOCK, ESCALATE và bridge giả ALLOW cho dữ liệu vi phạm hard constraint. Sai một binding không được chỉ ghi warning rồi commit.

G4b chỉ PASS khi đã có bằng chứng đường thành công và đường từ chối, cùng kiểm rằng core thủ công vẫn hoạt động khi AI/CVF tắt. Một read thành công và một mutation bị chặn chưa đủ nghiệm thu toàn bộ integration.

## 7 Ba loại receipt không thay thế nhau

- **Validation receipt:** ghi validator đã kiểm nội dung/snapshot/rules nào, outcome và giới hạn kết luận.
- **Quyết định người dùng hoặc review hiện trường:** gắn actor được xác thực, vai trò, đúng plan/case/validation, phạm vi, bằng chứng và kết luận của sự kiện nghiệp vụ tương ứng.
- **CVF action receipt:** cho phép hoặc từ chối một action của agent trong scope/time/target cụ thể.

Trong machine model, `validation_receipt` luôn pin plan/case/rule set. `runRef` chỉ đi với phương án sinh từ SOLVER/SYNTHETIC; revision `MANUAL_EDIT` phải bỏ `runRef`, pin `parentPlanRef` trong PlanContent và được kiểm lại độc lập. Revision không kế thừa trạng thái hoặc proof tối ưu của run cha. `decision_receipt` phân biệt `USER_SELECTION`, `FIELD_REVIEW` và `REVOCATION`; `lifecycle_event` lưu sự kiện riêng với `planRef` và receipt phù hợp. `authenticationEventId` và `sourceAuthority=SERVER_AUTHENTICATED_EVENT` chỉ có giá trị khi backend đối chiếu được sự kiện xác thực thật. JSON Schema chấp nhận một chuỗi không chứng minh sự kiện ấy đã xảy ra.

`evidenceRefs` trong quyết định phải được backend giải tới một evidence registry bất biến có hash và quyền truy cập; một đường dẫn/URL hay chuỗi do client tự gửi chưa đủ làm bằng chứng. `coveredRuleIds` nêu các rule mà review đã xem xét. USER_SELECTION dùng danh sách rỗng vì lựa chọn của user không phải clearance kỹ thuật. Với FIELD_REVIEW có kết luận chấp nhận, backend đối chiếu coverage với toàn bộ engineering checks áp dụng còn cần review ngoài tool; chỉ loại khỏi tập yêu cầu khi có căn cứ NOT_APPLICABLE được kiểm. Một review bị từ chối có thể chưa cover hết nhưng không được tạo FIELD_HANDOFF_RECORDED hợp lệ.

Backend không dùng CVF action receipt thay quyết định của người dùng, không dùng user selection thay field review và không dùng field attachment thay validation hard constraints. Tên các entity/field nghiệp vụ cụ thể tuân theo schema hiện hành trong `contracts/`; protocol bridge được triển khai bằng adapter có version riêng.

## 8 Dữ liệu AI và giới hạn nguồn

AI cloud chỉ nhận dữ liệu trong phạm vi đã được operator cho phép; mặc định tài liệu gốc ở local. Không đưa token, session, toàn bộ hồ sơ hoặc source riêng vào request chỉ để “giải thích” nếu action không cần. Nội dung tài liệu không được phép đổi tool catalog, policy, hạn mức hay actor. Kết quả trích xuất giữ trạng thái chưa xác minh cho đến luồng xác nhận hợp lệ.

Agent local nộp `CVF_COMPATIBILITY_REPORT.md` có source SHA thật, file/package đã đọc, lựa chọn transport, contract mapping, commands, expected/actual, logs và các giới hạn còn lại. Khi chưa có bằng chứng tương thích, giữ AI actions vô hiệu hóa và ghi G4b `NOT_IN_SCOPE` cho bản core hoặc `BLOCKED` nếu đang triển khai capability đó.

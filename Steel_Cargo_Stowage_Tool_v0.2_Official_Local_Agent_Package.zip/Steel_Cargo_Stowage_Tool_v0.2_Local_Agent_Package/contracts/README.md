# Contracts v0.2

Đây là hợp đồng dữ liệu cho package bàn giao chính thức cho Agent local. Nội dung
và tên trường trong `schemas/` là nguồn máy đọc; cách diễn giải nằm trong
`WIRE_MODEL.md`. Đây chưa phải OpenAPI của ứng dụng đã triển khai.

## Cách đọc

1. Đọc `WIRE_MODEL.md` để hiểu các bất biến và ranh giới quyền hạn.
2. Đọc `MODEL_INTERFACE.json` để tra nhanh file schema và tên trường.
3. Dùng `tests/fixtures/valid_bundle.json` để chạy ví dụ liên kết bằng hash thực.
4. Dùng bộ kiểm tra của package để đối chiếu schema và invariant được thực thi
   trong reference harness; các kiểm tra runtime/engineering chưa thực thi phải
   giữ trạng thái chưa có bằng chứng.

## Danh mục schema

| File | Đối tượng |
|---|---|
| common.schema.json | Ref, evidence và rule evaluation dùng chung |
| intake_draft.schema.json | Dữ liệu thiếu hoặc xung đột trước xác nhận |
| vessel_profile.schema.json | Phiên bản hồ sơ tàu đã xác minh theo cấu trúc |
| hold_profile.schema.json | Hầm BOX và miền xếp sau clearance |
| support_profile.schema.json | Hồ sơ kê/chồng theo loại bó hàng |
| manifest.schema.json | Các cargo unit nguyên vẹn và nhóm phải đi đủ |
| rule_set.schema.json | Snapshot bộ quy tắc, phạm vi và nguồn |
| loading_case.schema.json | Phiên bản chuyến/bài toán và các đầu vào đã pin |
| plan_content.schema.json | Nội dung bố trí bất biến, không chứa approval |
| optimization_run.schema.json | Lần chạy, mode và mức chứng minh kết quả |
| validation_receipt.schema.json | Bằng chứng chạy bộ kiểm tra cho đúng plan |
| decision_receipt.schema.json | Lựa chọn, review hiện trường hoặc thu hồi |
| lifecycle_event.schema.json | Sự kiện vòng đời độc lập nội dung plan |
| fixture_bundle.schema.json | Gói ví dụ tổng hợp với hash của từng content |

Các `$id` dưới `https://cvf.local/steel-stowage/0.2/` chỉ là namespace ổn định để
phân giải schema từ registry local. Không phải URL dịch vụ, không tải schema từ
Internet và không dùng một schema mới trên mạng thay schema đã pin.

JSON Schema bảo vệ hình thức. Tham chiếu, số cộng, phân hoạch kiện, hình học,
trạng thái, quyền của người dùng và hiệu lực hiện tại cần bộ kiểm tra nghiệp vụ.

## Quy tắc thay đổi

Không mở `additionalProperties` chỉ để một payload sai qua được schema. Thay
contract phải có version, migration nếu đã có dữ liệu, fixture, negative test và
disposition trong báo cáo local. Snapshot VERIFIED hoặc profile đã APPROVED không
được sửa nội dung dưới cùng ID/version; thay đổi tạo version mới.

Mọi fixture trong package là `testOnly: true`; số đo, hạn mức, actor và profile là
giả lập. Hash thực chỉ chứng minh đúng các byte giả lập đó. Không có hồ sơ phương
tiện thực hoặc phê duyệt kỹ thuật thực được cung cấp bởi các fixture.

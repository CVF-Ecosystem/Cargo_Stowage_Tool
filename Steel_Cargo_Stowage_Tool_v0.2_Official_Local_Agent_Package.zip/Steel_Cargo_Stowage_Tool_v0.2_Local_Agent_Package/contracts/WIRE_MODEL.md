# Wire model và bất biến v0.2

## 1 Phạm vi cố định của lần bàn giao

V0.2 mô hình hóa một hầm mục tiêu dạng BOX, với các bó đứng đúng chiều cao và chỉ
xoay quanh trục z theo 0, 90, 180 hoặc 270 độ. Không lật bó theo pitch/roll. Hầm
mục tiêu phải được xác nhận rỗng. Hàng hiện hữu chỉ được khai báo ở ngoài hầm mục
tiêu; vẫn tham gia cân đối khối lượng toàn tàu.

Hai nhóm hàng là `BUNDLED_REBAR` và `BUNDLED_PIPE`, mỗi unit phải có đúng profile
được pin. Không mặc định hai nhóm được phép xếp lên nhau. `FULL_BASE_SUPPORT` chỉ
được sử dụng khi profile được duyệt và case đã có bằng chứng mở tính năng nhiều
tầng. Cấu hình mặc định khi chưa có bằng chứng đó là một tầng.

Không có số đo, chiều dày kê hoặc hạn mức thực nào được điền sẵn bằng mẫu giả lập.
TRAPEZOID, hầm mục tiêu đã có hàng và các cấu hình tiếp xúc khác cần mở rộng
contract riêng; không ép chúng vào BOX hoặc loại trừ ngầm bằng một ghi chú.

## 2 Nội dung bất biến và tham chiếu

Mọi entity content có các trường chung:

| Trường | Nghĩa |
|---|---|
| schemaVersion | Hằng `0.2` |
| id | ID ASCII ổn định, không dùng tên hiển thị làm khóa |
| version | Số nguyên dương; version mới khi nội dung thay đổi |
| testOnly | Dữ liệu chỉ phục vụ test; true thì không dùng để chấp thuận vận hành |

Nội dung không chứa hash của chính nó. Envelope trong fixture hoặc kho snapshot
lưu `{kind, id, version, sha256, content}`. `kind/id/version` của envelope phải khớp
content và loại schema. Một ref có `{kind, id, version, sha256}`; mọi thành phần
đều phải khớp snapshot được tải, không chỉ ID. Không được có hai record cùng
kind/id/version nhưng nội dung khác.

`PlanContent` không chứa planStatus, approval hoặc solverStatus. Lịch sử trạng
thái và quyết định được ghi bằng entity riêng. Việc người dùng chọn một phương án
không sửa các vị trí hoặc làm thay đổi content hash của phương án đó.

`inputSnapshotSha256` bằng `loadingCaseRef.sha256`. Đây là hash của content case
đã pin các dependency bằng hash; đổi một dependency phải tạo case/version/hash
mới. Plan ghi `generation.runId` để truy vết, không ref hash ngược tới kết quả run.
Run có thể tham chiếu plan; validation receipt tham chiếu run và plan. Cách này
tránh vòng hash run → plan → run.

Với sửa tay, generation.method=MANUAL_EDIT và parentPlanRef là bắt buộc;
generation chỉ cần method và generatorVersion, không tạo seed/timeLimit/run giả.
Plan mới và validation receipt mới không sửa origin run. runRef của validation
hiện tại được bỏ trống cho MANUAL_EDIT; origin được truy qua parentPlanRef. Với
SOLVER/SYNTHETIC, runId/seed/timeLimitMs và validation.runRef vẫn bắt buộc ở tầng
nghiệp vụ. runRef cấp bundle cũng có thể bỏ trống khi active plan là sửa tay.

## 3 Chuẩn băm nội dung

Tên chuẩn nội bộ: `STOWAGE-JSON-0.2`. Đây là quy ước của package, không
tuyên bố là triển khai RFC 8785.

1. Chỉ nhận JSON object/array/string/integer/boolean/null. Không float, NaN hoặc
   Infinity. Integer phải nằm trong khoảng an toàn ±9.007.199.254.740.991;
   các trường khối lượng/kích thước có giới hạn nhỏ nhất riêng trong schema.
2. Tên khóa phải là ASCII; không nhận Unicode surrogate không ghép đôi. Giá trị
   chuỗi Unicode được giữ nguyên, không tự chuẩn hóa hoặc đổi xuống dòng.
3. Sắp xếp object keys tăng dần; giữ nguyên thứ tự array. Hai array cùng thành
   viên nhưng khác thứ tự không mặc nhiên có cùng hash.
4. Serialize tương đương Python `json.dumps(content, sort_keys=True,
   separators=(',', ':'), ensure_ascii=False, allow_nan=False)`.
5. Mã hóa UTF-8, không BOM, không thêm newline; SHA-256 của các byte đó viết bằng
   hex chữ thường.

Backend là nơi tính hash có thẩm quyền. Client không được tự cung cấp một hash rồi
được coi là đã xác minh. JSON Schema có thể coi một số giá trị dạng 1.0 là integer;
canonicalizer vẫn phải từ chối float để tránh khác biệt giữa các runtime.

Hash tài liệu gốc trong `documentSha256` là hash trực tiếp byte của file; không áp
chuẩn JSON lên ảnh/PDF/XLSX. Không trộn hash file gốc với hash snapshot JSON.

## 4 Hồ sơ tàu và chứng từ

`vessel_profile` lưu tên, đăng ký, vesselClass, operatingRegionIds, nguồn xác minh
danh tính và `certificateCargoLimitKg`. `grossTonnageGt` và `deadweightKg` là hai
trường tùy chọn riêng, không có trường ghép GT/full load/kg.

Mỗi certificate có documentId, documentSha256, documentType, validFrom,
validityKind, verification và evidence. SAFETY_INSPECTION bắt buộc DATED và có
validUntil. `VERIFIED_NON_EXPIRING` chỉ dành cho loại giấy phù hợp và cần nguồn
xác nhận; thiếu ngày không được tự diễn giải là không hết hạn.

Case có `operatingDate` là ngày bắt đầu và `validThroughDate` là ngày kết thúc của
khoảng hoạt động đã khai báo, tính cả hai đầu theo `timeZone`. validThroughDate
không được trước operatingDate. Chứng từ được dùng để xác nhận giới hạn phải phù
hợp toàn bộ khoảng đó. Nếu chứng từ/quy định yêu cầu điều kiện khác, người có
chuyên môn phải xác nhận; reference date check không thay việc xác minh phạm vi.

Các trường `confirmedBy`, `verification` hoặc `sourceAuthority` chỉ là hình thức
dữ liệu. Backend phải đối chiếu nguồn và authentication event thực; client/AI tự
gửi chuỗi “VERIFIED” không có quyền tạo một snapshot đã xác minh.

## 5 Hình học BOX và placement

Hầm khai báo lengthMm, widthMm, heightMm của vùng mô hình **trước** clearance;
`dimensionsBasis=DECLARED_BEFORE_CLEARANCE`. `measurementMethod` bắt buộc là
MEASURED, DRAWING hoặc ESTIMATED_CONFIRMED; measurementEvidence gắn đúng phương
pháp và nguồn số đo/ước tính đã được người có trách nhiệm xác nhận. Không ghi
nguồn bản vẽ thành số đo trực tiếp hoặc dùng AI tự đoán số. Gốc ở góc dưới của vùng mô hình,
x dọc chiều dài, y ngang, z hướng lên. `axis` ghi rõ liên hệ với tàu hoặc đánh dấu
DECLARED_LOCAL. Không suy luận hướng mũi/lái từ dấu của tọa độ.

Miền sau clearance là:

```text
x ∈ [xMinMm, lengthMm - xMaxMm]
y ∈ [yMinMm, widthMm  - yMaxMm]
z ∈ [0, heightMm - topMm]
```

Nếu clearance làm miền có chiều dài/rộng/cao không dương thì chặn. Không có
clearance đáy dùng chung; kê đáy được mô hình hóa bằng profile. Chỉ trừ clearance
một lần. excludedZones là các khối cấm có tọa độ trong hệ mô hình này, không phải
cách lách yêu cầu khai báo hầm rỗng.

Placement có cargoUnitId, xMm/yMm/zMm, yawDegrees, layer và supportedByIds. Tọa độ
là góc nhỏ nhất của khối bao **sau khi xoay**. Yaw 90/270 đổi chiều dài và rộng;
chiều cao giữ nguyên. Tất cả các đỉnh phải nằm trong miền, không chỉ tâm bó.

Hai khối được phép chạm mặt nếu khoảng hở yêu cầu tương ứng bằng 0; phần thể tích
giao nhau dương là overlap. `betweenCargoMm` là khoảng hở ngang tối thiểu của các
kiện có khoảng z giao nhau; không cộng nó như một khoảng hở dọc giữa hai tầng có
quan hệ đỡ. Hướng x hoặc y phải đủ tách footprint cho cặp cần kiểm khoảng hở.
excludedZones được coi là vùng đã bao gồm khoảng tránh cần thiết theo số đo được
xác nhận; validator không tự thêm cùng clearance lần hai quanh nó.

Viewer dùng cùng snapshot và chuyển hệ trục render có công thức rõ; mesh trang
trí không thay bounding envelope cho validator. Việc khối bao vừa hình học chưa
chứng minh mặt tiếp xúc hoặc khả năng đưa hàng vào vị trí đó.

## 6 Profile kê và chồng

`support_profile` có reviewState DRAFT/APPROVED/REVOKED, reviewEvidence, phạm vi
vesselClasses/regionIds, cargoType và allowedYawDegrees. Trước sử dụng phải có
profile APPROVED phù hợp và đúng hash. Khi profile thay đổi, không ghi đè version
cũ; tạo case mới pin version mới và kiểm lại.

Trong cùng một case chỉ dùng một version/hash cho một support profile ID;
compatibleUpperProfileIds được giải tới đúng version đã pin trong case.

Các tham số cấu hình:

| Trường | Nghĩa |
|---|---|
| stackingMode | SINGLE_LAYER hoặc FULL_BASE_SUPPORT |
| maxLayers | Tổng số lớp cargo cho cấu hình được duyệt; SINGLE_LAYER luôn 1 |
| baseDunnageHeightMm | Độ nâng mặt đỡ bó tầng 0 so với đáy mô hình |
| interlayerDunnageHeightMm | Khoảng kê dưới bó tầng trên, lấy từ profile của bó trên |
| maxSupportedMassKg | Hạn mức **cargo phía trên** mà bó/cấu hình đỡ được phép nhận |
| supportedMassBasis | NET_CARGO_ABOVE_AFTER_DUNNAGE_RESERVE |
| maxStackHeightMm | Giới hạn z đỉnh chồng tính từ đáy mô hình, theo cấu hình duyệt |
| compatibleUpperProfileIds | Những ID profile trên được phép kết hợp; version thực vẫn phải pin |
| requiresAntiRoll | Ghi nhận yêu cầu chống lăn phải được review ngoài toán học |

maxSupportedMassKg là allowance net đã được chuyên môn xác nhận sau ảnh hưởng kê
và bố trí đỡ; không dùng rating kết cấu thô thay vào đây. Case mass reserve về kê
là kiểm tổng tải toàn tàu, không thay việc xác nhận allowance truyền tải này.

Tầng 0 có layer=0, supportedByIds rỗng và z=baseDunnageHeightMm. Tầng trên chỉ được
dùng khi case.layeredStackingEnabled=true, có layeredStackingGateEvidence,
profile FULL_BASE_SUPPORT và cấu hình cụ thể được duyệt. Tọa độ z bằng đỉnh mặt
đỡ cùng cao cộng interlayerDunnageHeightMm của bó trên. Tập footprint đỡ phải phủ
đầy đủ footprint bó trên trong mô hình bảo thủ; graph đỡ không có vòng, self-ref,
ID không tồn tại hoặc cạnh ngược tầng.

Tổng khối lượng **distinct descendant cargo** đặt lên một support không vượt
maxSupportedMassKg. Không đếm trùng cùng descendant theo hai nhánh. Đây là kiểm
bảo thủ hình học/số học trên cấu hình được duyệt. Nó không tính ứng suất thực,
độ bền bó ống, ma sát, nén gỗ hoặc tiếp xúc cục bộ; các phần đó thuộc review chuyên
môn và phải có coverage riêng.

## 7 Manifest và lựa chọn hàng

Mỗi cargo unit là một bó nguyên vẹn, có id riêng, sourceLineId, loại, kích thước
bao, massKg, massBasis và supportProfileRef. Một ID chỉ xuất hiện một lần trong
manifest. declaredTotalMassKg phải bằng tổng massKg của toàn bộ unit. Nhóm
`ALL_OR_NONE` chỉ cho phép xếp toàn bộ hoặc không xếp unit nào trong nhóm.

V0.2 nhận massKg nguyên, chính xác theo nguồn đã xác nhận. Nguồn có kg lẻ hoặc chỉ
có tổng lô mà thiếu trọng lượng từng bó phải lưu vào IntakeDraft để xử lý. Không
truncate, làm tròn xuống hoặc chia đều tổng lô thành số đo của từng bó. Mở rộng
sang gram/decimal cần đổi contract và các kiểm thử liên quan.

Case phân hoạch toàn manifest thành requiredUnitIds, optionalUnitIds và
excludedUnitIds; ba tập rời nhau và hợp đúng toàn bộ cargo IDs. Trong ALL_REQUIRED,
optionalUnitIds rỗng; các unit không loại khỏi bài toán đều bắt buộc. Trong
MAXIMIZE_OPTIONAL, vẫn phải xếp đủ required units mới đạt yêu cầu lựa chọn.

Mục tiêu v0.2 cố định theo mode: ALL_REQUIRED tìm một nghiệm xếp đủ tập bắt buộc;
MAXIMIZE_OPTIONAL tối đa tổng massKg của optional units được đặt sau khi thỏa toàn
bộ required units và hard constraints. Không có custom priority/weight ở v0.2.
Quy tắc phá hòa phải gắn với solverBuild nếu có tuyên bố tái lập kết quả; thay mục
tiêu tùy chỉnh cần version contract mới. Không cần thêm một field objective không
có trong schema vì mục tiêu được suy duy nhất từ mode và phiên bản đặc tả v0.2.

Plan phân hoạch lại thành placements, unplaced và excludedUnitIds. Các tập phải
rời nhau, phủ đúng manifest và không có ID lạ. Excluded phải khớp lựa chọn case;
unplaced là hàng được yêu cầu xét nhưng chưa xếp, mỗi unit có reasonCode và reason.
Hàng required bị unplaced không làm biến mất draft; nó chặn điều kiện chọn plan.

## 8 Cân đối tải chuyến

Phương trình duy nhất của v0.2:

```text
existingCargoKg + sum(massKg của các unit thực đặt) + plannedDunnageMassKg
    <= voyageCargoLimitKg
    <= vessel.certificateCargoLimitKg
```

`allowanceBasis=CARGO_PLUS_PLANNED_DUNNAGE`. voyageCargoLimitKg là tổng budget đã
được người có trách nhiệm xác nhận sau các tải/điều kiện non-cargo của chuyến,
nhưng **chưa trừ** dự phòng kê mới. existingCargoKg gồm hàng hiện hữu và phần kê
liên quan đã có từ trước nằm ngoài hầm mục tiêu trong cùng budget; không cộng lại
vào plannedDunnageMassKg. Việc dùng budget bảo thủ này không tuyên bố mọi vật kê
được phân loại pháp lý là cargo trong mọi hồ sơ tàu.

plannedDunnageMassKg là khoản dự phòng cho cấu hình xếp đang xét. Giữ nguyên khoản
này nếu plan chỉ xếp một phần; muốn giảm phải có case version mới và nguồn xác
nhận. Nguồn đầu vào đã trừ kê phải được chuẩn hóa minh bạch trước confirm, không
âm thầm trừ thêm một lần hoặc tự cộng tăng hạn mức. Không có epsilon vượt tải.

## 9 Run và bằng chứng kết quả

OptimizationRun lưu loadingCaseRef, mode, seed, timeLimitMs, solverBuild,
startedAt/finishedAt, planRefs, proofEvidenceRefs và status có bốn trục riêng:

| Trục | Giá trị |
|---|---|
| termination | COMPLETED, TIME_LIMIT, ERROR, CANCELLED |
| candidate | NONE, UNVALIDATED, VALIDATED |
| fulfillment | ALL_REQUIRED_PLACED, REQUIRED_MISSING, NO_CANDIDATE |
| proof | NOT_PROVEN, PROVEN_OPTIMAL, PROVEN_INFEASIBLE |

NONE không có plan candidate; UNVALIDATED là candidate chưa đạt đầy đủ điều kiện
validation; VALIDATED cần receipt phù hợp đủ hard checks. Mọi claim proof phải có
bằng chứng solver cho đúng mô hình và tập yêu cầu. PROVEN_INFEASIBLE không được
đi cùng một candidate đáp ứng chính tập yêu cầu được chứng minh bất khả thi. Nếu
muốn trả candidate phần hàng tùy chọn sau khi bài toán ALL_REQUIRED bất khả thi,
phải là run/case mode mới, không gộp hai kết luận trái nhau vào cùng run.

TIME_LIMIT hoặc heuristic chưa tìm thấy không tự thành PROVEN_INFEASIBLE. Có
candidate hợp lệ không tự chứng minh optimal. Đầu vào, mode, seed hoặc cấu hình
run phải khớp generation được ghi trong plan; không gắn kết quả cũ vào case mới.

## 10 Rules coverage và receipts

RuleSetVersion pin reviewState/evidence, scope, effectiveFrom/effectiveTo và từng
rule. Core bắt buộc S-001 đến S-008 và S-013 không được vô hiệu hóa bằng preference
hoặc xóa khỏi registry. S-009–S-011 phải xuất hiện trong coverage để cho biết phần
engineering còn thiếu. S-012 không hoạt động ở cấu hình ban đầu cho đến khi có
nguồn và profile phù hợp được duyệt.

Mỗi enabled rule áp dụng phải có đúng một outcome; rule bỏ sót, trùng hoặc đổi
version đều không được hiểu là PASS. NOT_APPLICABLE cần căn cứ phạm vi xác minh,
không dùng cho dữ liệu thiếu. HARD/HARD_GATE/GOVERNANCE thuộc quyền thao tác cần
đạt trước lựa chọn; FAIL, NEEDS_REVIEW hoặc NOT_EVALUATED chặn cấp điều kiện chọn.
Các engineering checks thiếu dữ liệu có thể giữ phương án sơ bộ, nhưng vẫn phải
hiện ra trong viewer và report. Một giới hạn bắt buộc đã biết bị vi phạm luôn
chặn, dù trước đó nhóm rule được xử lý bằng review ngoài tool.

ValidationReceipt pin đúng plan, case, input hash, rule set và run; ghi build,
thời gian, ruleEvaluations, observedPlacedMassKg và hardChecksPassed. Không tin
một receipt do client gửi tự khai PASS. Server phải tạo hoặc kiểm chứng receipt
với các log/check thực. testOnly=true luôn assurance=TEST_ONLY; kết quả này không
đủ để lựa chọn hoặc field handoff vận hành.

DecisionReceipt khác ValidationReceipt. USER_SELECTION ghi lựa chọn của operator;
FIELD_REVIEW ghi nhận rà soát theo phạm vi chuyên môn; REVOCATION ghi thu hồi.
actorId/actorRole/authenticationEventId do server xác định từ phiên và registry
được phép, không do caller tự cấp. evidenceRefs phải được server giải đến bằng
chứng bất biến đã kiểm hash; một đường dẫn hoặc URL không tự có thẩm quyền.

FIELD_REVIEW phải có role ENGINEERING_REVIEWER từ registry. Chức danh SUPERVISOR
không tự cho phép rà soát kỹ thuật; nếu người đó có năng lực và được đơn vị giao
trách nhiệm, registry phải cấp role ENGINEERING_REVIEWER rõ ràng.

`coveredRuleIds` của USER_SELECTION là mảng rỗng vì lựa chọn không phải kết luận
engineering. FIELD_REVIEW có kết luận ACCEPTED_WITH_CONDITIONS phải phủ toàn bộ
engineering checks áp dụng còn cần external review, tính từ rule snapshot ở
backend. Không hard-code bỏ qua một rule chỉ vì client không gửi tên nó. Review
REJECTED có thể ghi phạm vi chưa đầy đủ; nó không tạo điều kiện bàn giao đạt.

LifecycleEvent chỉ ghi lại PLAN_CREATED, USER_SELECTED, FIELD_HANDOFF_RECORDED,
MARKED_STALE hoặc REVOKED cho đúng planRef. Các event cần quyết định phải pin
receiptRef đúng loại, scope và target. CVF ALLOW không tạo một receipt lựa chọn
hoặc review hiện trường.

Sự tồn tại của snapshot mới không xóa lịch sử. Khi ngày/đầu vào/rule/profile/điều
kiện hiệu lực thay đổi ảnh hưởng plan, giữ nội dung cũ để tra cứu nhưng yêu cầu
validation và quyết định mới. Sau restore phải tái kiểm khả dụng hiện tại;
không coi credentials/sessions cũ là dữ liệu nghiệp vụ để phục hồi quyền.

## 11 Intake và provenance

IntakeDraft riêng chứa field path, rawText, sourceUnit, normalizedValue nếu có,
status, candidates và sourceLocator; issues được gắn vào đúng field. Cho phép
thiếu dữ liệu và xung đột; không điền 0 hoặc VERIFIED để qua schema. Chỉ confirm
qua backend mới tạo immutable snapshot có đủ trường.

Timestamp dùng dạng có `T`, giây và múi giờ rõ (`Z` hoặc offset như `+07:00`).
Schema có pattern hình thức; validator phải kiểm ngày/giờ lịch hợp lệ và timezone.
Không giả định việc khởi tạo FormatChecker là đã có đủ mọi checker tùy chọn.

Evidence nguồn DOCUMENT có documentSha256; MANUAL_ENTRY không bắt buộc tạo file
hash giả nhưng cần người xác nhận, thời gian, nội dung và nguồn/ghi chú phù hợp.
SYNTHETIC chỉ dùng trong fixture. Định dạng và chuỗi actor không thay xác minh
thẩm quyền; đây là trách nhiệm runtime riêng.

## 12 Cách dùng fixture

`valid_bundle.json` nghĩa là bundle có cấu trúc và số học mẫu hợp lệ, không phải
phương án đã được duyệt. Nó gồm hash thật của 12 content records và một tệp nguồn
giả lập; tất cả testOnly=true. Ví dụ validation giữ S-008/S-013 runtime và
S-009–S-011 engineering ở NOT_EVALUATED, hardChecksPassed=false, quyết định chọn
REJECTED. Run có candidate UNVALIDATED. Các nhãn APPROVED/VERIFIED trong profile
giả chỉ thử hình thức schema, không xác nhận kỹ thuật thực.

Khi chuyển sang dữ liệu thật, cần nhập nguồn thật, xác minh quyền/source và tạo
các version mới qua quy trình backend. Không sửa testOnly=false trên fixture để
biến nó thành hồ sơ vận hành.

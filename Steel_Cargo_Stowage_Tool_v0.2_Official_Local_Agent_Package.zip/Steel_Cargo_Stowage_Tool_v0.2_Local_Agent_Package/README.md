# Steel Cargo Stowage Tool v0.2

## Package chính thức làm việc với Agent local

Ngày phát hành: **31-10-2026**. Mã package: **SCST-LOCAL-0.2**.

- Trạng thái tài liệu bàn giao: `OFFICIAL_LOCAL_AGENT_HANDOFF`.
- Mục đích: xác minh tại local, triển khai theo contract và nộp bằng chứng nghiệm thu.
- Phạm vi sản phẩm: lập phương án sơ bộ xếp bó thép trong hầm tàu/sà lan, dùng local, AI tùy chọn.
- Trạng thái ứng dụng: **chưa có ứng dụng hoàn chỉnh hoặc solver sản xuất trong package**.
- Trạng thái xác nhận kỹ thuật/hiện trường: **chưa được cấp bởi package này**.

Đây là bộ yêu cầu làm việc v0.2 đã hợp nhất baseline v0.1 và phản biện R1. Agent local dùng các tài liệu đang hiệu lực trong package này làm đầu vào chính; phần `history/` chỉ phục vụ truy vết. Không cần tải hoặc đọc lại cuộc trò chuyện để hiểu nhiệm vụ.

## Bắt đầu

1. Đọc `START_HERE_LOCAL_AGENT.md`.
2. Đọc `MASTER_SPEC_V0.2.md` và các tài liệu `docs/` theo mục lục trong đó.
3. Kiểm `FILE_CHECKSUMS.sha256` bằng `tooling/verify_package.py`.
4. Chạy bộ kiểm contract theo `reference/README.md` và lệnh thực tế trong `evidence/PACKAGE_VALIDATION_REPORT.md`.
5. Đối chiếu repo CVF, dữ liệu thực, điều kiện máy local; nộp báo cáo đầu tiên theo template.

## Cách đọc mức bằng chứng

| Nhãn | Ý nghĩa |
|---|---|
| `SPECIFIED` | Quy định đã viết rõ trong package |
| `CONTRACT_TESTED` | Script tham chiếu đã kiểm cấu trúc và một số bất biến trên dữ liệu giả lập |
| `IMPLEMENTED` | Agent local đã có code ứng dụng; chưa tự đồng nghĩa đúng |
| `RUNTIME_TESTED` | Có test/log của ứng dụng chạy thực tại local |
| `FIELD_REVIEWED` | Có người có trách nhiệm đối chiếu điều kiện thực tế |

Kết quả contract test không tự làm G0–G5 đạt. Kiểm tra tham chiếu luôn trả `operationalEligible=false`; không dùng nó làm giấy phép sử dụng phương án.

## Tổ chức tệp

| Vị trí | Vai trò |
|---|---|
| `MASTER_SPEC_V0.2.md` | Mục tiêu, ranh giới và yêu cầu sản phẩm chính thức |
| `docs/01_SCOPE_AND_DECISIONS.md` | Quyết định thiết kế v0.2 và phần cần dữ liệu/chuyên môn |
| `docs/02_DATA_GEOMETRY_STATE.md` | Dữ liệu, khối lượng, hình học, hash và điều kiện trạng thái |
| `docs/03_ACCEPTANCE_AND_EVIDENCE.md` | Gates và bằng chứng nghiệm thu |
| `docs/04_CVF_AND_LOCAL_AUTH.md` | Quyền local và ranh giới CVF |
| `docs/05_R1_DISPOSITION.md` | Cách xử lý 14 nhận định phản biện |
| `docs/06_UX_API_STORAGE.md` | Luồng người dùng, API, lưu trữ và phục hồi |
| `docs/07_SOURCES_AND_APPLICABILITY.md` | Nguồn, phạm vi sử dụng và việc phải xác minh |
| `contracts/` | Schema, mô hình trao đổi dữ liệu và quy tắc hash |
| `reference/`, `tests/` | Kiểm tra contract, fixtures giả lập và ca thử |
| `templates/` | Mẫu kết quả Agent local phải trả |
| `evidence/` | Kết quả đã chạy khi đóng gói và giới hạn bằng chứng |
| `history/` | Baseline v0.1, phản biện R1; không phải yêu cầu đang hiệu lực |

## Quy tắc xử lý mâu thuẫn

Tài liệu v0.2 và schema v0.2 phải được đọc cùng nhau: prose quy định ý nghĩa và hành vi; schema quy định cấu trúc máy. Khi chúng mâu thuẫn, Agent local ghi discrepancy và đề xuất sửa đồng bộ; không chọn bản dễ thực hiện hơn để bỏ điều kiện bắt buộc. `history/` không được dùng để đảo ngược quyết định đã ghi rõ tại v0.2. Reference code minh họa những kiểm tra đã triển khai trong gói, không có quyền làm suy yếu yêu cầu của spec.

Không nhúng chứng từ, dữ liệu khách hàng hoặc khóa API vào repo. Mọi thông số synthetic chỉ dùng cho test. Người vận hành cung cấp nguồn thật qua quy trình intake tại local.

# Bằng chứng kiểm tra khi đóng gói v0.2

## Kết luận và phạm vi

Snapshot contract của package `SCST-LOCAL-0.2` đã chạy **86 tests: 86 đạt, 0 failures, 0 errors, 0 skipped**. Đây là kiểm tra mã tham chiếu trên dữ liệu tổng hợp. `operationalEligible=false`; không có gate triển khai hoặc hiện trường nào được cấp PASS từ kết quả này.

Báo cáo này mô tả bằng chứng có thật trong `contract_check_receipt.json` và `contract_checks.log` cùng thư mục. Receipt gốc được giữ nguyên, gồm từng test, runtime, command và hash các đầu vào. Đường dẫn tuyệt đối trong receipt là đường dẫn tại môi trường thực sự đã chạy; không phải đường dẫn bắt buộc trên máy nhận package.

## Môi trường và lần chạy đã quan sát

| Thuộc tính | Giá trị thực |
|---|---|
| Thời điểm receipt | 2026-10-31T06:06:46.627641+00:00 |
| Python | 3.12.14 |
| jsonschema | 4.26.0 |
| Platform | Linux-6.18.57-x86_64-with-glibc2.39 |
| Số tests | 86 |
| Failures / errors / skipped | 0 / 0 / 0 |
| Thời gian suite trong log | 1.238 giây; chỉ là quan sát trên fixture nhỏ |
| Đầu vào được receipt băm | 36 tệp mã/schema/fixture/tài liệu tham chiếu |

Lệnh thực tế ghi trong receipt:

```text
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 /workspace/scratch/76105b566a46/package_v02/Steel_Cargo_Stowage_Tool_v0.2_Local_Agent_Package/tests/run_all.py --output /workspace/scratch/76105b566a46/v02_contract_evidence
```

Dependency kiểm schema trong môi trường trên nằm ở `/workspace/scratch/76105b566a46/audit_contracts/deps` và được đưa vào `PYTHONPATH`. Dependency không được nhúng vào ZIP. Môi trường local có thể cài theo `requirements.txt` trong virtual environment riêng.

## Cách chạy lại trên máy nhận

Tại thư mục gốc package, sau khi giải nén:

```text
python tooling/verify_package.py
python -m venv .venv
```

Chọn interpreter của virtual environment: Windows thường là `.venv\Scripts\python.exe`; Linux/macOS thường là `.venv/bin/python`. Dùng interpreter đó thay `python` trong hai lệnh sau:

```text
python -m pip install -r requirements.txt
python tests/run_all.py --output ../contract-evidence-local
```

Thư mục `--output` phải nằm ngoài package. Runner chỉ đọc input, không sửa schema/fixtures và không tạo bytecode cache trong package. Bộ kiểm hash không cần dependency jsonschema. Ghi kết quả local mới vào evidence riêng; không ghi đè evidence của bản phát hành.

## Những gì đã được kiểm trong suite

| Nhóm | Bằng chứng được cung cấp |
|---|---|
| Schema và fixtures | 14 schema Draft 2020-12 hợp cấu trúc; 12 entity fixtures và bundle hợp cấu trúc; tham chiếu schema được resolve từ package |
| Serialization và identity | 7 vectors, hash nội dung, ref/envelope/payload khớp, phiên bản và kind, 12 record trong bundle dùng hash đúng, nguồn fixture có file/hash đối chiếu |
| Intake và dữ liệu | Phân biệt nháp, trường thiếu/xung đột, nguyên kiện, ID, đơn vị và phân hoạch placed/unplaced/excluded |
| Khối lượng và ngày | Tổng cargo, hạn mức chứng nhận/chuyến, reserve kê mới, ngày biên bao gồm cả hai đầu và timestamp hợp lệ có timezone |
| Hình học | BOX, margins, excluded zones, yaw, overlap, khoảng cách, độ cao kê và support DAG |
| Profile và chồng | Profile phù hợp; SINGLE_LAYER không làm tầng đỡ cho cargo phía trên; giới hạn tầng/chiều cao của profile dưới áp dụng cho descendants; khối lượng phía trên được tính bảo thủ |
| Rule và trạng thái | Coverage đủ, mandatory rules, unknown/fail, proof không suy ra từ timeout, required fulfillment |
| Sửa tay và receipt | Parent cùng case, plan/validation mới, không gắn nhầm run gốc, role/coverage của field-review record |

Danh sách đầy đủ test function và verdict nằm trong receipt, expected/actual chi tiết đọc từ test source và log. PASS của negative test nghĩa là trường hợp sai đã bị từ chối đúng trong harness.

Fixture có các trường mô tả trạng thái như APPROVED/VERIFIED để kiểm quan hệ dữ liệu, nhưng mọi record đều `testOnly=true`. Run giữ `candidate=UNVALIDATED`, receipt giữ `hardChecksPassed=false`; S-008/S-013 và các kiểm tra kỹ thuật S-009–S-011 vẫn `NOT_EVALUATED`. Các chuỗi actor/approval trong fixture không phải danh tính hoặc quyết định thật.

## Những gì chưa được kiểm bởi package

- Backend thực: authentication, authorization, CSRF, transaction, race/stale, audit, backup/restore và migrations.
- Solver production: packing correctness, optimality, hiệu năng trên manifest/máy mục tiêu và khả năng thao tác thực.
- CVF: checkout nguồn, license, exports, dependencies, chạy bridge và các nhánh runtime.
- Dữ liệu tàu, manifest, giấy hiện hành, nguồn áp dụng và profile kê/chồng thật.
- Tải tiếp xúc, tải cục bộ, sức bền, ổn định, chằng buộc, đường cẩu và trình tự xếp.
- UI/E2E, import/export PDF/XLSX thực và đối chiếu chuyến hiện trường.

Các mục trên có yêu cầu nghiệm thu tại `docs/03_ACCEPTANCE_AND_EVIDENCE.md`. **25 mã LAT là kịch bản nghiệm thu tương lai, không cộng vào 86 tests đã chạy.** G0 cần owner/chuyên môn đối chiếu phạm vi với nhu cầu thật; G1/G2/G3/G4a/G4b/G5 cần các bằng chứng tương ứng. Package không ghi tên người quyết định hoặc gate PASS giả.

## Tính toàn vẹn bản phát hành

Đã đóng một ZIP kiểm phát hành, giải nén sang thư mục độc lập và chạy lại tại thư mục đó. `tooling/verify_package.py` xác nhận toàn bộ 63 tệp được liệt kê của snapshot lúc đó. Bộ contract sau giải nén tiếp tục **86/86 đạt**, không failure/error/skipped, trong 1.151 giây; receipt lúc `2026-10-31T06:11:49.123602+00:00`. Toàn bộ 36 hash đầu vào của hai lần chạy trùng nhau.

Receipt và log của lần chạy sau giải nén nằm tại `portability_contract_check_receipt.json` và `portability_contract_checks.log`. Bản phát hành cuối bổ sung hai tệp evidence này cùng phần mô tả kiểm tra; không thay mã kiểm, schema hoặc fixtures đã được chạy. Lần chạy trên bản giải nén dùng cùng Python/dependency của môi trường kiểm tra, chưa phải thử trên máy Windows/macOS hoặc môi trường sạch của người dùng.

`FILE_CHECKSUMS.sha256` băm các tệp phát hành ngoại trừ chính tệp checksum để tránh vòng tự tham chiếu. `PACKAGE_MANIFEST.json` ghi thành phần, trạng thái bàn giao và nguồn lịch sử. `tooling/verify_package.py` kiểm mọi tệp được liệt kê và báo số khớp; checksum không phải chữ ký số của tác giả hoặc chứng cứ dữ liệu đúng thực tế.

Khi local sửa code/spec hoặc sinh evidence mới, lưu trên nhánh/bản làm việc riêng và ghi diff so với snapshot đầu vào. Không sửa file checksum của release rồi trình nó như bằng chứng bản gốc vẫn nguyên vẹn.

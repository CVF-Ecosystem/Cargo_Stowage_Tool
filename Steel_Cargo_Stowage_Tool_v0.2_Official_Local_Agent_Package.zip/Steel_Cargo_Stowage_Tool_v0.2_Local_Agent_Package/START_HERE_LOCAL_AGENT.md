# Work order chính thức cho Agent local

## Nhiệm vụ

Dùng package SCST-LOCAL-0.2 để xác minh thiết kế tại môi trường local, dựng ứng dụng theo từng gate và nộp bằng chứng thật. Chủ công cụ đã yêu cầu hoàn thiện package này làm cơ sở làm việc. Việc có package chính thức không thay cho xác minh dữ liệu tàu, profile kỹ thuật, quyền người dùng hoặc nghiệm thu hiện trường.

## Việc thực hiện ngay

1. Kiểm checksum và đọc README, MASTER_SPEC, docs, contracts, tests. Không dùng lịch sử v0.1 như đặc tả đang hiệu lực.
2. Khảo sát workspace/repo local có sẵn, quy định trong AGENTS.md, OS, Python/Node và công cụ build. Không ghi đè dữ liệu hoặc repo đang có. Nếu cần, tạo nhánh/worktree riêng theo quy tắc môi trường.
3. Chạy bộ kiểm contract. Ghi đúng command, runtime, result và giới hạn. Các thông số TEST_ONLY không được đưa vào production.
4. Đọc repo CVF tại commit `ebf31b9f5c42e4de58f40a434409c3441a5d8383` nếu có. Nếu khác commit, ghi khác biệt. Kiểm license, exports, dependencies và mandatory guards trước khi làm bridge; không sửa CVF core.
5. Trả báo cáo ban đầu: phần phù hợp, discrepancy, dữ liệu còn thiếu, rủi ro triển khai và kế hoạch commit theo gate. Chỉ hỏi owner những câu hỏi ảnh hưởng phạm vi hoặc thông số nghiệp vụ; tiếp tục các việc độc lập đã làm được.

## Được chủ động triển khai

- Code skeleton monorepo, frontend/backend boundaries, database migration, DTO intake và snapshots.
- Import/normalization, validator xác định và test; giao diện dữ liệu, 2D/3D projection trên synthetic fixtures.
- Solver spike có time budget và status đúng mức bằng chứng.
- Backup/restore harness; UI/E2E và các test quyền hạn.
- Adapter CVF độc lập sau khi kiểm tính tương thích; AI có thể để tắt trong core đầu tiên.

Các việc này không phải đợi một nghiệm thu runtime đã hoàn tất. Tuy nhiên, chỉ báo gate PASS khi có đủ bằng chứng và đúng người chấp nhận gate theo docs/03.

## Không được tự quyết thay dữ liệu thực

- Không tự gán cargo capacity từ GT, DWT hoặc con số được thuật lại trong tài liệu lịch sử.
- Không tự đặt kích thước hầm, margin, số tầng, tải đỡ, khoảng kê, điều kiện chồng hay hạn mức chuyến.
- Không đổi HARD thiếu dữ liệu thành cảnh báo cho phép chọn plan.
- Không dùng TEST_ONLY hoặc trường `confirmedBy` do client gửi làm chứng cứ người thật xác nhận.
- Không coi giao diện 3D hoặc CVF ALLOW là chứng minh ổn định/sức bền/chằng buộc.
- Không tự mở hình thang, hầm đã có hàng, mixed stacking, cloud/multiuser hoặc phạm vi hàng mới ngoài điều kiện mở rộng.

## Trình tự triển khai

| Bước | Kết quả cần đạt |
|---|---|
| A Khảo sát và đối chứng | LOCAL_DESIGN_REVIEW, ENVIRONMENT_REPORT, OPEN_DECISIONS |
| B Nền dữ liệu | Intake nháp, confirm có quyền, immutable records, refs/hashes, migration, backup |
| C Validator | Đối soát units/mass, BOX/margins/exclusions, support profile, coverage và state policy |
| D Solver | Run mode, required/optional/excluded, nghiệm có thể kiểm độc lập, timeout/cancel |
| E UI và core | Sửa tay qua backend, 2D fallback, phiên bản, chọn plan, export và receipt |
| F AI và CVF tùy chọn | Read, denied mutation, allowed bounded revision, lỗi bridge và replay |
| G Đối chiếu thực tế | Dữ liệu và chuyến mẫu được phép dùng, review chuyên môn, giới hạn vận hành |

## Kết quả trả sau mỗi vòng

1. `LOCAL_DESIGN_REVIEW.md`: issue ID, file/code evidence, disposition, patch đề xuất và test liên quan.
2. `GATE_STATUS.md`: G0/G1/G2/G3/G4a/G4b/G5, owner thật, trạng thái và evidence. G4b có thể NOT_IN_SCOPE khi AI actions bị vô hiệu hóa.
3. `RUNTIME_EVIDENCE/`: exact commands, source SHA, environment/dependencies, input/rules SHA, expected/actual, logs và timestamp.
4. `OPEN_DECISIONS.md`: dữ liệu cần owner/chuyên môn; hành động nào bị chặn và phần nào vẫn tiếp tục.
5. `CVF_COMPATIBILITY_REPORT.md`: kiểm repo thực và wire contract adapter; chưa kiểm phải ghi NOT_RUN.
6. `TREEVIEW_AS_BUILT.md`: cấu trúc thực đã tạo, không sao chép cây dự kiến làm kết quả.

Dùng `templates/LOCAL_AGENT_REPORT.md` để giữ một mẫu báo cáo nhất quán. Screenshots hỗ trợ UI nhưng không thay output có thể kiểm lại của validator/solver.

## Đóng nhận định phản biện

14 nhận định R1 đã được xử lý ở mức thiết kế trong docs/05. Agent local kiểm lại từng cách xử lý; có thể bác bỏ hoặc đề nghị sửa bằng evidence cụ thể. Kết quả CONTRACT_TESTED trong package không tự đóng phần xác thực actor, CVF runtime, hiệu lực pháp lý hoặc profile kỹ thuật thật.

## Lệnh kiểm tra package

Tại thư mục gốc sau khi giải nén:

```text
python tooling/verify_package.py
python -m venv .venv
```

Chọn Python trong virtual environment theo OS, cài `requirements.txt`, rồi chạy lệnh trong `reference/README.md`. Không yêu cầu quyền admin để cài toàn hệ thống. Nếu môi trường không có quyền tải dependency, báo blocker môi trường; không bỏ test rồi ghi PASS.

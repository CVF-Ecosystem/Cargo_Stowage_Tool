# Mẫu báo cáo Agent local

Đây là mẫu chưa điền, không phải bằng chứng đã thực hiện. Copy các mục tương ứng sang bộ báo cáo thực; thay `CHƯA_CÓ` bằng dữ liệu quan sát được. Không dùng placeholder làm hash, actor, source SHA hoặc kết quả PASS.

## 1 Nhận diện lần làm việc

| Trường | Giá trị cần điền |
|---|---|
| Package đầu vào và checksum | CHƯA_CÓ |
| Phiên bản đặc tả | 0.2, cần đối chiếu package thực |
| Source repo/branch/commit của ứng dụng | CHƯA_CÓ |
| Repo CVF và commit thực | CHƯA_CÓ |
| Máy/OS/runtime/dependencies | CHƯA_CÓ |
| Thời điểm bắt đầu/kết thúc có timezone | CHƯA_CÓ |
| Người triển khai và reviewer được giao | CHƯA_CÓ |
| Phạm vi của lần làm việc | CHƯA_CÓ |

## 2 LOCAL_DESIGN_REVIEW

### Kết luận thực tế

Trạng thái ban đầu: `NOT_STARTED`. Viết rõ phần nào đã đọc, đã sửa, đã chạy, phần nào chưa có đủ dữ liệu. Nêu quyết định cần owner/chuyên môn; không chỉ ghi “đã kiểm tra”.

| R1 | Disposition triển khai | File/commit thay đổi | Test và evidence | Còn phụ thuộc ai/điều kiện nào |
|---|---|---|---|---|
| R01 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R02 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R03 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R04 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R05 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R06 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R07 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R08 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R09 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R10 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R11 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R12 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R13 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |
| R14 | NOT_STARTED | CHƯA_CÓ | NOT_RUN | CHƯA_CÓ |

Disposition triển khai dùng `IMPLEMENTED_AND_TESTED`, `IMPLEMENTED_NOT_TESTED`, `BLOCKED_BY_INPUT`, `CHANGE_PROPOSED`, `NOT_STARTED`. Khi đề xuất khác contract, nêu bằng chứng và tác động trước khi ghi phiên bản thay đổi.

## 3 GATE_STATUS

| Gate | Trạng thái | Phạm vi | Evidence refs | Người quyết định và ngày |
|---|---|---|---|---|
| G0 | NOT_STARTED | CHƯA_CÓ | CHƯA_CÓ | CHƯA_CÓ |
| G1 | NOT_STARTED | CHƯA_CÓ | CHƯA_CÓ | CHƯA_CÓ |
| G2 | NOT_STARTED | CHƯA_CÓ | CHƯA_CÓ | CHƯA_CÓ |
| G3 | NOT_STARTED | CHƯA_CÓ | CHƯA_CÓ | CHƯA_CÓ |
| G4a | NOT_STARTED | Core UI/API/quyền người dùng | CHƯA_CÓ | CHƯA_CÓ |
| G4b | NOT_STARTED | Chưa xác nhận AI actions có bật hay không | CHƯA_CÓ | CHƯA_CÓ |
| G5 | NOT_STARTED | CHƯA_CÓ | CHƯA_CÓ | CHƯA_CÓ |

Nếu bản core không bật AI actions, G4b có thể ghi NOT_IN_SCOPE sau khi dẫn cấu hình và test chứng minh capability bị tắt. Không tự mặc định trạng thái này trước khi kiểm checkout thực.

## 4 RUNTIME_EVIDENCE

Lặp bảng sau cho từng test hoặc nhóm test có cùng input/scope; đính kèm log gốc.

| Trường | Giá trị |
|---|---|
| Test ID và LAT/R1 liên quan | CHƯA_CÓ |
| Loại bằng chứng | NOT_RUN; khi chạy chọn CONTRACT_REFERENCE_ONLY hoặc runtime/field scope cụ thể |
| Source commit | CHƯA_CÓ |
| Exact command và working directory | CHƯA_CÓ |
| Runtime/dependency versions | CHƯA_CÓ |
| Timestamp có timezone | CHƯA_CÓ |
| Input fixture/source hash | CHƯA_CÓ |
| Case/plan/rule/profile snapshot hashes | CHƯA_CÓ |
| Expected và căn cứ oracle | CHƯA_CÓ |
| Actual | NOT_RUN |
| Verdict | NOT_RUN |
| Log/output refs | CHƯA_CÓ |
| Giới hạn kết luận | CHƯA_CÓ |

Không dùng ảnh UI làm bằng chứng duy nhất của thuật toán. Negative test cần chỉ rõ dữ liệu sai nào đã bị chặn và tại tầng nào. Contract reference checks đi kèm package có thể chạy lại làm mốc, nhưng phải phân biệt với production validator/API/solver đang xây.

## 5 CVF_COMPATIBILITY_REPORT

| Nội dung | Quan sát và evidence |
|---|---|
| Commit pinned được yêu cầu | ebf31b9f5c42e4de58f40a434409c3441a5d8383 |
| Commit checkout thực và diff | CHƯA_CÓ |
| Package/import/export surface | CHƯA_CÓ |
| License/dependencies/lockfile/runtime | CHƯA_CÓ |
| Mandatory guards và registration | CHƯA_CÓ |
| Mapping protocol adapter sang API canonical | CHƯA_CÓ |
| Transport, timeouts, request/receipt binding | CHƯA_CÓ |
| Read-only action đúng scope | NOT_RUN |
| Forbidden change_cargo_limit | NOT_RUN |
| Allowed bounded draft revision | NOT_RUN |
| BLOCK/ESCALATE/malformed/timeout | NOT_RUN |
| Sai actor/action/target/hash/nonce/expiry/replay | NOT_RUN |
| False ALLOW vẫn bị backend chặn | NOT_RUN |
| Core thủ công khi AI/CVF tắt | NOT_RUN |
| Kết luận tương thích | CHƯA_XÁC_MINH |

Không sửa CVF core để đạt test. Khi không tích hợp được, ghi vấn đề và đề xuất adapter hoặc giữ capability tắt; không tự bypass.

## 6 OPEN_DECISIONS

Chỉ thêm câu hỏi thực sự chặn một bước. Mỗi câu hỏi cần đủ ngữ cảnh để người trả lời biết quyết định ảnh hưởng gì.

| ID | Câu hỏi cần quyết định | Bằng chứng đã có | Lựa chọn và tác động | Người trả lời | Chặn gate nào | Trạng thái |
|---|---|---|---|---|---|---|
| CHƯA_CÓ | Chưa ghi nhận câu hỏi | CHƯA_CÓ | CHƯA_CÓ | CHƯA_CÓ | CHƯA_CÓ | NOT_STARTED |

Không hỏi lại những lựa chọn thiết kế đã được package chốt nếu không có bằng chứng mâu thuẫn hoặc nhu cầu thay phạm vi. Những số liệu kỹ thuật chưa có nguồn vẫn phải được người có trách nhiệm cung cấp, không tự dùng fixture.

## 7 TREEVIEW_AS_BUILT

Liệt kê đường dẫn có thật ở checkout hiện tại, vai trò và trạng thái. Phân biệt file đã tạo với kiến trúc dự kiến; không chép nguyên cây trong tài liệu rồi đổi tiêu đề.

| Đường dẫn thực | Vai trò | Đã hiện thực hay chỉ skeleton | Kiểm chứng |
|---|---|---|---|
| CHƯA_CÓ | CHƯA_CÓ | NOT_STARTED | NOT_RUN |

## 8 Đề nghị bước tiếp theo

Ghi việc có thể thực hiện ngay, dữ liệu còn thiếu, người cần quyết định và gate tiếp theo. Không dùng kết quả kiểm schema/reference để đề nghị triển khai hiện trường khi chưa có evidence runtime và review chuyên môn tương ứng.

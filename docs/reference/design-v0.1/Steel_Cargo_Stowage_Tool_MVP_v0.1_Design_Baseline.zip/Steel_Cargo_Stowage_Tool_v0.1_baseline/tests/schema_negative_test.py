"""Design schema rejection tests, NOT engine tests.
Run: python tests/schema_negative_test.py
"""
import copy,json
from pathlib import Path
from jsonschema import Draft202012Validator,FormatChecker
r=Path(__file__).resolve().parents[1]
def check(schema,fixture,mutator,label):
 sc=json.loads((r/'contracts/schemas'/f'{schema}.schema.json').read_text())
 ob=json.loads((r/'tests/fixtures'/f'{fixture}.json').read_text())
 mutator(ob)
 errors=list(Draft202012Validator(sc,format_checker=FormatChecker()).iter_errors(ob))
 assert errors,label
 print('REJECTED AS DESIGNED',label)
check('vessel_profile','vessel_profile',lambda x: x.update({'certificateCargoLimitKg':0}),'zero certificate limit')
check('vessel_profile','vessel_profile',lambda x: x['certificates'][0].update({'documentType':'REGISTRATION'}),'no safety inspection certificate')
check('manifest','manifest',lambda x: x['cargoUnits'][0].pop('massKg'),'missing cargo mass')
check('manifest','manifest',lambda x: x['cargoUnits'][0].update({'cargoType':'COIL'}),'unsupported coil cargo type')
check('hold_profile','hold_profile',lambda x:x.update({'geometryType':'TRAPEZOID'}),'missing trapezoid bottom width')
print('5 designed negative schema tests passed (no safety solver/run integration tested)')

# Synthetic fixtures (không dùng cho khai thác)

Các JSON trong thư mục này là dữ liệu **bịa đặt hoàn toàn** để thử định dạng, không phải phương tiện thực, giấy chứng nhận hợp lệ, số đo hầm thực, hoặc phương án đã được kiểm chứng.

Hash `aaaa...`, `bbbb...` là PLACEHOLDER và tuyệt đối không được chuyển sang sản phẩm khi xác thực provenance/hash. Schema validation chỉ kiểm tra hình thức, KHÔNG chứng minh kỹ thuật hoặc pháp lý.

"""DESIGN-ONLY schema validation and synthetic fixture checks.

This is NOT a solver, engineering certification, nor an operational acceptance test.
Run: python tests/schema_smoke_test.py
Requires: jsonschema
"""
import json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker

ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'contracts'/'schemas'
F=ROOT/'tests'/'fixtures'
count=0
for file in sorted(P.glob('*.schema.json')):
    schema=json.loads(file.read_text())
    Draft202012Validator.check_schema(schema)
    count+=1
    fixture=F/(file.name.removesuffix('.schema.json')+'.json')
    if fixture.exists():
        obj=json.loads(fixture.read_text())
        Draft202012Validator(schema,format_checker=FormatChecker()).validate(obj)
        print('SCHEMA+SYNTHETIC FIXTURE PASS',file.name)
    else:
        print('SCHEMA STRUCTURE PASS',file.name)
print(f'{count} schema definitions verified (format/domain/engineering tests NOT run)')

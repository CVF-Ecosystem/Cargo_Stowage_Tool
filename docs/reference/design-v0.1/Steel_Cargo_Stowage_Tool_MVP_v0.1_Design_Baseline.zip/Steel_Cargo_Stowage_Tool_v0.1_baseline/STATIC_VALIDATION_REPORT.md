# Static Validation Report — 2026-10-31

**Scope**: cấu trúc file JSON Schema và mẫu dữ liệu tổng hợp; **không** phải kiểm chứng an toàn hàng hải, CVF integration, packing solver hay UI.

## Commands executed

```bash
python tests/schema_smoke_test.py
python tests/schema_negative_test.py
```

## Observed results

- 6/6 JSON Schema definitions passed JSON Schema Draft 2020-12 structural validation.
- 5/5 available synthetic fixtures validated against the corresponding schemas.
- 5/5 designed invalid fixtures were rejected (cargo limit zero, absence of inspected certificate, cargo mass missing, unsupported coil cargo type, trapezoid without bottom width).

## Not executed / outstanding

- No real manifest import or image extraction test.
- No numerical cargo safety solver test, no support/stability/structural review.
- No frontend, backend, API, SQLite runtime or backup/restore test.
- No CVF guard bridge/runtime integration or real authorization test.
- No field pilot review. `G0...G5` remain pending, regardless of the static schema checks.

## Implementation warning

Cross-record validations (sum cargo unit mass, cargo cap match across verified vessel/case, date validity, unique cargo unit IDs, approvals and snapshot hash integrity) **cannot be delegated to these JSON Schemas alone**. Backend must enforce them with deterministic domain validation and negative tests.

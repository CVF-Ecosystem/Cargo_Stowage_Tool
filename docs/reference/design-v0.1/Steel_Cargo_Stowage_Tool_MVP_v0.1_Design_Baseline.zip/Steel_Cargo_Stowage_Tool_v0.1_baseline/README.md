# Steel Cargo Stowage Tool — Design Baseline v0.1

**Ngày:** 2026-10-31  
**Trạng thái:** `DRAFT_FOR_LOCAL_REVIEW` — đặc tả thiết kế, **chưa có bằng chứng runtime / nghiệm thu kỹ thuật**.  
**Phạm vi:** Tool local-first lập phương án bố trí bó thép trong hầm tàu/sà lan, có hình ảnh 3D, AI tùy chọn, người dùng quyết định và lớp quản trị CVF.

## Mục lục bắt buộc

1. `docs/01_SCOPE_CONTRACT.md` — Phạm vi, ranh giới, giả định.
2. `docs/02_DATA_CONTRACT.md` — Dữ liệu, định danh, nhập liệu, lưu trữ, phiên bản.
3. `docs/03_SAFETY_RULE_CONTRACT.md` — Quy tắc và giới hạn bằng chứng an toàn.
4. `docs/04_ACCEPTANCE_EVIDENCE_CONTRACT.md` — Acceptance criteria, test, proof.
5. `docs/05_CVF_INTEGRATION_MAPPING.md` — Ánh xạ CVF, không sửa CVF core.
6. `docs/06_ROADMAP_GATED.md` — Roadmap dựa trên gates G0–G5.
7. `docs/07_ARCHITECTURE_TREEVIEW.md` — Monorepo, FE/BE tách module.
8. `docs/08_LOCAL_AGENT_HANDOFF.md` — Work order cho Agent local.
9. `docs/09_DECISION_RISK_LOG.md` — Các quyết định và rủi ro chưa đóng.
10. `docs/10_UX_WORKFLOWS.md` — Luồng UI/UX và trạng thái cần thể hiện.
11. `contracts/schemas/*.schema.json` — Khung schema đề xuất, chưa được freeze.
12. `tests/golden_cases.csv` — Danh sách oracle test mức thiết kế.

## Quan điểm thiết kế

- **Tool-first**: một bộ cài/chạy local, frontend và backend tách riêng theo code/API, không microservices.
- **Safety invariant**: tổng hàng hiện hữu + hàng dự kiến **không bao giờ vượt giới hạn hàng hóa đã xác minh** (cả giới hạn chứng nhận và giới hạn còn khả dụng cho chuyến).
- **Không đánh đồng** hình học khả thi với an toàn vận tải/ổn định kết cấu; quy tắc chưa được kiểm chứng **không** được ngầm `PASS`.
- **Manifest + hồ sơ phương tiện + kích thước vùng xếp hữu dụng**: trường bắt buộc chưa rõ → hỏi lại hoặc khóa solver.
- **Human authority**: AI đề xuất, không tự xác nhận dữ liệu, duyệt phương án hoặc thay luật; sửa đã duyệt tạo phiên bản mới.
- **CVF**: governance kiểm soát AI/tool calls, không thay thế Cargo Safety Engine và không làm thay đổi CVF core.

## Phân biệt các mức khẳng định

- `DESIGN_SPECIFIED`: có đặc tả.
- `IMPLEMENTED`: có code, chưa ngụ ý đúng.
- `TEST_EVIDENCED`: có test, log và fixture chạy thực.
- `FIELD_REVIEWED`: có đối chiếu thực tế và xác nhận chuyên môn.

Hiện tại **chỉ đạt `DESIGN_SPECIFIED`** ở mức bản dự thảo; chưa có test runtime.

## Nguồn tham chiếu chính (đọc với giới hạn áp dụng)

- IMO CSS Code (Resolution A.714(17), Annex 7 — metal products): https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/AssemblyDocuments/A.714%2817%29.pdf — tham chiếu kỹ thuật; cần kiểm tra phạm vi áp dụng với phương tiện thủy nội địa.
- Jurong Port steel cargo stowage: https://www.jp.com.sg/faqs/stowage-requirements/ — kinh nghiệm cảng Singapore; không tự động là pháp luật Việt Nam.
- QCVN 72:2025/BGTVT: https://tieuchuanxaydung.vsqi.gov.vn/quychuan/view?sohieu=QCVN%C2%A072%3A2025%2FBGTVT — cần xác nhận điều khoản áp dụng.
- Thông tư 78/2026/TT-BXD: https://chinhphu.vn/?docid=220128&pageid=27160 — ban hành 27/10/2026, **hiệu lực 01/05/2027** (chưa áp dụng như quy tắc hiện hành vào ngày soạn thảo).
- CVF repository, kiểm tra default branch tại commit `ebf31b9f5c42e4de58f40a434409c3441a5d8383` (2026-10-29): `Blackbird081/Controlled-Vibe-Framework-CVF-Provenance`. Việc truy cập nguồn không tương đương chứng minh tích hợp runtime.

## Đọc trước khi giao triển khai

Các giá trị trong mô hình ví dụ **không phải** dữ liệu vận hành hoặc giấy phép thực. Ảnh chứng từ đã được cung cấp qua cuộc trò chuyện không được tự nhúng vào repository/bộ ZIP này. Việc nhập chứng từ thực phải qua luồng quản lý dữ liệu riêng.

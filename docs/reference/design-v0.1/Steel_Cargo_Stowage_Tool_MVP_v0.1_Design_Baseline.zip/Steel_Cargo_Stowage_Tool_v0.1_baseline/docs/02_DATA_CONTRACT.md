# 02 — Data Contract v0.1

**Status:** `DRAFT_FOR_LOCAL_REVIEW`. Schema máy trong `../contracts/schemas/` là bản phác thảo để review, chưa freeze.

## Mô hình domain

- `Vessel` (identity ổn định) → `VesselProfileVersion` (bất biến sau khi VERIFIED).
- `VesselDocument` giữ file gốc, SHA-256, ngày hiệu lực, trường trích xuất và vị trí nguồn.
- `HoldProfileVersion` xác định **vùng xếp hữu dụng đã khai báo**, hệ trục xyz, hình hộp/hình thang, vùng loại trừ, nguồn số đo và margin.
- `Manifest` → `ManifestVersion` → `ManifestLine` → `CargoUnit`; `HandlingGroup` chỉ khi có quy tắc nâng/đóng gói phù hợp.
- `LoadingCase` pin một bộ phiên bản vessel/hold/manifest/rules, giới hạn hàng của chuyến và hàng hiện hữu.
- `OptimizationRun` lưu input hash, config/seed/time budget, solver build, kết quả.
- `StowagePlanVersion` giữ tọa độ/rotation (mm/độ), support relation, các cargo xếp/chưa xếp, rule results, plan hash.
- `ApprovalReceipt` có actor/time/plan hash, không do AI tạo; `AuditEvent` append-only; `BackupManifest` thống kê tài liệu/hash/DB version.

## Nhập chứng từ và xác minh

Pipeline: tải file → kiểm tra định dạng/kích thước/độc hại → SHA-256 lưu bản gốc bất biến → trích xuất AI/OCR có gắn source span → chuẩn hóa đơn vị → so khớp hồ sơ → hỏi lại mâu thuẫn → người dùng xác minh → ghi profile mới.

Trạng thái từng trường: `MISSING_REQUIRED`, `NEEDS_CONFIRMATION`, `CONFLICT`, `VERIFIED`.

**Chú ý fixture từ cuộc trò chuyện:** hai chứng từ cùng số đăng ký `SG-7240` có tên phương tiện khác nhau. Giấy an toàn phân biệt `lượng hàng 995 tấn` và `trọng tải toàn phần 999 tấn`; đây là hai khái niệm, không được dùng 999 tấn như payload. Giấy an toàn đang được đọc có thời hạn đến 06/11/2026, phải đối chiếu bản gốc/hồ sơ hiện hành khi lập chuyến. Không tự kết luận chứng từ nào thay thế chứng từ nào. **Không nhúng ảnh/hồ sơ thật vào repo.**

## Chính sách dữ liệu bắt buộc

- Khối lượng: số nguyên **kg**, tích dồn bằng integer; không nhận số âm, không nhận 0 cho kiện hàng thực.
- Kích thước: số nguyên **mm** cho bounding envelope của cargo unit, vùng hầm hữu dụng, kê lót và vùng loại trừ.
- Thời gian: ISO-8601 có timezone; ngày hiệu lực theo ngày tại nơi hoạt động.
- Tọa độ: gốc O=(0,0,0) ở một góc đáy vùng hầm hữu dụng; x theo chiều dài, y theo chiều ngang, z hướng lên; unit = mm. Hướng đầu mũi/lái phải có metadata riêng; **không suy đoán** x là mũi nếu chưa định nghĩa.
- Mọi dữ liệu từ AI trích xuất là `UNVERIFIED` cho tới khi user xác nhận. AI confidence không thay verification.
- Null/không có giá trị ≠ 0. Không tạo số giả làm số đo.
- Đơn vị bảng tính: parser bắt buộc nhận diện rõ mm/m, kg/tấn và locale dấu thập phân; mơ hồ → `NEEDS_CONFIRMATION`.

## Invariants dữ liệu

```text
W_existing + W_selected <= W_voyage_confirmed <= W_certificate_cargo_limit
W_existing >= 0
W_selected = sum(cargo_unit.massKg for placed cargo units)
IDs unique per manifest version
Each plan references immutable versions + a rule set hash
No VERIFIED field overwritten: replacement -> new version
No approved plan silently mutates: change -> new plan version, old approval remains historical only
```

Nếu chứng từ không thể xác minh cargo limit, vùng hầm thiếu kích thước hay manifest thiếu trọng lượng, không tạo optimization run có trạng thái `SOLVED`.

## Persist / retrieval

- SQLite (WAL trên ổ local hợp lệ) cho metadata, line items, profiles, plan version, rule outcomes, audit events, foreign keys. **Không** kết nối writable SQLite WAL qua network share.
- File store theo hash cho ảnh/PDF/XLSX/CSV gốc; checksum và MIME sniffing; không phụ thuộc tên file người dùng.
- JSON dùng cho API và snapshot portable (định kiểu, schema version, SHA-256). 3D viewer dựng lại từ `StowagePlanVersion`, không từ ảnh/render do AI phát sinh.
- Cơ chế tìm theo registration, case ID, manifest ID, date, cargo unit ID, plan version, trạng thái.
- Transaction khi ghi profile, manifest, plan, audit; ghi file theo staging + atomic rename + DB transaction; có kiểm tra orphaned blobs.
- Backup SQLite bằng API backup/transaction-consistent snapshot, copy file store theo manifest; verify checksum và thử restore định kỳ. Bản sao lưu bảo vệ khỏi sửa và truy cập trái phép.

## API contract sơ bộ

- `POST /api/v1/documents/intake` → document record, extraction *unverified*.
- `POST /api/v1/vessels/{id}/confirm-profile` → verified vessel profile version (human approval).
- `POST /api/v1/manifests/intake` → parsed draft + issues.
- `POST /api/v1/manifests/{id}/confirm` → manifest version immutable.
- `POST /api/v1/loading-cases` → case with pinned versions.
- `POST /api/v1/loading-cases/{id}/optimize` → run ID, result/report (backend validation first).
- `GET /api/v1/plans/{id}/versions/{v}` → exact geometry, coverage, provenance.
- `POST /api/v1/plans/{id}/revalidate` → new immutable validation receipt.
- `POST /api/v1/plans/{id}/select` → authenticated human decision bound to plan hash; no AI tool exposure.
- `POST /api/v1/backups` / `POST /api/v1/restore/verify` → controlled local operations.

Use Pydantic + OpenAPI to generate TypeScript client; avoid duplicate manually maintained models. All mutating endpoints enforce server-side preconditions, idempotency key where useful, optimistic concurrency with version/ETag.

## Quyền riêng tư

Gốc ảnh chứng từ có thể chứa dữ liệu cá nhân; local by default. AI Cloud (nếu sử dụng) chỉ nhận trường tối thiểu sau thao tác cho phép, không âm thầm tải toàn bộ tài liệu. Chặn traversal, macro/executable upload, formula injection trong CSV/Excel export, zip bombs, và thao túng prompt trong nội dung tài liệu.

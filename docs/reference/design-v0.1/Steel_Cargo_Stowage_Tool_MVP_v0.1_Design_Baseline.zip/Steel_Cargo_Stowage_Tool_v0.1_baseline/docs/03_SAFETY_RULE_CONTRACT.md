# 03 — Safety & Rule Contract v0.1

**Status:** `DRAFT_FOR_ENGINEERING_REVIEW`. Bộ rule này **không phải** danh mục chứng nhận tuân thủ pháp luật / thiết kế phương tiện.

## Hai lớp kiểm soát không được gộp

1. `CargoSafetyEngine`: các bất biến khối lượng, hình học, phạm vi profile hàng, kê đỡ, chèn lót, giới hạn đã nhập — logic xác định, độc lập AI/CVF.
2. `CVFGovernanceAdapter`: điều kiện Agent được đọc, đề xuất, gọi optimizer; ai được xác nhận/chấp thuận; audit và hạn chế quyền — **không** đưa kết quả này thay CargoSafetyEngine.

## Hard stop về tổng hàng

```text
certificateCargoLimitKg = verified authorized cargo capacity, NOT gross tonnage
voyageCargoLimitKg = human-confirmed usable cargo allowance for this loading case
existingCargoKg = verified cargo already aboard (if any)
selectedCargoKg = sum(massKg for actually placed units)

require certificateCargoLimitKg > 0
require voyageCargoLimitKg > 0 and voyageCargoLimitKg <= certificateCargoLimitKg
require existingCargoKg >= 0
require existingCargoKg + selectedCargoKg <= voyageCargoLimitKg
```

Nếu không biết hàng hiện hữu, chưa xác nhận cargo limit hoặc giấy hết hiệu lực ở ngày lập chuyến: **BLOCK_OPTIMIZATION**. Không có epsilon cho phép vượt tải; sai số không làm tăng capacity.

## Rule catalog ban đầu

| ID | Hành vi | Mức | Điều kiện dữ liệu | Không thể kiểm tra thì |
|---|---|---|---|---|
| S-001 | Certificate và vessel identity đã xác minh, phù hợp ngày chuyến | HARD_GATE | Documents/validity | BLOCK |
| S-002 | Voyage usable cargo allowance được người có thẩm quyền xác nhận | HARD_GATE | Vessel + voyage data | BLOCK |
| S-003 | Tổng hàng hiện hữu + hàng được chọn ≤ voyage limit ≤ certified cargo capacity | HARD_GATE | Mass kg | BLOCK |
| S-004 | Tất cả Cargo Units có ID, loại, bao hình học, trọng lượng hợp lệ | HARD_GATE | Manifest data | BLOCK |
| S-005 | Hình khối hàng nằm trong vùng xếp hữu dụng và không giao cắt / rơi vào excluded zones | HARD | Geometry | FAIL |
| S-006 | Chỉ xếp cargo types có support/stack profile đã review, theo orientation được phép | HARD | Cargo support profile | BLOCK/FAIL |
| S-007 | Quan hệ đỡ/chồng của các tầng đáp ứng support profile đầu vào; không có floating/unsupported units | HARD | Approved simple support rules | FAIL/NOT_EVALUATED |
| S-008 | Bất kỳ chỉnh sửa vị trí nào đều chạy lại rule engine ở backend | HARD_GATE | Plan diff | BLOCK |
| S-009 | Tải đáy hầm/tải cục bộ/kết cấu nếu có hồ sơ đủ tin cậy và rule được phê duyệt | CONDITIONAL | Engineering evidence | NOT_EVALUATED → Engineering review |
| S-010 | Ổn định, trim/list, mớn nước, điều kiện chuyển tải trung gian | ENGINEERING_CHECK | Hydrostatic/load data | NOT_EVALUATED → Engineering review |
| S-011 | Chằng buộc/chống lăn/chêm lót thực tế theo nhóm sản phẩm | ENGINEERING_CHECK | Material, dunnage plan | NOT_EVALUATED → Engineering review |
| S-012 | Ưu tiên nặng dưới nhẹ trên, ngắn dưới dài trên **nếu kê đỡ phù hợp** | SOFT/CONDITIONAL | Profile and geometry | Warning/score only |
| S-013 | Không cho AI tự đổi limit / set verified / phê duyệt | GOVERNANCE | CVF+Backend | BLOCK action |

Quy tắc S-009–S-011 **không được** báo PASS nếu thiếu dữ liệu. Khi đó Tool chỉ tuyên bố mức `GEOMETRY_FEASIBLE` và `RULES_CHECKED` với coverage rõ; việc được xếp thực tế là quyết định của người có trách nhiệm sau rà soát kỹ thuật.

## Thiết kế rule entry

`id`, `version`, `title`, `scope` (cargo type, vessel class, date), `severity`, `inputRequirements`, `decision` (`PASS|FAIL|NEEDS_REVIEW|NOT_EVALUATED|NOT_APPLICABLE`), `evidenceRefs`, `sourceType` (`LOCAL_APPROVED|OFFICIAL_RULE|GUIDELINE|ASSUMPTION`), `sourceUri`, `effectiveFrom`, `effectiveTo`, `owner`, `approvedBy`, `testCaseIds`.

HARD rules fail closed khi không đủ dữ liệu thuộc tiền điều kiện. Chỉ kích hoạt rule mới sau phiên bản hóa + review + test; không để AI/prompt thay runtime authority.

## Optimization contract

Thứ tự mục tiêu: (1) thỏa mọi HARD constraints có dữ liệu; (2) tùy chọn tìm cách xếp hết manifest hoặc báo không khả thi; (3) nếu không thể xếp hết, tối đa khối lượng **nằm trong giới hạn hợp pháp**, theo phép ưu tiên do user lựa chọn; (4) giảm trống, chênh lệch phân bố, số lần đảo dự kiến — chỉ scoring, không thể thay hard constraints.

Mọi run có `solverStatus=SOLVED|INFEASIBLE|TIMEOUT_WITH_CANDIDATE|TIMEOUT_NO_CANDIDATE`, seed/timeLimit, version và danh sách cargo units chưa xếp. `TIMEOUT_WITH_CANDIDATE` chỉ sử dụng được nếu candidate vượt qua revalidation; timeout không đồng nghĩa tối ưu toàn cục. “Đặt hết manifest” không phải yêu cầu tuyệt đối nếu vượt giới hạn cargo/voyage.

## Geometry 2.5D + 3D

- Solver sử dụng bounding-envelope của bó (not literal tubes), disallowed orientations, conservative packing clearances, layer positions và đơn giản hóa mặt tiếp xúc.
- 3D viewer đọc tọa độ solver đã lưu. Mesh 3D trang trí không được dùng làm nguồn quyết định hợp lệ.
- Không mô hình hóa thép cuộn hoặc hỗn hợp đặc thù trước khi có support profile riêng được phê duyệt.

## Nguồn quy tắc và giới hạn pháp lý

- IMO CSS Code Annex 7 mô tả rủi ro về deck/tank-top load, dịch chuyển hàng, ổn định và kê chèn hàng kim loại: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/AssemblyDocuments/A.714%2817%29.pdf. Đây là tài liệu chuẩn ngành vận tải biển, không tự động thay thế quy định nội địa Việt Nam.
- Jurong Port: https://www.jp.com.sg/faqs/stowage-requirements/ — thực hành ngành có chi tiết theo nhóm hàng, thuộc phạm vi cảng riêng.
- QCVN 72:2025/BGTVT https://tieuchuanxaydung.vsqi.gov.vn/quychuan/view?sohieu=QCVN%C2%A072%3A2025%2FBGTVT — kỹ sư/đơn vị chuyên môn phải đối chiếu điều khoản liên quan từng phương tiện.
- Thông tư 78/2026/TT-BXD ban hành 27/10/2026, **chỉ hiệu lực 01/05/2027**, Rule Registry cần active dates.

Không gắn nhãn `compliant` cho toàn bộ phương án khi chưa chứng minh được đầy đủ tiêu chí pháp lý và kỹ thuật áp dụng.

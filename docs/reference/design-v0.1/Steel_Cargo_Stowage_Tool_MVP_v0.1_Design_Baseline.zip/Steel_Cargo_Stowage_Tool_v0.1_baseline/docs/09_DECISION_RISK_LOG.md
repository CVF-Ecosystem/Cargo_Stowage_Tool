# 09 — Decisions, Risks, Open Questions v0.1

## Architecture decisions (đề xuất đã được user đồng ý về nguyên tắc)

| ID | Decision | Ghi chú |
|---|---|---|
| ADR-001 | Tool-first, local-first, có thể mở rộng | Không triển khai cloud/multitenant giai đoạn đầu |
| ADR-002 | FE/BE tách code, một monorepo/one local deployment | Modular monolith; typed OpenAPI |
| ADR-003 | SQLite + immutable documents + JSON plan snapshots | Version/audit/backup bắt buộc |
| ADR-004 | Solver deterministic/business rules backend, 3D là visualization | 3D không thay kỹ thuật |
| ADR-005 | AI optional, restricted, human decides | Không tự approve/alter limits |
| ADR-006 | CVF adapter bounded, CVF core untouched | Local integration cần bằng chứng |
| ADR-007 | Hầm mô hình hóa gần đúng; báo unknown rõ | Không tuyên bố an toàn toàn diện |

## Open blockers: phải xác minh trước từng gate

| ID | Câu hỏi / rủi ro | Priority | Owner | Resolve by |
|---|---|---|---|---|
| OPEN-01 | Cách xác nhận lượng hàng khả dụng theo chuyến (các tải và điều kiện đi kèm) | BLOCKER | Operator + chuyên môn | G0/G2 |
| OPEN-02 | Ai là người xác nhận giới hạn, điều kiện xếp, duyệt plan tại hiện trường? | BLOCKER | Operator | G0 |
| OPEN-03 | Dữ liệu hầm tối thiểu chính xác đến đâu, margins bao nhiêu? | BLOCKER | Kỹ thuật/Operator | G1/G2 |
| OPEN-04 | Support/stacking profile cho bó thép thanh/ống; dunnage điều kiện nào? | BLOCKER | Chuyên môn | G2 |
| OPEN-05 | Mức độ cho phép tối ưu một phần manifest và mục tiêu ưu tiên | HIGH | Owner | G0/G3 |
| OPEN-06 | Trường manifest thực tế và quy tắc tách dòng thành cargo unit | HIGH | Operator | G1 |
| OPEN-07 | Ranh giới dữ liệu gửi tới AI Cloud, nếu có | HIGH | Owner | G4b |
| OPEN-08 | Runtime CVF bridge khả thi với phiên bản pinned không? | HIGH | Local Agent | G4b |
| OPEN-09 | Dataset 2–3 chuyến thực và quyền dùng dữ liệu ẩn danh | HIGH | Operator | G5 |
| OPEN-10 | Văn bản áp dụng cho sà lan nội địa theo loại, vùng hoạt động và ngày chuyến | BLOCKER | Chuyên môn/pháp chế | G2 |

## Risk register (không gom rủi ro vào score)

| Risk | Severity | Mitigation | Residual |
|---|---|---|---|
| R-LOAD | CRITICAL | Verified cargo/voyage load + integer hard invariant | Requires verified voyage conditions |
| R-STABILITY | CRITICAL | Explicit not evaluated + field engineering signoff | Out of tool scope |
| R-SUPPORT | HIGH | Approved support profiles + fail closed | Geometry simplified |
| R-DOC | HIGH | original file hash + conflicting fields + human confirmation | Misread originals possible |
| R-AGENT | HIGH | CVF adapter + backend auth + negative tests | Integration unproven |
| R-DATA | HIGH | immutable snapshots, backups, access control | restore untested |
| R-OPT | MEDIUM/HIGH | bounded solver, oracle test, nonoptimal status | Optimality not guaranteed |

## Change control

Any modification to hard rules, cargo model or approval model requires version update, impact analysis, regression tests and explicit review. Changing solver preferences alone cannot disable hard constraints.

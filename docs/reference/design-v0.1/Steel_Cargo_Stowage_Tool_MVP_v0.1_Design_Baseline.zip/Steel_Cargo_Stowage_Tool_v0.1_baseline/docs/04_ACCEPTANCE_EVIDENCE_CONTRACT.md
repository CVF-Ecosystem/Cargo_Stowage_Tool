# 04 — Acceptance & Evidence Contract v0.1

**Status:** `DRAFT_FOR_LOCAL_REVIEW`. **Owner:** Independent reviewer + Local agent (runtime evidence). Phần sau là tiêu chí nghiệm thu, **chưa phải kết quả test**.

## Gates được xác nhận bằng bằng chứng, không bằng báo cáo tự nhận

| Gate | Bằng chứng cần nộp | Quyết định |
|---|---|---|
| G0 Scope | Scope signoff, hai cargo types, boundary/out-of-scope, role owner | ACCEPT / REVISE |
| G1 Data | JSON Schema compile, schema tests, imports có lỗi, sample fixture, migrate/backup restore test | PASS / FAIL |
| G2 Safety | Rule registry + trace to source + negative tests; engineering assumptions reviewed | PASS / FAIL / BLOCKED |
| G3 Solver | Test oracle, geometry/support/mass hard constraints, feasible/infeasible, timeouts, reproducibility | PASS / FAIL |
| G4 UI/CVF | E2E thao tác 3D→backend validation, AI-denied paths, approval-bound hash, local bridge integration evidence | PASS / FAIL |
| G5 Field | 2–3 chuyến tham chiếu, đối chiếu manifest-vị trí-tải-thao tác với chuyên gia khai thác | PASS / FAIL / LIMITATION |

## Evidence receipt tối thiểu

```json
{
  "testCaseId": "GC-001",
  "sourceCommit": "<real source commit>",
  "testCommand": "<exact reproducible command>",
  "testTimestamp": "<ISO-8601>",
  "runtimeVersions": {"python": "<version>", "node": "<version>"},
  "inputFixtureSha256": "<sha256>",
  "ruleSetSha256": "<sha256>",
  "expected": "<oracle>",
  "actual": "<real observed>",
  "verdict": "PASS_OR_FAIL",
  "logPath": "<saved log reference>",
  "limitations": ["<unverified aspects>"]
}
```

Không điền `<...>` thành số giả; không nộp screenshot thành bằng chứng duy nhất của correct solver.

## Test matrix cốt lõi

### Intake
- Phân biệt `cargo capacity` và `gross tonnage`; mâu thuẫn tên/giấy hết hạn/missing doc -> hỏi lại, không solver.
- Thiếu trọng lượng/mất đơn vị/CSV trùng ID/Excel có công thức hiểm -> fail closed.
- Nhập cùng tài liệu hai lần không tạo record nguồn nhân đôi, metadata vẫn lưu history.

### Mass & geometry
- Tổng vừa bằng giới hạn -> có thể đi tiếp kiểm tra còn lại; vượt đúng 1 kg -> BLOCK.
- Existing cargo 40 t + proposed 965 t trong allowed 995 t -> BLOCK.
- Manifest có một cargo unit lớn hơn hầm -> unplaced + lý do, không clip mesh.
- 2 cargo overlap -> FAIL; touching tolerance theo profile rõ ràng; unsupported orientation -> FAIL.
- Bó tầng trên không có mặt đỡ được định nghĩa -> FAIL/NOT_EVALUATED theo rule.
- 3D và plan JSON đồng nhất khi reload, phiên bản không đổi.

### Solver
- Feasible fixture nhỏ có lời giải oracle đơn giản.
- Infeasible fixture không thể xếp đủ, report unplaced, không tự tăng limit.
- Time budget exceeded trả `TIMEOUT_*` có luận cứ; không gắn nhãn global optimum.
- Với seed và snapshot giống nhau, có thể tái lập kết quả nếu solver/cấu hình deterministic; nếu nondeterministic phải ghi run metadata.

### Approval/CVF
- Browser gọi trực tiếp endpoint chọn/approve giả không vượt backend.
- AI/tool caller không được biến `CONFLICT` thành VERIFIED hay thay safety limit.
- Plan đã chọn thay manifest/rule/hold -> plan mới cần validation và approval mới, bản cũ giữ hash.
- Fake/expired/revoked/wrong-actor CVF approval evidence -> BLOCK/ESCALATE.
- CVF bridge unreachable -> hành động Agent có tính mutation/approval bị fail closed; manual tool core vẫn hoạt động dưới chính sách local.
- Prompt injection nhúng trong PDF/Excel bị coi là dữ liệu, không có quyền ra lệnh.

### Storage
- Crash giữa lưu tài liệu/metadata không để `VERIFIED` tham chiếu tới file thiếu; recovery thực sự hoạt động.
- Restore gói backup xong kiểm checksum, opens exact vessel, manifest, plans và audits.

## Tiêu chí hiệu quả vận hành chưa chốt chỉ tiêu

Chỉ đặt KPI sau khi có 2–3 chuyến đối chiếu và đo baseline thực: số bó xếp, tấn, thời gian giải, unplaced, số lần người dùng chỉnh, chênh lệch với phương án chuyên môn. Không đưa con số % cải thiện tùy ý vào acceptance gate.

## Trách nhiệm và phân loại bằng chứng

- Researcher/Auditor: nguồn, rule mapping, risk và giới hạn khẳng định.
- Local Agent: code, exact tests, logs, diff, screenshot UI đi kèm dữ liệu.
- Kỹ sư/đơn vị chuyên môn: xác minh giới hạn kỹ thuật, chằng buộc, ổn định, chấp nhận điều kiện sử dụng thực tế.
- User/Owner: quyết định phạm vi, phê duyệt lựa chọn phương án.

`TEST_EVIDENCED` không đồng nghĩa `FIELD_REVIEWED`; không được chuyển trạng thái bằng tuyên bố từ AI.

# 08 — Local Agent Handoff / Work Order v0.1

**Role:** Local Implementer & Runtime Verifier.  
**Authority:** Không có quyền sửa CVF core; không có quyền tuyên bố tuân thủ chất xếp/đăng kiểm.  
**Input:** Bộ Design Baseline v0.1, tài liệu/test cases và các giấy tờ/vận đơn được operator cung cấp tại local (KHÔNG mặc định truy cập dữ liệu từ cuộc trò chuyện).

## Mission

Đối chiếu các contracts với mã nguồn CVF local và yêu cầu nghiệp vụ, dựng baseline code skeleton theo modular monolith FE/BE **sau khi G0–G2 được review**, xây test harness và gợi ý những điểm bất khả thi/phải hỏi lại. Cung cấp bằng chứng thực, không lấp chỗ trống bằng giả định.

## Execution order

1. **READ & AUDIT:** đọc README + 9 docs; xác minh đúng snapshot CVF commit; tạo `REVIEW_OPEN_ISSUES.md` với blockers, các thông tin phải hỏi người vận hành/kỹ sư.
2. **G0/G1 SPEC:** đề xuất tinh chỉnh schema từ hình thức dự thảo, implement validators, test CSV/Excel/vessel doc field conflict, versioning/immutability. **Đừng tự invent payload từ chứng từ.**
3. **G2 ENGINEERING:** đối chiếu rule source applicability; nhờ chuyên gia xác nhận parameter và condition; đánh dấu `NOT_EVALUATED` nơi thiếu.
4. **FE/BE SKELETON:** monorepo, typed API, SQLite migrations, storage test, 3D sample projection. Không gọi 3D demo là safety solver.
5. **SOLVER SPIKE:** fixture synthetic small; proof of impossible/overweight/unsupported cases; xuất trace/oracle.
6. **CVF SPIKE:** thử read-only và denied mutation qua guard bridge. Không thay CVF guard core / forge roles or approvals.
7. **REPORT:** nộp log thực, exact commands, test result PASS/FAIL, screenshots UI, gaps và đề xuất next gate.

## Output package tối thiểu

- `LOCAL_DESIGN_REVIEW.md`: discrepancies và disposition theo từng contract.
- `GATE_STATUS.md`: G0–G5 = NOT_STARTED/PENDING/PASS/FAIL/BLOCKED + evidence refs.
- `RUNTIME_EVIDENCE/`: tests, source SHA, input fixture SHA, logs, constraints coverage.
- `CVF_COMPATIBILITY_REPORT.md`: exact package imports, bridge decision paths, negative cases.
- `OPEN_DECISIONS.md`: chỉ các câu hỏi thật sự chặn triển khai.
- `TREEVIEW_AS_BUILT.md`: đường dẫn thực sau khi code, phân biệt kiến trúc dự kiến.

## Nonnegotiable rules

- Không cho AI phê duyệt, đổi hạn mức, sửa nguồn xác minh hoặc coi `ESCALATE` thành `ALLOW`.
- Không đánh dấu pass cho rule chưa kiểm; không dùng hình 3D làm bằng chứng ổn định/tải cục bộ.
- Không đưa ảnh/PII giấy tờ vào repo/public logs. Test fixture riêng cần anonymize.
- Không sửa repo CVF core. Nếu phát hiện bug/không tương thích, chỉ báo issue + đề xuất adapter bounded.
- Hành động ngoài phạm vi cần explicit operator approval và bằng chứng, không tự điều chỉnh requirement.
- Nộp runnable tests và ghi nhận kết quả trung thực; `not run` không phải `pass`.

## First useful commit (đề nghị, không phải đã thực hiện)

Create monorepo skeleton + docs import + JSON Schema unit tests + validator for `certificateCargoLimitKg`, `voyageCargoLimitKg`, `existingCargoKg` + failing tests for gross/payload confusion. No optimization claim. Gate status remains G0/G1 pending until reviewed.

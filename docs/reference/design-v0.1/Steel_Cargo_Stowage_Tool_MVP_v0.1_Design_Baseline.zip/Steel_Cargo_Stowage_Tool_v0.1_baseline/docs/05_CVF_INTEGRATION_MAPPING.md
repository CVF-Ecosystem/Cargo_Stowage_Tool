# 05 — CVF Integration Mapping v0.1

**Status:** `CANDIDATE_MAPPING_ONLY`; **Not integrated**.  
**Source snapshot:** `Blackbird081/Controlled-Vibe-Framework-CVF-Provenance`, commit `ebf31b9f5c42e4de58f40a434409c3441a5d8383` (2026-10-29, default branch checked 2026-10-31).

## Source evidence (GitHub, không phải runtime)

1. `EXTENSIONS/CVF_GUARD_CONTRACT/src/engine.ts`: `GuardRuntimeEngine` có `registerGuard`, `evaluate`, aggregation `BLOCK/ESCALATE`, mandatory guard identities.
2. `EXTENSIONS/CVF_GUARD_CONTRACT/src/types.ts`: `GuardRequestContext` (phase, riskLevel, role, action, scope, traceHash...), `GuardDecision = ALLOW|BLOCK|ESCALATE`, `RiskApprovalEvidence`, `BuildAuthorityEvidence`.
3. `docs/reference/CVF_SEMANTIC_POLICY_INTENT_REGISTRY.md`: `guard_alias`, `policy_intent`, `output_contract`, `eval_signal`; các alias `EXPLICIT_APPROVAL_REQUIRED`, `SCOPE_BOUND_EXECUTION`, `AUDITABILITY_REQUIRED`; intents `NO_ASSUMPTION`, `REQUIRE_CLARIFICATION`.
4. `docs/reviews/CVF_NCR_HTML_PILOT_R2_GATE_ARCHITECTURE_REVIEW_2026-10-24.md`: cảnh báo đường approval/RiskGate có thể chưa khớp; không giả định guard ALLOW chỉ vì UI đã có approval.

Các file trên chứng minh **có source tương ứng**, chưa chứng minh Tool có thể gọi hoặc các guard đã chạy đúng trong ngữ cảnh nghiệp vụ này.

## Policy mapping dự kiến (không tuyên bố đã tích hợp)

| Business action | CVF control candidate | Server precondition | Denied behavior |
|---|---|---|---|
| `extract_document` | input/context validation + scope | isolated document, untrusted content | no instructions from document executed |
| `read_profile` | scope guard, audit | allowed case and read scope | deny unrelated documents |
| `propose_stowage` | scope / audit | verified case + safety validation | no solver when missing required |
| `request_plan_revision` | mutation/scope + audit | exact plan version and allowed edit | deny unauthorized state change |
| `change_cargo_limit` | authority gate | human & verified source; immutable new profile | AI always denied |
| `confirm_intake` | authority gate | explicit actual user confirmation | AI cannot self-confirm |
| `select_plan` | authority gate + audit | user actor, current version, plan hash | AI cannot self-approve |
| `edit_rule_registry` | guarded admin maintenance, not user planning AI | separately approved review & test | deny during normal operation |

## Adapter boundary

```text
AI provider (optional)
  -> permitted tool catalog
  -> Python backend CVF Adapter port
  -> CVF Guard Bridge (candidate: bounded local Node process using CVF_GUARD_CONTRACT)
  -> ALLOW / BLOCK / ESCALATE + receipt
  -> Python Backend Policy + CargoSafetyEngine (revalidate independently)
  -> persisted action, if allowed and authorized
```

Do **not** directly replicate canonical CVF guard logic in Python without review; do **not** import CVF runtime into React browser. Bounded Node bridge is a **candidate architecture** pending compatibility and security tests; it is not a claim of ready-to-use integration. If exact CVF runtime cannot be cleanly integrated, keep AI mutation capabilities disabled, use local backend authorization for manual workflow, and open a separate integration review; do not silently bypass.

## Trust boundaries

- Browser/client-provided actor, approval, role/risk level or traceHash is **not authoritative**. Server verifies identity, scope, immutable target, evidence and hashes before constructing guard context.
- Uploaded documents and AI messages are untrusted input, never rule source.
- CVF `ALLOW` is not cargo engineering clearance; CargoSafetyEngine still must pass its own rules.
- CVF `BLOCK/ESCALATE`, missing adapter result, expired approval, stale snapshot => fail closed on the Agent mutation path.
- No changes to CVF core as a side effect of this Tool project. Any candidate needed upstream is separately reviewed under CVF governance.

## Local validation tasks

- Verify current repository commit, package import surface, license/runtime/dependencies, mandatory guard registration and adapter contract.
- Build a *standalone bridge spike* for one read-only `read_profile` and one denied `change_cargo_limit` request; capture actual guard decisions and receipts.
- Run forged actor, expired/revoked approval, stale plan and browser-supplied traceHash tests.
- Verify that false `ALLOW` from bridge cannot bypass Python CargoSafetyEngine.
- Submit `CVF_COMPATIBILITY_REPORT.md` with exact SHA, files read, test commands, results, unresolved issues; do not claim `INTEGRATED` before tests.
